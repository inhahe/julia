#include "WindowLevelSettingsWidget.h"

WindowLevelSettingsWidget::WindowLevelSettingsWidget(QWidget *parent)
: QWidget(parent)
{
	setupUi(this);

	QPalette palette = lcdNumberWindow->palette();
	palette.setColor(QPalette::Normal, QPalette::Foreground, Qt::red);
	palette.setColor(QPalette::Normal, QPalette::Background, Qt::red);
	lcdNumberWindow->setPalette(palette);

	palette = lcdNumberLevel->palette();
	palette.setColor(QPalette::Normal, QPalette::Foreground, Qt::red);
	palette.setColor(QPalette::Normal, QPalette::Background, Qt::red);
	lcdNumberLevel->setPalette(palette);
}

void WindowLevelSettingsWidget::setMinimumWindow(int minimum)
{
	sliderWindow->setMinimum(minimum);
}

void WindowLevelSettingsWidget::setMaximumWindow(int maximum)
{
	sliderWindow->setMaximum(maximum);
}

void WindowLevelSettingsWidget::setWindow(int value)
{
	sliderWindow->setValue(value);
}

void WindowLevelSettingsWidget::setMinimumLevel(int minimum)
{
	sliderLevel->setMinimum(minimum);
}

void WindowLevelSettingsWidget::setMaximumLevel(int maximum)
{
	sliderLevel->setMaximum(maximum);
}

void WindowLevelSettingsWidget::setLevel(int value)
{
	sliderLevel->setValue(value);
}

void WindowLevelSettingsWidget::on_sliderWindow_valueChanged(int value)
{
	emit(windowChanged(value));
}   

void WindowLevelSettingsWidget::on_sliderLevel_valueChanged(int value)
{
	emit(levelChanged(value));
} 