#include "EndoscopyRenderer.hpp"
#include "IPRenderer.hpp"
#include "Logging.hpp"
#include "MarchingCubesEndoscopyRenderer.hpp"
#include "MarchingCubesRenderer.hpp"
#include "SliceRenderer.hpp"
#include "ShadedSurfaceRenderer.hpp"

#include "MainWindow.h"
#include "ExtractIsosurfaceSettingsDialog.h"
#include "EndoscopySettingsWidget.h"
#include "FilterSettingsDialog.h"
#include "HardwareRenderingDisplayWidget.h"
#include "IPSettingsWidget.h"
#include "MarchingCubesSettingsWidget.h"
#include "PerlinNoiseSettingsDialog.h"
#include "ResampledVolumeSettingsDialog.h"
#include "SSDSettingsWidget.h"
#include "SliceSettingsWidget.h"
#include "SubvolumeSettingsDialog.h"
#include "RenderingWidget.h"
#include "VolumeBrowser.h"
#include "ProgressBarCallback.h"

#include <QtCore/QSettings>
#include <QtGui/QDockWidget>
#include <QtGui/QFileDialog>
#include <QtGui/QMessageBox>
#include <QtGui/QProgressDialog>
#include <QtGui/QStackedWidget>
#include <QtGui/QWorkspace>

using namespace Thermite;

MainWindow::MainWindow(QWidget* parent)
:strLastViewedDirectory("")
,m_iPerlinNoiseVolumeCounter(1)
,m_iResampledVolumeCounter(1)
,m_iSubvolumeCounter(1)
,m_iFilteredVolumeCounter(1)
{
    setupUi(this);

	//Create the workspace
	workspace = new QWorkspace;
    setCentralWidget(workspace);

	//Create the volume browser
	volumeBrowserDockWindow = new QDockWidget("Volume Browser", this);
	volumeBrowser = new VolumeBrowser;
	volumeBrowser->addActionToContextMenu(actionAdd_Slice_Renderer);
	volumeBrowser->addActionToContextMenu(actionAdd_IP_Renderer);
	volumeBrowser->addActionToContextMenu(actionAdd_SSD_Renderer);
	volumeBrowser->addActionToContextMenu(actionAdd_Endoscopy_Renderer);
	volumeBrowserDockWindow->setWidget(volumeBrowser);
	addDockWidget(Qt::LeftDockWidgetArea, volumeBrowserDockWindow);

	//Create the settings editor
	settingsEditorDockWindow = new QDockWidget("Settings Editor", this);
	//settingsEditor = new SettingsEditor;
	settingsWidgetStack = new QStackedWidget;
	settingsEditorDockWindow->setWidget(settingsWidgetStack);
	addDockWidget(Qt::LeftDockWidgetArea, settingsEditorDockWindow);

	menuDialogs->addAction(volumeBrowserDockWindow->toggleViewAction());
	menuDialogs->addAction(settingsEditorDockWindow->toggleViewAction());
	menuToolbars->addAction(fileToolBar->toggleViewAction()); 
	menuToolbars->addAction(softwareRendererToolBar->toggleViewAction());
	menuToolbars->addAction(hardwareRendererToolBar->toggleViewAction());
	menuToolbars->addAction(processorToolBar->toggleViewAction());

	m_nameVolumeMap.clear();
	readSettings();

	menuOpen_Recent->addSeparator();
	menuOpen_Recent->addAction(actionClear_Recent_Files_List);	
}

void MainWindow::on_actionOpen_triggered()
{
	//Load a volume
	QString path = QFileDialog::getExistingDirectory(this, "Select directory to open", strLastViewedDirectory);
	if(path.isEmpty() == false)
	{
		QDir dir(path);
		dir.makeAbsolute();
		strLastViewedDirectory = dir.path();
		openFile(dir.path());
	}	
}

void MainWindow::on_actionSave_As_triggered()
{	
	if(volumeBrowser->hasSelectedItem() == false)
	{
		QMessageBox::information(this, "Voxel Studio", "Please select a volume first");
		return;
	}

	//Save the volume
	QString selectedVolume = volumeBrowser->getSelectedVolume();
	QString path = QFileDialog::getExistingDirectory(this, "Select directory to save to", strLastViewedDirectory);
	if(path.isEmpty() == false)
	{
		QDir dir(path);
		dir.makeAbsolute();	
        
		strLastViewedDirectory = dir.path();
		m_nameVolumeMap[selectedVolume]->save(dir.path().toStdString(), BZIP2);
	}	
}

void MainWindow::on_actionImport_triggered()
{
	
	//Load a volume
	QString filename = QFileDialog::getOpenFileName(this, "Select file to import", ".", "Volumes (*.dat)");
	
	//Check the file isn't open
	if(m_nameVolumeMap.contains(filename))
	{
		QMessageBox::information(this, "Voxel Studio", "The volume you selected is already open!");
		return;
	}

	//Open it.
	LinearVolume<uint2>* pVolume = new LinearVolume<uint2>;
	try
	{
		QProgressDialog progressDialog("Importing DAT File...",0,0,1000);
		ProgressBarCallback progressBarCallback(&progressDialog);
		pVolume->importDAT(filename.toStdString(), progressBarCallback);
	}
	catch (const file_error& e)
	{
		QMessageBox::warning(this, "VoxelStudio", QString("Failed to open file - ") + e.what());
		return;
	}
	addVolume(filename,pVolume);
}

void MainWindow::on_actionAdd_Slice_Renderer_triggered()
{
	addRenderingWindow(Slice);
}

void MainWindow::on_actionAdd_Endoscopy_Renderer_triggered()
{
	addRenderingWindow(Endoscopy);
}

void MainWindow::on_actionAdd_IP_Renderer_triggered()
{
	addRenderingWindow(IP);
}

void MainWindow::on_actionAdd_SSD_Renderer_triggered()
{
	addRenderingWindow(SSD);
}

void MainWindow::on_actionAdd_Marching_Cubes_Renderer_triggered()
{
	addRenderingWindow(MarchingCubes);
}

void MainWindow::on_actionAdd_Marching_Cubes_Endoscopy_Renderer_triggered()
{
	addRenderingWindow(MarchingCubesEndoscopy);
}

void MainWindow::addRenderingWindow(RendererType type, int iWidth, int iHeight)
{
	//Identify which volume is selected...	
	if(volumeBrowser->hasSelectedItem() == false)
	{
		QMessageBox::information(this, "Voxel Studio", "Please select a volume first");
		return;
	}
	QString selectedVolume = volumeBrowser->getSelectedVolume();

	Thermite::Volume<Thermite::uint2>* pVolume = m_nameVolumeMap[selectedVolume];

	RenderingWidget* renderingWidget;
	QWidget* settingsWidget;
	switch(type)
	{
	case Slice:
		{
			SliceRenderer<uint2>* pRenderer = new SliceRenderer<uint2>(pVolume);
			renderingWidget = new RenderingWidget(pRenderer);
			renderingWidget->setMaxRes(HighResolution);
			renderingWidget->setMinRes(HighResolution);

			settingsWidget = new SliceSettingsWidget(pRenderer);

			connect(settingsWidget, SIGNAL(updateRequired()),renderingWidget,SLOT(update()));

			dynamic_cast<SliceSettingsWidget*>(settingsWidget)->setInitialValues(); //Should always work as we've just created it.

			break;
		}
	case IP:
		{
			IPRenderer<uint2>* pRenderer = new IPRenderer<uint2>(pVolume);
			renderingWidget = new RenderingWidget(pRenderer);
			renderingWidget->setMaxRes(LowResolution);
			renderingWidget->setMinRes(LowResolution);

			settingsWidget = new IPSettingsWidget(pRenderer);

			connect(settingsWidget, SIGNAL(updateRequired()),renderingWidget,SLOT(update()));

			dynamic_cast<IPSettingsWidget*>(settingsWidget)->setInitialValues(); //Should always work as we've just created it.

			break;
		}
	case SSD:
		{
			ShadedSurfaceRenderer<uint2>* pRenderer = new ShadedSurfaceRenderer<uint2>(pVolume);
			renderingWidget = new RenderingWidget(pRenderer);
			renderingWidget->setMaxRes(MediumResolution);
			renderingWidget->setMinRes(MediumResolution);

			settingsWidget = new SSDSettingsWidget(pRenderer);

			connect(settingsWidget, SIGNAL(updateRequired()),renderingWidget,SLOT(update()));

			dynamic_cast<SSDSettingsWidget*>(settingsWidget)->setInitialValues(); //Should always work as we've just created it.

			break;
		}
	case Endoscopy:
		{
			EndoscopyRenderer<uint2>* pRenderer = new EndoscopyRenderer<uint2>(pVolume,200.0f);
			renderingWidget = new RenderingWidget(pRenderer);
			renderingWidget->setMaxRes(LowResolution);
			renderingWidget->setMinRes(LowResolution);

			settingsWidget = new EndoscopySettingsWidget(pRenderer);

			connect(settingsWidget, SIGNAL(updateRequired()),renderingWidget,SLOT(update()));

			dynamic_cast<EndoscopySettingsWidget*>(settingsWidget)->setInitialValues(); //Should always work as we've just created it.

			break;
		}
	case MarchingCubes:
		{
			MarchingCubesRenderer<uint2>* pRenderer = new MarchingCubesRenderer<uint2>(pVolume);
			renderingWidget = new RenderingWidget(pRenderer);
			settingsWidget = new MarchingCubesSettingsWidget(pRenderer);

			connect(settingsWidget, SIGNAL(updateRequired()),renderingWidget,SLOT(update()));

			dynamic_cast<MarchingCubesSettingsWidget*>(settingsWidget)->setInitialValues(); //Should always work as we've just created it.

			break;
		}
	case MarchingCubesEndoscopy:
		{
			MarchingCubesEndoscopyRenderer<uint2>* pRenderer = new MarchingCubesEndoscopyRenderer<uint2>(pVolume);
			renderingWidget = new RenderingWidget(pRenderer);
			settingsWidget = new QWidget(); //MarchingCubesSettingsWidget(pRenderer);

			//connect(settingsWidget, SIGNAL(updateRequired()),renderingWidget,SLOT(update()));

			//dynamic_cast<MarchingCubesSettingsWidget*>(settingsWidget)->setInitialValues(); //Should always work as we've just created it.

			break;
		}
	default:
		{
			QMessageBox::information(this, "VoxelStudio", "Unable to create renderer - unknown rendering type");
			return;
		}

	}

	listRendererSettings.push_back(std::make_pair(renderingWidget,settingsWidget));	
		
	settingsWidgetStack->addWidget(settingsWidget);

	QWidget* window = workspace->addWindow(renderingWidget);
	window->resize(iWidth, iHeight);
	window->show();

	connect(workspace,SIGNAL(windowActivated(QWidget*)),this,SLOT(renderingWidgetGotFocus(QWidget*)));
}

void MainWindow::writeSettings()
{
	QSettings settings("David Williams", "Voxel Studio");

	//Save the size and position
	settings.setValue("Position", pos());
	settings.setValue("Size", size());

	//Save the last viewed directory
	settings.setValue("LastViewedDirectory", strLastViewedDirectory);

	//Save the recent files list
	settings.beginWriteArray("Recent Files");
	QList<QAction*> listActions = menuOpen_Recent->actions();
	for (int i = 0; i < listActions.size(); ++i)
	{
		if(listActions.at(i)->isSeparator())
		{
			break;
		}
		settings.setArrayIndex(i);
		settings.setValue("File", listActions.at(i)->text());
	}
	settings.endArray();
}

void MainWindow::readSettings()
{
	QSettings settings("David Williams", "Voxel Studio");

	//Load the size and position
	QPoint pos = settings.value("Position", QPoint(200, 200)).toPoint();
	QSize size = settings.value("Size", QSize(640, 480)).toSize();
	resize(size);
	move(pos);

	strLastViewedDirectory = settings.value("LastViewedDirectory").toString();

	//Load the recent files list
	int iNoOfRecentFiles = settings.beginReadArray("Recent Files");
	for (int i = 0; i < iNoOfRecentFiles; ++i)
	{
		settings.setArrayIndex(i);
		QString filename = settings.value("File").toString();
		menuOpen_Recent->addAction(filename);
	}
	settings.endArray();
}

void MainWindow::closeEvent(QCloseEvent *event)
{
	writeSettings();
}

bool MainWindow::openFile(QString path)
{
	//Check the file isn't open
	if(m_nameVolumeMap.contains(path))
	{
		QMessageBox::information(this, "Voxel Studio", "The volume you selected is already open!");
		return false;
	}

	//Open it.
	LinearVolume<uint2>* pVolume = new LinearVolume<uint2>;
	try
	{
		QProgressDialog progressDialog("Importing DAT File...",0,0,1000);		
		ProgressBarCallback progressBarCallback(&progressDialog);
		pVolume->load(path.toStdString(), progressBarCallback);
	}
	catch (const file_error& e)
	{
		QMessageBox::warning(this, "VoxelStudio", QString("Failed to open file - ") + e.what());
		return false;
	}
	addVolume(path,pVolume);

	//Add to recent files list.
	//If already there then remove and re-insert at top.
	QList<QAction*> listActions = menuOpen_Recent->actions();
	for(unsigned int ct = 0; ct < listActions.size(); ++ct)
	{
		if(listActions[ct]->text() == path)
		{
			menuOpen_Recent->removeAction(listActions[ct]);
			delete listActions.at(ct);
			break;
		}
	}
	QAction* action = new QAction(path,menuOpen_Recent);
	menuOpen_Recent->insertAction(menuOpen_Recent->actions()[0],action);

	THERMITE_LOG_INFO << "Finished opening file";
	return true;
}

void MainWindow::on_menuOpen_Recent_triggered(QAction* actActive)
{	
		//Check the action isn't the clear files list one - this is handled seperatly.
		if(actActive != actionClear_Recent_Files_List)
		{
			openFile(actActive->text());
		}
}

void MainWindow::on_actionClear_Recent_Files_List_triggered()
{
	QList<QAction*> listActions = menuOpen_Recent->actions();
	for(unsigned int ct = 0; ct < listActions.size(); ++ct)
	{
		if(listActions.at(ct)->isSeparator())
		{
			break;
		}
		menuOpen_Recent->removeAction(listActions.at(ct));
		delete listActions.at(ct);
	}
}

void MainWindow::renderingWidgetGotFocus(QWidget* renderingWidget)
{
	std::list< std::pair< RenderingWidget*, QWidget* > >::iterator iterRendererSettings = listRendererSettings.begin();
	while(iterRendererSettings != listRendererSettings.end())
	{
		if(iterRendererSettings->first == renderingWidget)
		{
			settingsWidgetStack->setCurrentWidget(iterRendererSettings->second);
			break;
		}
		++iterRendererSettings;
	}
}

void MainWindow::on_actionPerlin_Noise_Volume_triggered()
{	
	THERMITE_LOG_DEBUG << "Generating perlin volume";
	PerlinNoiseSettingsDialog perlinNoiseSettingsDialog(this);	
	perlinNoiseSettingsDialog.exec();
}

void MainWindow::on_actionExtract_Mesh_triggered()
{
	THERMITE_LOG_DEBUG << "Extracting Mesh";

	//Identify which volume is selected...	
	if(volumeBrowser->hasSelectedItem() == false)
	{
		QMessageBox::information(this, "Voxel Studio", "Please select a volume first");
		return;
	}

	ExtractIsosurfaceSettingsDialog extractIsosurfaceSettingsDialog(this);
	extractIsosurfaceSettingsDialog.exec();
}

void MainWindow::on_actionGenerate_Resampled_Volume_triggered()
{
	THERMITE_LOG_DEBUG << "Resampling Volume";

	//Identify which volume is selected...
	QString selectedVolume = volumeBrowser->getSelectedVolume();
	if(volumeBrowser->hasSelectedItem() == false)
	{
		QMessageBox::information(this, "Voxel Studio", "Please select a volume first");
		return;
	}

	ResampledVolumeSettingsDialog resampledVolumeSettingsDialog(this);
	resampledVolumeSettingsDialog.exec();	
}

void MainWindow::on_actionGenerate_Subvolume_triggered()
{
	THERMITE_LOG_DEBUG << "Generating Subvolume";
	//Identify which volume is selected...
	if(volumeBrowser->hasSelectedItem() == false)
	{
		QMessageBox::information(this, "Voxel Studio", "Please select a volume first");
		return;
	}
	SubvolumeSettingsDialog subvolumeSettingsDialog(this);
	subvolumeSettingsDialog.exec();
}

void MainWindow::on_actionGenerate_Filtered_Volume_triggered()
{
	THERMITE_LOG_DEBUG << "Filtering Volume";

	//Identify which volume is selected...
	QString selectedVolume = volumeBrowser->getSelectedVolume();
	if(volumeBrowser->hasSelectedItem() == false)
	{
		QMessageBox::information(this, "Voxel Studio", "Please select a volume first");
		return;
	}

	FilterSettingsDialog filterSettingsDialog(this);
	filterSettingsDialog.exec();
}

void MainWindow::addVolume(QString volumeNameString, Thermite::Volume<Thermite::uint2>* pVolume)
{
	m_nameVolumeMap[volumeNameString] = pVolume;

	volumeBrowser->addVolume(volumeNameString);
	volumeBrowser->selectVolume(volumeNameString);
}

void MainWindow::removeVolume(QString volumeNameString)
{
	m_nameVolumeMap.remove(volumeNameString);
	volumeBrowser->removeVolume(volumeNameString);
}

QString MainWindow::getSelectedVolume(void)
{
	return volumeBrowser->getSelectedVolume();
}

Thermite::Volume<Thermite::uint2>* MainWindow::getVolumeByName(QString nameString)
{
	return m_nameVolumeMap[nameString];
}