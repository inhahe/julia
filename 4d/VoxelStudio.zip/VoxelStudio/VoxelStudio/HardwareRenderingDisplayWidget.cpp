#include "HardwareRenderer.hpp"
#include "MarchingCubesEndoscopyRenderer.hpp"

#include <QtGui/QKeyEvent>
#include <QtGui/QMouseEvent>

#include "HardwareRenderingDisplayWidget.h"

using namespace Thermite; 

HardwareRenderingDisplayWidget::HardwareRenderingDisplayWidget(HardwareRenderer* pRenderer, QWidget *parent)
: QGLWidget(parent)
,RenderingDisplayWidget(pRenderer)
{
	setFocusPolicy(Qt::StrongFocus);
}

void HardwareRenderingDisplayWidget::initializeGL()
{
	m_pRenderer->initialise();
}

void HardwareRenderingDisplayWidget::resizeGL(int w, int h)
{
	glViewport(0,0,w,h);

	m_pRenderer->setSize(w,h);
	m_pRenderer->camera().setExtents(w/2.0,h/2.0,1024.0);	
}

void HardwareRenderingDisplayWidget::paintGL()
{
	m_pRenderer->render();
}

void HardwareRenderingDisplayWidget::mousePressEvent(QMouseEvent* event)
{
	mousePressEventHandler(event);
}
void HardwareRenderingDisplayWidget::mouseMoveEvent(QMouseEvent* event)
{
	mouseMoveEventHandler(event);
	updateGL();
}
void HardwareRenderingDisplayWidget::keyPressEvent(QKeyEvent* event)
{
	//THERMITE_LOG_DEBUG << "Got key press";
	if(event->key() == Qt::Key_Space) //FIXME - this is a hack!
	{
		//THERMITE_LOG_DEBUG << "Got space";
		MarchingCubesEndoscopyRenderer<uint2> *pMarchingCubesEndoscopyRenderer;
		pMarchingCubesEndoscopyRenderer = dynamic_cast<MarchingCubesEndoscopyRenderer<uint2>*>(m_pRenderer);
		if(pMarchingCubesEndoscopyRenderer)
		{
			//THERMITE_LOG_DEBUG << pMarchingCubesEndoscopyRenderer->getObjectSpacePosition(m_iOldX, m_iOldY);
			Vector3DDouble pos = pMarchingCubesEndoscopyRenderer->getObjectSpacePosition(m_iOldX, m_iOldY);
			Vector3DUint4 posAsInt = static_cast<Vector3DUint4>(pos);
			for(uint4 z = posAsInt.z()-12; z < posAsInt.z() + 12; z++)
			{
				for(uint4 y = posAsInt.y()-12; y < posAsInt.y() + 12; y++)
				{
					for(uint4 x = posAsInt.x()-12; x < posAsInt.x() + 12; x++)
					{
						double dXDist = static_cast<double>(x) - static_cast<double>(posAsInt.x());
						double dYDist = static_cast<double>(y) - static_cast<double>(posAsInt.y());
						double dZDist = static_cast<double>(z) - static_cast<double>(posAsInt.z());

						double dDist = sqrt(dXDist*dXDist+dYDist*dYDist+dZDist*dZDist);
						if(dDist <= 10)
						{
							const_cast<Volume<uint2>*>(pMarchingCubesEndoscopyRenderer->volume())->voxelAt(Vector3DUint4(x,y,z)) = 0;
						}
					}
				}
			}			
		}
	}
	keyPressEventHandler(event);
	updateGL();
}

void HardwareRenderingDisplayWidget::updateDisplayWidget(void)
{
	updateGL();
}