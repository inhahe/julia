#include "Logging.hpp"
#include "SoftwareRenderer.hpp"

#include <QtCore/QTime>
#include <QtGui/QPainter>
#include <QtGui/QResizeEvent>
#include <QtGui/QRgb>

#include "SoftwareRenderingDisplayWidget.h"

using namespace Thermite;

SoftwareRenderingDisplayWidget::SoftwareRenderingDisplayWidget(SoftwareRenderer* pRenderer, QWidget *parent)
:QWidget(parent)
,RenderingDisplayWidget(pRenderer)
{
	setFocusPolicy(Qt::StrongFocus);
}

SoftwareRenderingDisplayWidget::~SoftwareRenderingDisplayWidget()
{
}

void SoftwareRenderingDisplayWidget::paintEvent(QPaintEvent *event)
{
	SoftwareRenderer* pSoftwareRenderer = dynamic_cast<SoftwareRenderer*>(m_pRenderer);
	QPainter painter(this);
	painter.setRenderHint(QPainter::SmoothPixmapTransform);

	if(currentRes == LowResolution)
	{
		QTime time;
		time.start();
		pSoftwareRenderer->setSize(width()/4,height()/4);
		pSoftwareRenderer->render();
		QImage lowResImage(pSoftwareRenderer->width(),pSoftwareRenderer->height(),QImage::Format_RGB32);
		for(uint4 y = 0; y < pSoftwareRenderer->height(); ++y)
		{
			for(uint4 x = 0; x < pSoftwareRenderer->width(); ++x)
			{
				uint1 red = pSoftwareRenderer->image().pixelAt(x,y).red();
				uint1 green = pSoftwareRenderer->image().pixelAt(x,y).green();
				uint1 blue = pSoftwareRenderer->image().pixelAt(x,y).blue();
				uint4 result = (0xff << 24) | ((red & 0xff) << 16) | ((green & 0xff) << 8) | (blue & 0xff);
				lowResImage.setPixel(x,y,result);
			}
		}
		QRect source(0,0,lowResImage.width(),lowResImage.height());
		QRect target(0,0,width(),height());
		painter.drawImage(target,lowResImage,source);
		THERMITE_LOG_DEBUG << "Rendered low res frame in " << time.elapsed() << "ms";
		if(changeCurrentRes(MediumResolution))
		{
			update();
		}
	}
	else if(currentRes == MediumResolution)
	{
		QTime time;
		time.start();
		pSoftwareRenderer->setSize(width()/2,height()/2);
		pSoftwareRenderer->render();
		QImage mediumResImage(pSoftwareRenderer->width(),pSoftwareRenderer->height(),QImage::Format_RGB32);
		for(uint4 y = 0; y < pSoftwareRenderer->height(); ++y)
		{
			for(uint4 x = 0; x < pSoftwareRenderer->width(); ++x)
			{
				uint1 red = pSoftwareRenderer->image().pixelAt(x,y).red();
				uint1 green = pSoftwareRenderer->image().pixelAt(x,y).green();
				uint1 blue = pSoftwareRenderer->image().pixelAt(x,y).blue();
				uint4 result = (0xff << 24) | ((red & 0xff) << 16) | ((green & 0xff) << 8) | (blue & 0xff);
				mediumResImage.setPixel(x,y,result);
			}
		}
		QRect source(0,0,mediumResImage.width(),mediumResImage.height());
		QRect target(0,0,width(),height());
		painter.drawImage(target,mediumResImage,source);
		THERMITE_LOG_DEBUG << "Rendered medium res frame in " << time.elapsed() << "ms";
		if(changeCurrentRes(HighResolution))
		{
			update();
		}
	}
	else
	{
		QTime time;
		time.start();
		pSoftwareRenderer->setSize(width(),height());
		pSoftwareRenderer->render();
		QImage highResImage(pSoftwareRenderer->width(),pSoftwareRenderer->height(),QImage::Format_RGB32);
		for(uint4 y = 0; y < pSoftwareRenderer->height(); ++y)
		{
			for(uint4 x = 0; x < pSoftwareRenderer->width(); ++x)
			{
				uint1 red = pSoftwareRenderer->image().pixelAt(x,y).red();
				uint1 green = pSoftwareRenderer->image().pixelAt(x,y).green();
				uint1 blue = pSoftwareRenderer->image().pixelAt(x,y).blue();
				uint4 result = (0xff << 24) | ((red & 0xff) << 16) | ((green & 0xff) << 8) | (blue & 0xff);
				highResImage.setPixel(x,y,result);
			}
		}
		QRect source(0,0,highResImage.width(),highResImage.height());
		QRect target(0,0,width(),height());
		painter.drawImage(target,highResImage,source);
		THERMITE_LOG_DEBUG << "Rendered high res frame in " << time.elapsed() << "ms";
		changeCurrentRes(LowResolution);
	}
}

void SoftwareRenderingDisplayWidget::resizeEvent(QResizeEvent * event)
{
	changeCurrentRes(LowResolution);

	m_pRenderer->setSize(event->size().width(),event->size().height());
	m_pRenderer->camera().setExtents(event->size().width(),event->size().height(),1024.0);
}

void SoftwareRenderingDisplayWidget::mousePressEvent(QMouseEvent* event)
{
	changeCurrentRes(LowResolution);
	mousePressEventHandler(event);
	//update();
}
void SoftwareRenderingDisplayWidget::mouseMoveEvent(QMouseEvent* event)
{
	changeCurrentRes(LowResolution);
	mouseMoveEventHandler(event);
	update();
}

void SoftwareRenderingDisplayWidget::keyPressEvent(QKeyEvent* event)
{
	changeCurrentRes(LowResolution);
	keyPressEventHandler(event);
	update();
}

void SoftwareRenderingDisplayWidget::updateDisplayWidget(void)
{
	update();
}