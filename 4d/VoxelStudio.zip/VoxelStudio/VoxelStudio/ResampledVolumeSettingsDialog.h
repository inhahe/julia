#ifndef RESAMPLED_VOLUME_SETTINGS_DIALOG_H
#define RESAMPLED_VOLUME_SETTINGS_DIALOG_H

#include "ui_ResampledVolumeSettingsDialog.h"

class ResampledVolumeSettingsDialog : public QDialog, private Ui::ResampledVolumeSettingsDialog
{
	Q_OBJECT
public:
	ResampledVolumeSettingsDialog(QWidget *parent = 0);	

private:
	void generateResampledVolume(void);
	static int m_iResampledVolumeCounter;

private slots:
	void on_okButton_clicked();
};

#endif