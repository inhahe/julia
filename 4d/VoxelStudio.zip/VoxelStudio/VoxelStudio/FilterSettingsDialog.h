#ifndef FILTER_SETTINGS_DIALOG_H
#define FILTER_SETTINGS_DIALOG_H

#include "ui_FilterSettingsDialog.h"

class FilterSettingsDialog : public QDialog, private Ui::FilterSettingsDialog
{
	Q_OBJECT
public:
	FilterSettingsDialog(QWidget *parent = 0);	

private:
	void generateFilteredVolume(void);
	static int m_iFilteredVolumeCounter;

private slots:
	void on_okButton_clicked();
};

#endif