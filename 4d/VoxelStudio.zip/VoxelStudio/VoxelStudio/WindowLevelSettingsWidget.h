#ifndef WINDOWLEVELSETTINGSWIDGET_H
#define WINDOWLEVELSETTINGSWIDGET_H

#include "ui_WindowLevelSettingsWidget.h"

class WindowLevelSettingsWidget : public QWidget, private Ui::WindowLevelSettingsWidget
{
	Q_OBJECT
public:
	WindowLevelSettingsWidget(QWidget *parent = 0);

	void setMinimumWindow(int minimum);
	void setMaximumWindow(int maximum);
	void setWindow(int value);
	void setMinimumLevel(int minimum);
	void setMaximumLevel(int maximum);
	void setLevel(int value);

signals:
	void windowChanged(int newValue);
	void levelChanged(int newValue);

private slots:
	void on_sliderWindow_valueChanged(int value);
	void on_sliderLevel_valueChanged(int value);

};

#endif