#ifndef SLICESETTINGSWIDGET_H
#define SLICESETTINGSWIDGET_H

#include "FwdDecl.hpp"
#include "Typedef.hpp"

#include "ui_SliceSettingsWidget.h"

class SliceSettingsWidget : public QWidget, private Ui::SliceSettingsWidget
{
	Q_OBJECT
public:
	SliceSettingsWidget(Thermite::SliceRenderer<Thermite::uint2>* pSliceRenderer, QWidget *parent = 0);

	void setInitialValues(void);

signals:
	void updateRequired(void);

protected:
	Thermite::SliceRenderer<Thermite::uint2>* m_pSliceRenderer;

private slots:
	void on_windowLevelSettingsWidget_windowChanged(int value);
	void on_windowLevelSettingsWidget_levelChanged(int value);
	void on_checkBoxIsosurfaceEnabled_toggled(bool value);
	void on_isosurfaceSettingsWidget_isovalueChanged(double value);
	void on_isosurfaceSettingsWidget_isosurfaceColourChanged(QColor color);
	void on_radioButtonTrilinear_toggled(bool checked);
	void on_radioButtonCatmullRom_toggled(bool checked);
};

#endif