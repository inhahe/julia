#ifndef RENDER_RESOUTION_H
#define RENDER_RESOUTION_H

enum RenderResolution
{
	LowResolution,
	MediumResolution,
	HighResolution
};

#endif;