#ifndef MARCHINGCUBESSETTINGSWIDGET_H
#define MARCHINGCUBESSETTINGSWIDGET_H

#include "FwdDecl.hpp"
#include "Typedef.hpp"

#include "ui_MarchingCubesSettingsWidget.h"

class MarchingCubesSettingsWidget : public QWidget, private Ui::MarchingCubesSettingsWidget
{
	Q_OBJECT
public:
	MarchingCubesSettingsWidget(Thermite::MarchingCubesRenderer<Thermite::uint2>* pMarchingCubesRenderer, QWidget *parent = 0);

	void setInitialValues(void);

signals:
	void updateRequired(void);

protected:
	Thermite::MarchingCubesRenderer<Thermite::uint2>* m_pMarchingCubesRenderer;

private slots:
	void on_niceInterpolationCheckBox_toggled(bool value);
	void on_isosurfaceSettingsWidget_isovalueChanged(double value);
	void on_isosurfaceSettingsWidget_isosurfaceColourChanged(QColor color);
};

#endif