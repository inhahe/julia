#include <QtGui/QColorDialog>

#include "IsosurfaceSettingsWidget.h"

IsosurfaceSettingsWidget::IsosurfaceSettingsWidget(QWidget *parent)
: QWidget(parent)
{
	setupUi(this);
}

void IsosurfaceSettingsWidget::setIsovalue(int value)
{
	doubleSpinBoxIsovalue->setValue(value);
}

void IsosurfaceSettingsWidget::setIsosurfaceColour(QColor colour)
{
	//Set the icon on the button to match
	QPixmap pixmap(32,32);
	pixmap.fill(colour);
	QIcon icon(pixmap);
	pushButtonChangeColour->setIcon(icon);

	emit isosurfaceColourChanged(colour);
}

void IsosurfaceSettingsWidget::on_doubleSpinBoxIsovalue_valueChanged(double value)
{
	emit isovalueChanged(value);
}

void IsosurfaceSettingsWidget::on_pushButtonChangeColour_clicked(bool checked)
{
	//Get the colour
	QColor chosenColour = QColorDialog::getColor();

	//Set the icon on the button to match
	QPixmap pixmap(32,32);
	pixmap.fill(chosenColour);
	QIcon icon(pixmap);
	pushButtonChangeColour->setIcon(icon);

	emit isosurfaceColourChanged(chosenColour);
}