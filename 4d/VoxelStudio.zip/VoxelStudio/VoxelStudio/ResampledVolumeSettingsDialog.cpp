#include "LinearVolume.hpp"
#include "VolumeGenerator.hpp"

#include "MainWindow.h"
#include "ResampledVolumeSettingsDialog.h"
#include "ProgressBarCallback.h"

#include <QtGui/QMessageBox>
#include <QtGui/QProgressDialog>

int ResampledVolumeSettingsDialog::m_iResampledVolumeCounter = 1;

using namespace Thermite;

ResampledVolumeSettingsDialog::ResampledVolumeSettingsDialog(QWidget *parent)
: QDialog(parent)
{
	setupUi(this);

	MainWindow* pMainWindow = dynamic_cast<MainWindow*>(parent);
	if(!pMainWindow)
	{
		THERMITE_LOG_ERROR << "Could not convert parent() to MainWindow*";
		return;
	}
	QString selectedVolume = pMainWindow->getSelectedVolume();
	Volume<uint2>* pVolume = pMainWindow->getVolumeByName(selectedVolume);	

	widthSpinBox->setValue(pVolume->width());
	heightSpinBox->setValue(pVolume->height());
	depthSpinBox->setValue(pVolume->depth());
}

void ResampledVolumeSettingsDialog::on_okButton_clicked()
{
	generateResampledVolume();
	accept();
}

void ResampledVolumeSettingsDialog::generateResampledVolume(void)
{
	MainWindow* pMainWindow = dynamic_cast<MainWindow*>(parent());
	if(!pMainWindow)
	{
		THERMITE_LOG_ERROR << "Could not convert parent() to MainWindow*";
		return;
	}
	QString selectedVolume = pMainWindow->getSelectedVolume();
	Volume<uint2>* pVolume = pMainWindow->getVolumeByName(selectedVolume);

	QProgressDialog progressDialog("Generating Subvolume...",0,0,1000);
	ProgressBarCallback progressBarCallback(&progressDialog);

	Volume<uint2>* pResampledVolume = VolumeGenerator< uint2, LinearVolume<uint2> >::generateResampledVolume
	(
		*(dynamic_cast<LinearVolume<uint2>*>(pVolume)),
		widthSpinBox->value(),
		heightSpinBox->value(),
		depthSpinBox->value(),
		progressBarCallback
	);

	QString strVolumeName("Resampled Volume " + QString::number(m_iResampledVolumeCounter));
	m_iResampledVolumeCounter++;
	pMainWindow->addVolume(strVolumeName,pResampledVolume);
	//pResampledVolume->exportDAT("c:\\temp.dat");
	//pResampledVolume->exportDAT("c:\\temp\\ship_output.dat");
}
