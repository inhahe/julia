#ifndef PROGRESSBARCALLBACK_H
#define PROGRESSBARCALLBACK_H

class QProgressDialog;

class ProgressBarCallback
{
public:
	ProgressBarCallback(QProgressDialog* pProgressDialog);

	void operator()(std::string text, double value);
private:
	QProgressDialog* m_pProgressDialog;
};

#endif