#include "MarchingCubesRenderer.hpp"

#include "MarchingCubesSettingsWidget.h"
#include "RenderingWidget.h"

using namespace Thermite;

MarchingCubesSettingsWidget::MarchingCubesSettingsWidget(Thermite::MarchingCubesRenderer<Thermite::uint2>* pMarchingCubesRenderer, QWidget *parent)
: QWidget(parent)
,m_pMarchingCubesRenderer(pMarchingCubesRenderer)
{
	setupUi(this);
}

void MarchingCubesSettingsWidget::setInitialValues(void)
{
	uint2 minVoxel = m_pMarchingCubesRenderer->volume()->minimum();
	uint2 maxVoxel = m_pMarchingCubesRenderer->volume()->maximum();
	uint2 voxelRange = maxVoxel - minVoxel;

	isosurfaceSettingsWidget->setIsovalue(minVoxel + (voxelRange/2));
	isosurfaceSettingsWidget->setIsosurfaceColour(QColor(0,0,255));
}

void MarchingCubesSettingsWidget::on_isosurfaceSettingsWidget_isovalueChanged(double value)
{
	m_pMarchingCubesRenderer->setIsovalue(value);
	emit updateRequired();
}

void MarchingCubesSettingsWidget::on_isosurfaceSettingsWidget_isosurfaceColourChanged(QColor colour)
{
	m_pMarchingCubesRenderer->setIsosurfaceColour(RGBA<uint1>(colour.red(),colour.green(),colour.blue(),255));
	emit updateRequired();
}

void MarchingCubesSettingsWidget:: on_niceInterpolationCheckBox_toggled(bool value)
{
	m_pMarchingCubesRenderer->setUseNiceInterpolation(value);
	emit updateRequired();
}