#ifndef IPSETTINGSWIDGET_H
#define IPSETTINGSWIDGET_H

#include "FwdDecl.hpp"
#include "Typedef.hpp"

#include "ui_IPSettingsWidget.h"

class IPSettingsWidget : public QWidget, private Ui::IPSettingsWidget
{
	Q_OBJECT
public:
	IPSettingsWidget(Thermite::IPRenderer<Thermite::uint2>* pIPRenderer, QWidget *parent = 0);

	void setInitialValues(void);

signals:
	void updateRequired(void);

protected:
	Thermite::IPRenderer<Thermite::uint2>* m_pIPRenderer;

private slots:
	void on_doubleSpinBoxBrightness_valueChanged(double value);
	void on_windowLevelSettingsWidget_windowChanged(int value);
	void on_windowLevelSettingsWidget_levelChanged(int value);
};

#endif