#include "GeneralRendererSettingsWidget.h"
#include "RenderingWidget.h"

GeneralRendererSettingsWidget::GeneralRendererSettingsWidget(QWidget *parent)
: QWidget(parent)
{
	setupUi(this);
}

void GeneralRendererSettingsWidget::setMaxRes(RenderResolution res)
{
	switch(res)
	{
	case HighResolution:
		{
			radioButtonMaxResHigh->setChecked(true);
			break;
		}
	case MediumResolution:
		{
			radioButtonMaxResMedium->setChecked(true);
			break;
		}
	case LowResolution:
		{
			radioButtonMaxResLow->setChecked(true);
			break;
		}
	}
}
void GeneralRendererSettingsWidget::setMinRes(RenderResolution res)
{
	switch(res)
	{
	case HighResolution:
		{
			radioButtonMinResHigh->setChecked(true);
			break;
		}
	case MediumResolution:
		{
			radioButtonMinResMedium->setChecked(true);
			break;
		}
	case LowResolution:
		{
			radioButtonMinResLow->setChecked(true);
			break;
		}
	}
}

void GeneralRendererSettingsWidget::setZoom(double zoom)
{
	doubleSpinBoxZoom->setValue(zoom);
}

void GeneralRendererSettingsWidget::on_radioButtonMaxResHigh_toggled(bool checked)
{
	if(checked)
	{
		emit maxResChanged(HighResolution);
	}
}

void GeneralRendererSettingsWidget::on_radioButtonMaxResMedium_toggled(bool checked)
{
	if(checked)
	{
		emit maxResChanged(MediumResolution);
	}
}

void GeneralRendererSettingsWidget::on_radioButtonMaxResLow_toggled(bool checked)
{
	if(checked)
	{
		emit maxResChanged(LowResolution);
	}
}

void GeneralRendererSettingsWidget::on_radioButtonMinResHigh_toggled(bool checked)
{
	if(checked)
	{
		emit minResChanged(HighResolution);
	}
}

void GeneralRendererSettingsWidget::on_radioButtonMinResMedium_toggled(bool checked)
{
	if(checked)
	{
		emit minResChanged(MediumResolution);
	}
}

void GeneralRendererSettingsWidget::on_radioButtonMinResLow_toggled(bool checked)
{
	if(checked)
	{
		emit minResChanged(LowResolution);
	}
}

void GeneralRendererSettingsWidget::on_doubleSpinBoxZoom_valueChanged(double value)
{
	emit zoomChanged(value);
}