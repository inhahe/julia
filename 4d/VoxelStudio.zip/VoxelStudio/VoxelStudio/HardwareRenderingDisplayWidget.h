#ifndef HARDWARE_RENDERING_DISPLAY_WIDGET_H
#define HARDWARE_RENDERING_DISPLAY_WIDGET_H

#include "FwdDecl.hpp"

#include <QtOpenGL/QGLWidget>

#include "RenderingDisplayWidget.h"


class HardwareRenderingDisplayWidget : public QGLWidget, public RenderingDisplayWidget
{

public:
	HardwareRenderingDisplayWidget(Thermite::HardwareRenderer* pRenderer, QWidget *parent = 0);

	void updateDisplayWidget(void);

protected:
	void initializeGL();
	void resizeGL(int w, int h);
	void paintGL();

	void mousePressEvent(QMouseEvent* event);
	void mouseMoveEvent(QMouseEvent* event);
	void keyPressEvent(QKeyEvent* event);

//private:
	//Thermite::HardwareRenderer* m_pRenderer;
};

#endif