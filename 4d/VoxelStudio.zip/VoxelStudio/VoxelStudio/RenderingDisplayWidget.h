#ifndef RENDERING_DISPLAY_WIDGET_H
#define RENDERING_DISPLAY_WIDGET_H

#include "FwdDecl.hpp"
#include "Typedef.hpp"

#include "RenderResolution.h"

class QKeyEvent;
class QMouseEvent;

class RenderingDisplayWidget
{
public:
	RenderingDisplayWidget(Thermite::Renderer* pRenderer);
	virtual ~RenderingDisplayWidget();

	void setMaxRes(RenderResolution res);
	void setMinRes(RenderResolution res);
	bool changeCurrentRes(RenderResolution res);

	virtual void updateDisplayWidget(void) = 0;

protected:
	void mousePressEventHandler(QMouseEvent* event);
	void mouseMoveEventHandler(QMouseEvent* event);
	void keyPressEventHandler(QKeyEvent* event);	

	RenderResolution currentRes;
	RenderResolution maxRes;
	RenderResolution minRes;
	
	Thermite::Renderer* m_pRenderer;

//private: //FIXME - this should be private but was changed as a hack...
	int m_iOldX;
	int m_iOldY;	
};

#endif