#ifndef EXTRACT_ISOSURFACE_SETTINGS_DIALOG_H
#define EXTRACT_ISOSURFACE_SETTINGS_DIALOG_H

#include "ui_ExtractIsosurfaceSettingsDialog.h"

class ExtractIsosurfaceSettingsDialog : public QDialog, private Ui::ExtractIsosurfaceSettingsDialog
{
	Q_OBJECT
public:
	ExtractIsosurfaceSettingsDialog(QWidget *parent = 0);

private:
	void extractIsosurfaceAsMesh(void);

private slots:
	void on_okButton_clicked();
};

#endif