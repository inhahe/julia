#include "LinearVolume.hpp"
#include "VolumeGenerator.hpp"

#include "MainWindow.h"
#include "SubvolumeSettingsDialog.h"
#include "ProgressBarCallback.h"

#include <QtGui/QMessageBox>
#include <QtGui/QProgressDialog>

int SubvolumeSettingsDialog::m_iSubvolumeCounter = 1;

using namespace Thermite;

SubvolumeSettingsDialog::SubvolumeSettingsDialog(QWidget *parent)
: QDialog(parent)
{
	setupUi(this);

	MainWindow* pMainWindow = dynamic_cast<MainWindow*>(parent);
	if(!pMainWindow)
	{
		THERMITE_LOG_ERROR << "Could not convert parent() to MainWindow*";
		return;
	}
	QString selectedVolume = pMainWindow->getSelectedVolume();
	Volume<uint2>* pVolume = pMainWindow->getVolumeByName(selectedVolume);	

	minXSpinBox->setMaximum(pVolume->width()-2);
	minYSpinBox->setMaximum(pVolume->height()-2);
	minZSpinBox->setMaximum(pVolume->depth()-2);

	maxXSpinBox->setMaximum(pVolume->width()-1);
	maxYSpinBox->setMaximum(pVolume->height()-1);
	maxZSpinBox->setMaximum(pVolume->depth()-1);

	maxXSpinBox->setValue(pVolume->width()-1);
	maxYSpinBox->setValue(pVolume->height()-1);
	maxZSpinBox->setValue(pVolume->depth()-1);
}

void SubvolumeSettingsDialog::on_okButton_clicked()
{
	if ((maxXSpinBox->value() <= minXSpinBox->value()) || (maxYSpinBox->value() <= minYSpinBox->value()) || (maxZSpinBox->value() <= minZSpinBox->value()))
	{
		QMessageBox::information(this, "Voxel Studio", "Maximum corner must be greater than minimum corner.");
		reject();
	}
	else
	{
		generateSubvolume();
		accept();		
	}
}

void SubvolumeSettingsDialog::generateSubvolume(void)
{
	MainWindow* pMainWindow = dynamic_cast<MainWindow*>(parent());
	if(!pMainWindow)
	{
		THERMITE_LOG_ERROR << "Could not convert parent() to MainWindow*";
		return;
	}
	QString selectedVolume = pMainWindow->getSelectedVolume();
	Volume<uint2>* pVolume = pMainWindow->getVolumeByName(selectedVolume);

	QProgressDialog progressDialog("Generating Subvolume...",0,0,1000);
	ProgressBarCallback progressBarCallback(&progressDialog);

	Volume<uint2>* pSubvolume = VolumeGenerator< uint2, LinearVolume<uint2> >::generateSubVolume
	(
		*(dynamic_cast<LinearVolume<uint2>*>(pVolume)),
		Vector3DUint4(minXSpinBox->value(),minYSpinBox->value(),minZSpinBox->value()),
		Vector3DUint4(maxXSpinBox->value(),maxYSpinBox->value(),maxZSpinBox->value()),
		progressBarCallback
	);

	QString strVolumeName("Subvolume " + QString::number(m_iSubvolumeCounter));
	m_iSubvolumeCounter++;
	pMainWindow->addVolume(strVolumeName,pSubvolume);
}
