#ifndef ISOSURFACESETTINGSWIDGET_H
#define ISOSURFACESETTINGSWIDGET_H

#include "ui_IsosurfaceSettingsWidget.h"

class IsosurfaceSettingsWidget : public QWidget, private Ui::IsosurfaceSettingsWidget
{
	Q_OBJECT
public:
	IsosurfaceSettingsWidget(QWidget *parent = 0);

	void setIsovalue(int value);
	void setIsosurfaceColour(QColor colour);

signals:
	void isovalueChanged(double value);
	void isosurfaceColourChanged(QColor colour);

private slots:
	void on_doubleSpinBoxIsovalue_valueChanged(double value);
	void on_pushButtonChangeColour_clicked(bool checked);

};

#endif