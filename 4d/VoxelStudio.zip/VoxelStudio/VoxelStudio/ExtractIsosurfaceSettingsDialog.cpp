#include "LinearVolume.hpp"
#include "VolumeProcessor.hpp"

#include "MainWindow.h"
#include "ExtractIsosurfaceSettingsDialog.h"
#include "ProgressBarCallback.h"

#include <QtGui/QMessageBox>
#include <QtGui/QProgressDialog>

using namespace Thermite;

ExtractIsosurfaceSettingsDialog::ExtractIsosurfaceSettingsDialog(QWidget *parent)
: QDialog(parent)
{
	setupUi(this);	
}

void ExtractIsosurfaceSettingsDialog::on_okButton_clicked()
{
	extractIsosurfaceAsMesh();
	accept();	
}

void ExtractIsosurfaceSettingsDialog::extractIsosurfaceAsMesh(void)
{
	
	MainWindow* pMainWindow = dynamic_cast<MainWindow*>(parent());
	if(!pMainWindow)
	{
		THERMITE_LOG_ERROR << "Could not convert parent() to MainWindow*";
		return;
	}
	QString selectedVolume = pMainWindow->getSelectedVolume();
	THERMITE_LOG_DEBUG << "Volume name is " << selectedVolume.toStdString();
	//Extract the isosurfaces
	Volume<uint2>* pVolume = pMainWindow->getVolumeByName(selectedVolume);

	THERMITE_LOG_DEBUG << "Got volume";

	QProgressDialog progressDialog("Extracting isosurface as mesh...",0,0,1000);
	ProgressBarCallback progressBarCallback(&progressDialog);

	std::vector< std::vector< Vector3DDouble > > triangles = VolumeProcessor<uint2>::extractMeshForIsosurface(pVolume, isovalueSpinBox->value(), progressBarCallback);
	std::ofstream myfile;
	myfile.open ("c:\\test.obj");
	//Print the vertices    
	std::vector< std::vector< Vector3DDouble > >::iterator trianglesIter = triangles.begin();
	int triangleCt= 0;
	while(trianglesIter != triangles.end())
	{
		std::vector< Vector3DDouble >::iterator triangleIter = trianglesIter->begin();
		while(triangleIter != trianglesIter->end())
		{
			myfile << "v " << triangleIter->x() << " " << triangleIter->y() << " " << triangleIter->z() << std::endl;
			++triangleIter;
		}
		++trianglesIter;
		++triangleCt;
		progressBarCallback("Writing vertices to disk...", static_cast<double>(triangleCt)/static_cast<double>(triangles.size()));
	}

	uint4 uNoOfVertices = triangles.size()* 3;
	uint4 ct = 1;
	while(ct < uNoOfVertices)
	{
		myfile << "f " << ct << " " << ct+1 << " " << ct+2 << std::endl;
		ct+=3;
		progressBarCallback("Writing triangles to disk...", static_cast<double>(ct)/static_cast<double>(uNoOfVertices));
	}

	myfile.close();
}
