#ifndef SOFTWARE_RENDERING_DISPLAY_WIDGET_H
#define SOFTWARE_RENDERING_DISPLAY_WIDGET_H

#include "RenderingDisplayWidget.h"

#include <QtGui/QWidget>

class SoftwareRenderingDisplayWidget : public QWidget, public RenderingDisplayWidget
{
    Q_OBJECT
	
public:
	SoftwareRenderingDisplayWidget(Thermite::SoftwareRenderer* pRenderer, QWidget *parent = 0);
	~SoftwareRenderingDisplayWidget();	

	void updateDisplayWidget(void);

protected:
	void paintEvent(QPaintEvent *event);
	void resizeEvent(QResizeEvent * event);

	void mousePressEvent(QMouseEvent* event);
	void mouseMoveEvent(QMouseEvent* event);
	void keyPressEvent(QKeyEvent* event);	
};

#endif