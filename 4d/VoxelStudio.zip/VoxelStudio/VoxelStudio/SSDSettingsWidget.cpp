#include "ShadedSurfaceRenderer.hpp"

#include "SSDSettingsWidget.h"
#include "RenderingWidget.h"

using namespace Thermite;

SSDSettingsWidget::SSDSettingsWidget(Thermite::ShadedSurfaceRenderer<Thermite::uint2>* pSSDRenderer, QWidget *parent)
: QWidget(parent)
,m_pSSDRenderer(pSSDRenderer)
{
	setupUi(this);
}

void SSDSettingsWidget::setInitialValues(void)
{
	uint2 minVoxel = m_pSSDRenderer->volume()->minimum();
	uint2 maxVoxel = m_pSSDRenderer->volume()->maximum();
	uint2 voxelRange = maxVoxel - minVoxel;

	isosurfaceSettingsWidget->setIsovalue(minVoxel + (voxelRange/2));
	isosurfaceSettingsWidget->setIsosurfaceColour(QColor(0,0,255));
}

void SSDSettingsWidget::on_isosurfaceSettingsWidget_isovalueChanged(double value)
{
	m_pSSDRenderer->setIsovalue(value);
	emit updateRequired();
}

void SSDSettingsWidget::on_isosurfaceSettingsWidget_isosurfaceColourChanged(QColor colour)
{
	m_pSSDRenderer->setIsosurfaceColour(RGBA<uint1>(colour.red(),colour.green(),colour.blue(),255));
	emit updateRequired();
}