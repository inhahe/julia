#include "IPRenderer.hpp"

#include "IPSettingsWidget.h"
#include "RenderingWidget.h"

using namespace Thermite;

IPSettingsWidget::IPSettingsWidget(IPRenderer<uint2>* pIPRenderer, QWidget *parent)
: QWidget(parent)
{
	setupUi(this);

	m_pIPRenderer = pIPRenderer;
}

void IPSettingsWidget::setInitialValues(void)
{
	uint2 minVoxel = m_pIPRenderer->volume()->minimum();
	uint2 maxVoxel = m_pIPRenderer->volume()->maximum();
	uint2 voxelRange = maxVoxel - minVoxel;

	windowLevelSettingsWidget->setMinimumWindow(0);
	windowLevelSettingsWidget->setMaximumWindow(voxelRange);
	windowLevelSettingsWidget->setWindow(voxelRange);

	windowLevelSettingsWidget->setMinimumLevel(minVoxel);
	windowLevelSettingsWidget->setMaximumLevel(maxVoxel);
	windowLevelSettingsWidget->setLevel(minVoxel + (voxelRange/2)); 
}

void IPSettingsWidget::on_doubleSpinBoxBrightness_valueChanged(double value)
{
	m_pIPRenderer->setBrightness(value);
	emit updateRequired();
}

void IPSettingsWidget::on_windowLevelSettingsWidget_windowChanged(int value)
{
	m_pIPRenderer->setWindow(value);
	emit updateRequired();
} 

void IPSettingsWidget::on_windowLevelSettingsWidget_levelChanged(int value)
{
	m_pIPRenderer->setLevel(value);
	emit updateRequired();
} 