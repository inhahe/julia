#include "HardwareRenderer.hpp"
#include "SoftwareRenderer.hpp"

#include "RenderingWidget.h"
#include "HardwareRenderingDisplayWidget.h"
#include "SoftwareRenderingDisplayWidget.h"

using namespace Thermite;

RenderingWidget::RenderingWidget(Renderer* pRenderer, QWidget *parent)
: QWidget(parent)
,m_pRenderer(pRenderer)
{
	setupUi(this);

	QWidget* pWidget;

	if(dynamic_cast<SoftwareRenderer*>(m_pRenderer))
	{
		SoftwareRenderingDisplayWidget* pSoftwareRenderingDisplayWidget = new SoftwareRenderingDisplayWidget(dynamic_cast<SoftwareRenderer*>(m_pRenderer),this);
		pWidget = pSoftwareRenderingDisplayWidget;
		m_pDisplayWidget = pSoftwareRenderingDisplayWidget;		
	}	
	else if(dynamic_cast<HardwareRenderer*>(m_pRenderer))
	{
		HardwareRenderingDisplayWidget* pHardwareRenderingDisplayWidget = new HardwareRenderingDisplayWidget(dynamic_cast<HardwareRenderer*>(m_pRenderer),this);
		pWidget = pHardwareRenderingDisplayWidget;
		m_pDisplayWidget = pHardwareRenderingDisplayWidget;
	}	
	else
	{
		THERMITE_LOG_ERROR << "Failed to determine renderer type.";
		return;
	}

	QSizePolicy sizePolicy = pWidget->sizePolicy();
	sizePolicy.setVerticalPolicy(QSizePolicy::Expanding);
	pWidget->setSizePolicy(sizePolicy);

	vboxLayout->insertWidget(0,pWidget);

	//Set initial values
	generalRendererSettingsWidget->setMinRes(LowResolution);
	generalRendererSettingsWidget->setMaxRes(HighResolution);
	generalRendererSettingsWidget->setZoom(1.0);
}

Thermite::Renderer* RenderingWidget::renderer()
{
	return m_pRenderer;
}

void RenderingWidget::setMaxRes(RenderResolution res)
{
	generalRendererSettingsWidget->setMaxRes(res);
}

void RenderingWidget::setMinRes(RenderResolution res)
{
	generalRendererSettingsWidget->setMinRes(res);
}

void RenderingWidget::update(void)
{
	m_pDisplayWidget->updateDisplayWidget();
}

void RenderingWidget::on_generalRendererSettingsWidget_maxResChanged(RenderResolution res)
{
	m_pDisplayWidget->setMaxRes(res);
	update();
}

void RenderingWidget::on_generalRendererSettingsWidget_minResChanged(RenderResolution res)
{
	m_pDisplayWidget->setMinRes(res);
	update();
}

void RenderingWidget::on_generalRendererSettingsWidget_zoomChanged(double value)
{
	m_pRenderer->camera().setWidth(dynamic_cast<QWidget*>(m_pDisplayWidget)->width() / value);
	m_pRenderer->camera().setHeight(dynamic_cast<QWidget*>(m_pDisplayWidget)->height() / value);
	update();
}