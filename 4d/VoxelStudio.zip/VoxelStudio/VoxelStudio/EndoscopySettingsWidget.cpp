#include "EndoscopyRenderer.hpp"

#include "EndoscopySettingsWidget.h"
#include "RenderingWidget.h"

using namespace Thermite;

EndoscopySettingsWidget::EndoscopySettingsWidget(EndoscopyRenderer<uint2>* pEndoscopyRenderer, QWidget *parent)
: QWidget(parent)
,m_pEndoscopyRenderer(pEndoscopyRenderer)
{
	setupUi(this);
}

void EndoscopySettingsWidget::setInitialValues(void)
{
	//Now set up the appropriate initial values.
	uint2 minVoxel = m_pEndoscopyRenderer->volume()->minimum();
	uint2 maxVoxel = m_pEndoscopyRenderer->volume()->maximum();
	uint2 voxelRange = maxVoxel - minVoxel;

	doubleSpinBoxIsovalue->setValue(minVoxel + (voxelRange/10));
}