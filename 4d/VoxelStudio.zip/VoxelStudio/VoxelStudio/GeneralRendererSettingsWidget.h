#ifndef GENERALRENDERERSETTINGSWIDGET_H
#define GENERALRENDERERSETTINGSWIDGET_H

#include "ui_GeneralRendererSettingsWidget.h"

#include "RenderResolution.h"

class GeneralRendererSettingsWidget : public QWidget, private Ui::GeneralRendererSettingsWidget
{
	Q_OBJECT
public:
	GeneralRendererSettingsWidget(QWidget *parent = 0);

	void setMaxRes(RenderResolution res);
	void setMinRes(RenderResolution res);
	void setZoom(double zoom);

signals:
	void maxResChanged(RenderResolution newRes);
	void minResChanged(RenderResolution newRes);
	void zoomChanged(double newZoom);

private slots:
	void on_radioButtonMaxResHigh_toggled(bool checked);
	void on_radioButtonMaxResMedium_toggled(bool checked);
	void on_radioButtonMaxResLow_toggled(bool checked);

	void on_radioButtonMinResHigh_toggled(bool checked);
	void on_radioButtonMinResMedium_toggled(bool checked);
	void on_radioButtonMinResLow_toggled(bool checked);

	void on_doubleSpinBoxZoom_valueChanged(double value);
};

#endif