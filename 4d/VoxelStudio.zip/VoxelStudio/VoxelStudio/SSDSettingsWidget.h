#ifndef SSDSETTINGSWIDGET_H
#define SSDSETTINGSWIDGET_H

#include "FwdDecl.hpp"
#include "Typedef.hpp"

#include "ui_SSDSettingsWidget.h"

class SSDSettingsWidget : public QWidget, private Ui::SSDSettingsWidget
{
	Q_OBJECT
public:
	SSDSettingsWidget(Thermite::ShadedSurfaceRenderer<Thermite::uint2>* pSSDRenderer, QWidget *parent = 0);

	void setInitialValues(void);

signals:
	void updateRequired(void);

protected:
	Thermite::ShadedSurfaceRenderer<Thermite::uint2>* m_pSSDRenderer;

private slots:
	void on_isosurfaceSettingsWidget_isovalueChanged(double value);
	void on_isosurfaceSettingsWidget_isosurfaceColourChanged(QColor color);
};

#endif