#include "LinearVolume.hpp"
#include "VolumeGenerator.hpp"

#include "MainWindow.h"
#include "PerlinNoiseSettingsDialog.h"
#include "ProgressBarCallback.h"

#include <QtGui/QMessageBox>
#include <QtGui/QProgressDialog>

int PerlinNoiseSettingsDialog::m_iPerlinNoiseVolumeCounter = 1;

using namespace Thermite;

PerlinNoiseSettingsDialog::PerlinNoiseSettingsDialog(QWidget *parent)
: QDialog(parent)
{
	setupUi(this);
}

int PerlinNoiseSettingsDialog::volumeWidth(void)
{
	return widthSpinBox->value();
}

int PerlinNoiseSettingsDialog::volumeHeight(void)
{
	return heightSpinBox->value();
}

int PerlinNoiseSettingsDialog::volumeDepth(void)
{
	return depthSpinBox->value();
}

int PerlinNoiseSettingsDialog::minValue(void)
{
	return minValueSpinBox->value();
}

int PerlinNoiseSettingsDialog::maxValue(void)
{
	return maxValueSpinBox->value();
}

void PerlinNoiseSettingsDialog::on_okButton_clicked()
{
	if (maxValueSpinBox->value() <= minValueSpinBox->value())
	{
		QMessageBox::information(this, "Voxel Studio", "Maximum value must be greater than minimum value.");
		reject();
	}
	else
	{
		generatePerlinNoiseVolume();
		accept();		
	}
}

void PerlinNoiseSettingsDialog::generatePerlinNoiseVolume(void)
{
	LinearVolume<uint2>* pVolume = 0;
	try
	{
		QProgressDialog progressDialog("Generating Perlin Noise Volume...",0,0,1000);
		ProgressBarCallback progressBarCallback(&progressDialog);
		/*pVolume = VolumeGenerator<uint2, LinearVolume<uint2> >::generatePerlinNoiseVolume
			(
			volumeWidth(),
			volumeHeight(),
			volumeDepth(),
			minValue(),
			maxValue(),
			progressBarCallback
			);*/

		pVolume = VolumeGenerator<uint2, LinearVolume<uint2> >::generateLevelVolume
			(
			volumeWidth(),
			volumeHeight(),
			volumeDepth()
			);
	}
	catch (const std::bad_alloc& e)
	{
		QMessageBox::warning(this, "VoxelStudio", "Not enough memory to generate volume.");
		return;
	}

	QString strVolumeName("Perlin Noise Volume " + QString::number(m_iPerlinNoiseVolumeCounter));
	m_iPerlinNoiseVolumeCounter++;
	MainWindow* mainWindow = dynamic_cast<MainWindow*>(parent());
	mainWindow->addVolume(strVolumeName,pVolume);

	pVolume->exportDAT("c:\\temp.dat");
}
