#include <QtGui/QApplication>
#include <QtGui/QProgressDialog>

#include "ProgressBarCallback.h"

ProgressBarCallback::ProgressBarCallback(QProgressDialog* pProgressDialog)
:m_pProgressDialog(pProgressDialog)
{
	pProgressDialog->setAutoClose(false);
	pProgressDialog->setAutoReset(false);
}

void ProgressBarCallback::operator()(std::string text, double value)
{
	m_pProgressDialog->setLabelText(QString::fromStdString(text));
	m_pProgressDialog->setValue(static_cast<int>(value * 1000.0));	
	QApplication::processEvents();
}