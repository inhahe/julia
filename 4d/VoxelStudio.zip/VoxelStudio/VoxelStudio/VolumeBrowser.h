#ifndef VOLUMEBROWSER_H
#define VOLUMEBROWSER_H

#include "FwdDecl.hpp"
#include "Typedef.hpp"

#include "ui_VolumeBrowser.h"

class QAction;
class QMenu;

class VolumeBrowser : public QWidget, private Ui::VolumeBrowser
{
	Q_OBJECT
public:
	VolumeBrowser(QWidget *parent = 0);
	~VolumeBrowser();
	void addVolume(QString volumeNameString);
	void removeVolume(QString volumeNameString);
	QString getSelectedVolume();
	void selectVolume(QString volumeNameString);
	bool hasSelectedItem(void);
	void addActionToContextMenu(QAction* newAction);

protected:
	void contextMenuEvent(QContextMenuEvent *event);

private:
	QMenu* m_contextMenu;

};

#endif