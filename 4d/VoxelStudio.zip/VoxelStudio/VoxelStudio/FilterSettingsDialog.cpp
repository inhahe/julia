#include "LinearVolume.hpp"
#include "VolumeGenerator.hpp"

#include "MainWindow.h"
#include "FilterSettingsDialog.h"
#include "ProgressBarCallback.h"

#include <QtGui/QMessageBox>
#include <QtGui/QProgressDialog>

int FilterSettingsDialog::m_iFilteredVolumeCounter = 1;

using namespace Thermite;

FilterSettingsDialog::FilterSettingsDialog(QWidget *parent)
: QDialog(parent)
{
	setupUi(this);
}

void FilterSettingsDialog::on_okButton_clicked()
{	
	generateFilteredVolume();
	accept();
}

void FilterSettingsDialog::generateFilteredVolume(void)
{
	MainWindow* pMainWindow = dynamic_cast<MainWindow*>(parent());
	if(!pMainWindow)
	{
		THERMITE_LOG_ERROR << "Could not convert parent() to MainWindow*";
		return;
	}
	QString selectedVolume = pMainWindow->getSelectedVolume();
	Volume<uint2>* pVolume = pMainWindow->getVolumeByName(selectedVolume);

	QProgressDialog progressDialog("Generating Subvolume...",0,0,1000);
	ProgressBarCallback progressBarCallback(&progressDialog);

	Volume<uint2>* pFilteredVolume = VolumeGenerator< uint2, LinearVolume<uint2> >::generateFilteredVolume(*(dynamic_cast<LinearVolume<uint2>*>(pVolume)),progressBarCallback);

	QString strVolumeName("Filtered Volume " + QString::number(m_iFilteredVolumeCounter));
	m_iFilteredVolumeCounter++;
	pMainWindow->addVolume(strVolumeName,pFilteredVolume);

	pFilteredVolume->exportDAT("c:\\temp.dat");
}
