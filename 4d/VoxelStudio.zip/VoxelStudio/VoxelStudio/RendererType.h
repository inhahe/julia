#ifndef RENDERERTYPE_H
#define RENDERERTYPE_H

enum RendererType
{
	Slice,
	IP,
	SSD,
	Endoscopy,
	MarchingCubes,
	MarchingCubesEndoscopy
};

#endif