#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "FwdDecl.hpp"
#include "Typedef.hpp"

#include "ui_mainwindow.h"

#include "RendererType.h"

class QProgressDialog;
class QStackedWidget;
class QWorkspace;

class ProgressBarCallback;
class RenderingWidget;
class VolumeBrowser;

class MainWindow : public QMainWindow, private Ui::MainWindow
{
    Q_OBJECT
public:
    MainWindow(QWidget* parent = 0);

	void addVolume(QString volumeNameString, Thermite::Volume<Thermite::uint2>* pVolume);
	void removeVolume(QString volumeNameString);
	QString getSelectedVolume(void);
	Thermite::Volume<Thermite::uint2>* getVolumeByName(QString nameString);
	

protected:
	void closeEvent(QCloseEvent *event);
    
private:
	//Each entry holds the filename and a pointer to the data.
	QMap<QString, Thermite::Volume<Thermite::uint2>* > m_nameVolumeMap;
	QDockWidget* volumeBrowserDockWindow;
	QDockWidget* settingsEditorDockWindow;
	VolumeBrowser* volumeBrowser;
	QStackedWidget* settingsWidgetStack;
	QWorkspace* workspace;
	QString strLastViewedDirectory;

	int m_iPerlinNoiseVolumeCounter;
	int m_iResampledVolumeCounter;
	int m_iSubvolumeCounter;
	int m_iFilteredVolumeCounter;


	std::list< std::pair< RenderingWidget*, QWidget* > > listRendererSettings;

	void addRenderingWindow(RendererType type, int iWidth = 512, int iHeight = 512);
	void readSettings();
	void writeSettings();
	bool openFile(QString path);	

private slots:
	void on_actionOpen_triggered();
	void on_actionSave_As_triggered();
    void on_actionImport_triggered();
	void on_actionAdd_Slice_Renderer_triggered();
	void on_actionAdd_Endoscopy_Renderer_triggered();
	void on_actionAdd_IP_Renderer_triggered();	
	void on_actionAdd_SSD_Renderer_triggered();
	void on_actionAdd_Marching_Cubes_Renderer_triggered();
	void on_actionAdd_Marching_Cubes_Endoscopy_Renderer_triggered();
	void on_menuOpen_Recent_triggered(QAction* actActive);
	void on_actionClear_Recent_Files_List_triggered();
	void on_actionPerlin_Noise_Volume_triggered();
	void on_actionExtract_Mesh_triggered();
	void on_actionGenerate_Resampled_Volume_triggered();
	void on_actionGenerate_Subvolume_triggered();
	void on_actionGenerate_Filtered_Volume_triggered();

	void renderingWidgetGotFocus(QWidget* renderingWidget);
};

#endif