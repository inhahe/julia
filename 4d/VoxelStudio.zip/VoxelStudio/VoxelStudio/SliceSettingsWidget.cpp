#include "SliceRenderer.hpp"

#include "SliceSettingsWidget.h"
#include "RenderingWidget.h"

using namespace Thermite;

SliceSettingsWidget::SliceSettingsWidget(Thermite::SliceRenderer<Thermite::uint2>* pSliceRenderer, QWidget *parent)
: QWidget(parent)
,m_pSliceRenderer(pSliceRenderer)
{
	setupUi(this);	
}

void SliceSettingsWidget::setInitialValues(void)
{

	uint2 minVoxel = m_pSliceRenderer->volume()->minimum();
	uint2 maxVoxel = m_pSliceRenderer->volume()->maximum();
	uint2 voxelRange = maxVoxel - minVoxel;

	windowLevelSettingsWidget->setMinimumWindow(0);
	windowLevelSettingsWidget->setMaximumWindow(voxelRange);
	windowLevelSettingsWidget->setWindow(voxelRange);

	windowLevelSettingsWidget->setMinimumLevel(minVoxel);
	windowLevelSettingsWidget->setMaximumLevel(maxVoxel);
	windowLevelSettingsWidget->setLevel(minVoxel + (voxelRange/2));  

	isosurfaceSettingsWidget->setIsovalue(minVoxel + (voxelRange/10));
	isosurfaceSettingsWidget->setIsosurfaceColour(QColor(0,0,255));
	isosurfaceSettingsWidget->setEnabled(false);
}

void SliceSettingsWidget::on_windowLevelSettingsWidget_windowChanged(int value)
{
	m_pSliceRenderer->setWindow(value);
	emit updateRequired();
}   

void SliceSettingsWidget::on_windowLevelSettingsWidget_levelChanged(int value)
{
	m_pSliceRenderer->setLevel(value);
	emit updateRequired();
} 

void SliceSettingsWidget::on_checkBoxIsosurfaceEnabled_toggled(bool value)
{
	m_pSliceRenderer->setVolumeRenderingEnabled(value);
	emit updateRequired();
}

void SliceSettingsWidget::on_isosurfaceSettingsWidget_isovalueChanged(double value)
{
	m_pSliceRenderer->setIsovalue(value);
	emit updateRequired();
}

void SliceSettingsWidget::on_isosurfaceSettingsWidget_isosurfaceColourChanged(QColor colour)
{
	m_pSliceRenderer->setIsosurfaceColour(RGBA<uint1>(colour.red(),colour.green(),colour.blue(),255));
	emit updateRequired();
}

void SliceSettingsWidget::on_radioButtonTrilinear_toggled(bool checked)
{
	if(checked)
	{
		m_pSliceRenderer->setInterpolationFilter(ReconstructionFilter::createLinearInterpolationFilter());
		emit updateRequired();
	}
}

void SliceSettingsWidget::on_radioButtonCatmullRom_toggled(bool checked)
{
	if(checked)
	{
		m_pSliceRenderer->setInterpolationFilter(ReconstructionFilter::createCatmullRomInterpolationFilter());
		emit updateRequired();
	}
}