#include <QtGui/QMenu>
#include <QtGui/QContextMenuEvent>

#include "MainWindow.h"
#include "VolumeBrowser.h"

VolumeBrowser::VolumeBrowser(QWidget *parent)
: QWidget(parent)
,m_contextMenu(0)
{
	setupUi(this);

	m_contextMenu = new QMenu(this);
}

VolumeBrowser::~VolumeBrowser()
{
	if(m_contextMenu)
	{
		delete m_contextMenu;
	}
	m_contextMenu = 0;
}

void VolumeBrowser::addVolume(QString volumeNameString)
{
	QTreeWidgetItem* volumeItem = new QTreeWidgetItem();
	volumeItem->setText(0, volumeNameString);
	treeWidget->addTopLevelItem(volumeItem);
}

void VolumeBrowser::removeVolume(QString volumeNameString)
{
	QList<QTreeWidgetItem *> items = treeWidget->findItems(volumeNameString,Qt::MatchExactly);
	if(items.size() == 1) //There should not more than 1.
	{
		QTreeWidgetItem* item = items[0]; 
		int index = treeWidget->indexOfTopLevelItem(item);
		treeWidget->takeTopLevelItem(index);
	}
}

QString VolumeBrowser::getSelectedVolume()
{
	QList<QTreeWidgetItem *> selectedVolumes = treeWidget->selectedItems();
	if(selectedVolumes.size() == 1)
	{
		return selectedVolumes[0]->text(0);
	}
	return "";
}

void VolumeBrowser::selectVolume(QString volumeNameString)
{
	treeWidget->clearSelection();
	QList<QTreeWidgetItem *> items = treeWidget->findItems(volumeNameString,Qt::MatchExactly);
	for(unsigned int ct = 0; ct < items.size(); ++ct)
	{
			treeWidget->setItemSelected(items[ct], true);
			break;
	}
}

void VolumeBrowser::contextMenuEvent(QContextMenuEvent *event)
{
	//Ensure the volume under the cursor is selected.
	QTreeWidgetItem* item = treeWidget->currentItem();
	if(item != 0)
	{
		treeWidget->setItemSelected(item, true);
	}
	//Show the menu.
	m_contextMenu->exec(event->globalPos());
}

bool VolumeBrowser::hasSelectedItem(void)
{
	QList<QTreeWidgetItem *> selectedVolumes = treeWidget->selectedItems();
	return (selectedVolumes.size() != 0); //Returns true if the list isn't empty.
}

void VolumeBrowser::addActionToContextMenu(QAction* newAction)
{
	m_contextMenu->addAction(newAction);
}