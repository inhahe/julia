#ifndef RENDERINGWIDGET_H
#define RENDERINGWIDGET_H

#include "FwdDecl.hpp"

#include "RenderResolution.h"
#include "ui_RenderingWidget.h"

class RenderingDisplayWidget;

class RenderingWidget : public QWidget, private Ui::RenderingWidget
{
	Q_OBJECT
public:	
	RenderingWidget(Thermite::Renderer* pRenderer, QWidget *parent = 0);
	Thermite::Renderer* renderer();

	void setMaxRes(RenderResolution res);
	void setMinRes(RenderResolution res);


protected:
	RenderingDisplayWidget* m_pDisplayWidget;
	Thermite::Renderer* m_pRenderer;

signals:

public slots:
	void on_generalRendererSettingsWidget_maxResChanged(RenderResolution res);
	void on_generalRendererSettingsWidget_minResChanged(RenderResolution res);
	void on_generalRendererSettingsWidget_zoomChanged(double value);
	void update(void);
};

#endif