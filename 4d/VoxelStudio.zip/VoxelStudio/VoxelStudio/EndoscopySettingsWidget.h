#ifndef ENDOSCOPYSETTINGSWIDGET_H
#define ENDOSCOPYSETTINGSWIDGET_H

#include "FwdDecl.hpp"
#include "Typedef.hpp"

#include "ui_EndoscopySettingsWidget.h"

class EndoscopySettingsWidget : public QWidget, private Ui::EndoscopySettingsWidget
{
	Q_OBJECT
public:
	EndoscopySettingsWidget(Thermite::EndoscopyRenderer<Thermite::uint2>* pEndoscopyRenderer, QWidget *parent = 0);

	void setInitialValues(void);

signals:
	void updateRequired(void);

protected:
	Thermite::EndoscopyRenderer<Thermite::uint2>* m_pEndoscopyRenderer;

private slots:
};

#endif