#include <QtGui/QApplication>
#include "MainWindow.h"

#include "Thermite.hpp"

int main(int argc, char *argv[])
{
	initThermite();

    QApplication app(argc, argv);
    MainWindow *window = new MainWindow;

    window->show();
    return app.exec();
}