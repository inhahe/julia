#ifndef SUBVOLUME_SETTINGS_DIALOG_H
#define SUBVOLUME_SETTINGS_DIALOG_H

#include "ui_SubvolumeSettingsDialog.h"

class SubvolumeSettingsDialog : public QDialog, private Ui::SubvolumeSettingsDialog
{
	Q_OBJECT
public:
	SubvolumeSettingsDialog(QWidget *parent = 0);	

private:
	void generateSubvolume(void);
	static int m_iSubvolumeCounter;

private slots:
	void on_okButton_clicked();
};

#endif