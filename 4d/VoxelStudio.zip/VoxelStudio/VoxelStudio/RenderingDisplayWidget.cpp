#include "Logging.hpp"
#include "Renderer.hpp"

#include <QtGui/QKeyEvent>
#include <QtGui/QMouseEvent>

#include "RenderingDisplayWidget.h"

using namespace Thermite;

RenderingDisplayWidget::RenderingDisplayWidget(Renderer* pRenderer)
:m_pRenderer(pRenderer)
, minRes(LowResolution)
, maxRes(HighResolution)
{
}

RenderingDisplayWidget::~RenderingDisplayWidget()
{
}

void RenderingDisplayWidget::setMaxRes(RenderResolution res)
{
	maxRes = res;
}

void RenderingDisplayWidget::setMinRes(RenderResolution res)
{
	minRes = res;
}

bool RenderingDisplayWidget::changeCurrentRes(RenderResolution res)
{
	RenderResolution original = currentRes; //Store the original
	currentRes = (std::min)(res, maxRes);
	currentRes = (std::max)(currentRes, minRes);
	return (original != currentRes); //Return true if the res has actually changed.
}

void RenderingDisplayWidget::mousePressEventHandler(QMouseEvent *event)
{
	m_iOldX = event->x();
	m_iOldY = event->y();	
}

void RenderingDisplayWidget::mouseMoveEventHandler(QMouseEvent *event)
{
	double xMovement = double(event->x() - m_iOldX) / 80.0f;
	double yMovement = double(event->y() - m_iOldY) / 80.0f;

	m_iOldX = event->x();
	m_iOldY = event->y();

	//With SDL screen coordinates (0,0) is top left
	m_pRenderer->camera().lookLeft(xMovement);
	m_pRenderer->camera().lookUp(yMovement);
}

void RenderingDisplayWidget::keyPressEventHandler(QKeyEvent* event)
{
	switch(event->key())
	{
	case Qt::Key_W:
		m_pRenderer->camera().setPosition(m_pRenderer->camera().position() + (m_pRenderer->camera().forward() * 5.0));
		break;
	case Qt::Key_S:
		m_pRenderer->camera().setPosition(m_pRenderer->camera().position() + (m_pRenderer->camera().forward() * -5.0));
		break;
	case Qt::Key_A:
		m_pRenderer->camera().setPosition(m_pRenderer->camera().position() + (m_pRenderer->camera().right() * -5.0));
		break;
	case Qt::Key_D:
		m_pRenderer->camera().setPosition(m_pRenderer->camera().position() + (m_pRenderer->camera().right() * 5.0));
		break;
	default:
		event->ignore();
		return;
	}
}