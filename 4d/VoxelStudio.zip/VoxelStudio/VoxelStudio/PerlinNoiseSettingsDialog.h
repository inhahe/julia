#ifndef PERLINNOISESETTINGSDIALOG_H
#define PERLINNOISESETTINGSDIALOG_H

#include "ui_PerlinNoiseSettingsDialog.h"

class PerlinNoiseSettingsDialog : public QDialog, private Ui::PerlinNoiseSettingsDialog
{
	Q_OBJECT
public:
	PerlinNoiseSettingsDialog(QWidget *parent = 0);

	int volumeWidth(void);
	int volumeHeight(void);
	int volumeDepth(void);

	int minValue(void);
	int maxValue(void);

private:
	void generatePerlinNoiseVolume(void);
	static int m_iPerlinNoiseVolumeCounter;

private slots:
	void on_okButton_clicked();
};

#endif