#include "Vector.hpp"

#include "Thermite.hpp"

using namespace Thermite;

int main(int argc, char** argv)
{
	initThermite();

	//////////////////////////////////////////////////////////////////////////
	// Vector Tests
	//////////////////////////////////////////////////////////////////////////
	Vector3DDouble v3dDouble(1.0,2.0,3.0);
	Vector3DFloat v3dFloat = static_cast<Vector3DFloat>(v3dDouble); //Test casting
	THERMITE_LOG_DEBUG << "After casting val is: " << v3dFloat << std::endl;

	Vector3DDouble v3d1(1.0,2.0,3.0);
	Vector3DDouble v3d2(4.0,5.0,6.0);
	THERMITE_LOG_DEBUG << "Should be (5,7,9) : " << v3d1 + v3d2 <<std::endl;
	THERMITE_LOG_DEBUG << "Should be (0.5,1,1.5) : " << v3d1 / 2.0 <<std::endl;
	THERMITE_LOG_DEBUG << "Should be (2,4,6) : " << 2.0 * v3d1 <<std::endl;

	//////////////////////////////////////////////////////////////////////////
	// Matrix Tests
	//////////////////////////////////////////////////////////////////////////
	Vector2DDouble v2d(1.0,2.0);
	Matrix2DDouble m2d;
	m2d.set(0,0,3.0);
	m2d.set(0,1,4.0);
	m2d.set(1,0,5.0);
	m2d.set(1,1,6.0);

	THERMITE_LOG_DEBUG << "v2d * m2d = " << v2d * m2d << std::endl;
	THERMITE_LOG_DEBUG << "m2d * v2d = " << m2d * v2d << std::endl;
	//v2d *= m2d;
	//THERMITE_LOG_DEBUG << "v2d *= m2d = " << v2d << std::endl;

	Vector2DDouble initialPos(1.0,3.0);
	Matrix2DDouble rotation = create2x2RotationMatrix<double>(3.14159265/6.0);
	initialPos = rotation * initialPos;
	THERMITE_LOG_DEBUG << "Rotated pos = " << initialPos << std::endl;	

    THERMITE_LOG_DEBUG << "Test completed" << std::endl;
    return 0;
}