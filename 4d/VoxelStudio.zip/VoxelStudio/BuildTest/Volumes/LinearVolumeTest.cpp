#include "LinearVolume.hpp"

using namespace Thermite;

template class LinearVolume<double>;
template class LinearVolume<double>;
template class LinearVolume<int1>;
template class LinearVolume<int2>;
template class LinearVolume<int4>;
template class LinearVolume<uint1>;
template class LinearVolume<uint2>;
template class LinearVolume<uint4>;