#include "BlockVolume.hpp"

using namespace Thermite;

template class BlockVolume<double>;
template class BlockVolume<double>;
template class BlockVolume<int1>;
template class BlockVolume<int2>;
template class BlockVolume<int4>;
template class BlockVolume<uint1>;
template class BlockVolume<uint2>;
template class BlockVolume<uint4>;