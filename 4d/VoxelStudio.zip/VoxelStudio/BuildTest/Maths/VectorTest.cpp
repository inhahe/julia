#include "Vector.hpp"

using namespace Thermite;

template class Vector<3,double>;
template class Vector<3,double>;
template class Vector<3,int1>;
template class Vector<3,int2>;
template class Vector<3,int4>;
template class Vector<3,uint1>;
template class Vector<3,uint2>;
template class Vector<3,uint4>;