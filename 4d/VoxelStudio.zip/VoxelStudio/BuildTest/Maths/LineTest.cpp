#include "Line.hpp"

using namespace Thermite;

template class Line<double>;
template class Line<double>;
template class Line<int1>;
template class Line<int2>;
template class Line<int4>;
template class Line<uint1>;
template class Line<uint2>;
template class Line<uint4>;