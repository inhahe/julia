#include "Matrix.hpp"

using namespace Thermite;

template class Matrix<3,float>;
template class Matrix<3,double>;
template class Matrix<3,int1>;
template class Matrix<3,int2>;
template class Matrix<3,int4>;
template class Matrix<3,uint1>;
template class Matrix<3,uint2>;
template class Matrix<3,uint4>;