#include "Plane.hpp"

using namespace Thermite;

template class Plane<double>;
template class Plane<double>;
template class Plane<int1>;
template class Plane<int2>;
template class Plane<int4>;
template class Plane<uint1>;
template class Plane<uint2>;
template class Plane<uint4>;