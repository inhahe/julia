#include "Intersection.hpp"

using namespace Thermite;

template Vector<3,double> intersectionOf<double>(const Line<double>& line, const Plane<double>& plane);
