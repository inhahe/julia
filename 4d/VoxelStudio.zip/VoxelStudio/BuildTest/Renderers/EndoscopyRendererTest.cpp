#include "EndoscopyRenderer.hpp"

using namespace Thermite;

template class EndoscopyRenderer<uint2>;
