#include "IPRenderer.hpp"

using namespace Thermite;

template class IPRenderer<uint2>;
