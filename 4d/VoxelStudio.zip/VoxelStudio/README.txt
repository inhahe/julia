There is no real documentation for this software, this file is intended to let you at least get an image on the screen.

1) Run VoxelStudio.exe in the exe subfolder.
2) Click File->Import.
3) Go up one folder and open cthead.dat
4) Numbering the icons on the toolbar from the left and starting at 1, you can click any of the icons between 3 and 5 inclusive.
5) Click and drag on the resulting image to manipulate it.