#ifndef RAYCASTINGRENDERER_HEADER_INCLUDED
#define RAYCASTINGRENDERER_HEADER_INCLUDED

#include <list>
#include <vector>

#include "VolumeRenderer.hpp"
#include "ScanlineRenderer.hpp"
#include "..\Images\RGBA.hpp"
#include "..\Base\Typedef.hpp"
#include "..\Maths\Polygon.hpp"

namespace Thermite
{
    class DensityColourPair
    {
    public:
        DensityColourPair(Thermite::uint4 uDensity, Thermite::RGBA<float> colColour) : m_uDensity(uDensity), m_colColour(colColour){}
        Thermite::uint4 m_uDensity;
        Thermite::RGBA<float> m_colColour;
    };

    template <typename VoxelType>
    class RaycastingRenderer : public VolumeRenderer<SoftwareRenderer, VoxelType>
    {
    public:
        RaycastingRenderer(Thermite::Volume<uint2>* pVolume) throw();
        virtual ~RaycastingRenderer() throw();
        virtual void render(void) throw();
        bool useSobel;
        void setSize(uint4 uWidth, uint4 uHeight);
//		Vector3DDouble imageSpacePosition(const Vector3DDouble& position); //FIXME - define Vector2D and return this.
    private:
        void computeTransferFunctionFromNodes(void);
		//void renderVolumeSidesToDepthBuffer(void);
		//void renderTriangleToDepthBuffer(const Vector3DDouble& v0,const Vector3DDouble& v1,const Vector3DDouble& v2);
		//void renderConvexPolygonToDepthBuffer(std::list< Vector3DDouble > vertices);
		//void renderConvexPolygonToDepthBuffer(Polygon< Vector3DDouble > vertices);
		//void renderQuadToDepthBuffer(const Vector3DDouble& v0,const Vector3DDouble& v1,const Vector3DDouble& v2,const Vector3DDouble& v3);
		//void renderSpanToDepthBuffer(uint4 x1, double depth1, uint4 x2, double depth2, uint4 y);
        double m_fLower;
        double m_fUpper;
        std::list<DensityColourPair> m_TransferFunctionNodes;
        std::vector< Thermite::RGBA<float> > transferFunction;
		//Image<double> m_imgDepth;
		uint4 frameCounter;
		ScanlineRenderer* m_rendScanline;
    };
}

#include "RaycastingRenderer.inl"
#endif
