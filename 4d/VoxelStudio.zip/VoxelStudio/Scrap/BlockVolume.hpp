#ifndef BLOCK_VOLUME_HEADER_INCLUDED
#define BLOCK_VOLUME_HEADER_INCLUDED

#include <fstream> //For file access
#include <vector>

#include "Volume.hpp" //Base class

namespace Thermite
{
    template <typename Type>
    class BlockVolume : public Volume<Type>
    {
    public:
        //Constructors, etc.
        BlockVolume() throw();
        BlockVolume(uint4 widthToSet, uint4 heightToSet, uint4 depthToSet) throw();
        //BlockVolume(const BlockVolume& rhs) throw();
        ~BlockVolume() throw();

        //Operators
        //BlockVolume<Type>& operator=(const BlockVolume<Type>& rhs) throw();

        //General getters/setters
        void setDimensions(const uint4 widthToSet,const uint4 heightToSet,const uint4 depthToSet) throw();

        //Value accessors
        const Type& voxelAt(const Vector3DUint4& position) const throw();
        Type& voxelAt(const Vector3DUint4& position) throw();

        //Interpolated value accessors
        double computeTrilinearlyInterpolatedValueAt(const Vector3DDouble& position) const throw();

        //Gradient accesors
        Vector3DInt4 computeCentralDifferenceGradientAt(const Vector3DUint4& position) const throw();

        //Interpolated gradient accessors
        Vector3DDouble computeTrilinearlyInterpolatedCentralDifferenceGradientAt(const Vector3DDouble& position) const throw();

        //File access
        //void importDAT(const std::string& filename) throw(file_error);

    protected:      

        class Block
        {
        public:
            Block() throw();
            ~Block() throw();

            const Type& voxelAt(const Vector3DInt4& position) const throw();
            Type& voxelAt(const Vector3DInt4& position) throw();

            void setBlockSize(uint4 size) throw();

            Type* getRawData(void) const throw();
        private:
            Type* m_pData;
        };

        //Internal data
        Block* m_pBlocks;
        uint4 m_uWidthInBlocks;
        uint4 m_uHeightInBlocks;
        uint4 m_uDepthInBlocks;
    };
    
}//namespace Thermite

#include "BlockVolume.inl"

#endif	//BLOCK_VOLUME_HEADER_INCLUDED

