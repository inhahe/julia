#include "..\Maths\Intersection.hpp"
#include "..\Maths\Line.hpp"
#include "..\Maths\Plane.hpp"

#define CELL_OCCUPIED_FLAG 0x8000
#define NEAR_EDGE_FLAG 0x4000

namespace Thermite
{
    template <typename VoxelType>
	XRayEndoscopyRenderer<VoxelType>::XRayEndoscopyRenderer(Thermite::LinearVolume<uint2>* pVolume,double threshold) throw()
		:VolumeRenderer<uint2, RGBA<float> >(pVolume)
		,m_fThreshold(threshold)
	{
		useSobel = false;
	}

    template <typename VoxelType>
	XRayEndoscopyRenderer<VoxelType>::~XRayEndoscopyRenderer() throw()
	{
	}

    template <typename VoxelType>
	void XRayEndoscopyRenderer<VoxelType>::render() throw()
	{
		//clear the display
		imageVal.clearTo(RGBA<float>(0.0f,0.0f,0.0f,0.0f));

		//set all pixels to be non important
		//importantPixels.clearTo(false);
		startDepths.clearTo(0.0f);
		std::vector<double> xPositions;
		std::vector<double> yPositions;
		double fMinDepth = 1000000.0f;
		uint4 voxelsProjectedToScreen = 0;
		//Project important voxels to screen
		for(uint4 z = 0; z < m_volImportance.depth(); ++z)
		{
			for(uint4 y = 0; y < m_volImportance.height(); ++y)
			{
				for(uint4 x = 0; x < m_volImportance.width(); ++x)
				{
					if(m_volImportance.voxelAt(Vector3DUint4(x,y,z)) > 0)
					{
						//Line<double> line(Vector3DDouble(x,y,z), cameraVal.position());
						Line<double> line(Vector3DDouble(x,y,z), cameraVal.position());
						Plane<double> plane(cameraVal.forward(), cameraVal.position() + cameraVal.forward());

						Vector3DDouble intersectionPoint = intersectionOf(line, plane);

						Vector3DDouble imageCenterToIntersectionPoint = intersectionPoint - (cameraVal.position() + cameraVal.forward()); 
						double imageCenterToIntersectionPointDotRight = imageCenterToIntersectionPoint.dot(cameraVal.right());
						double imageCenterToIntersectionPointDotUp = imageCenterToIntersectionPoint.dot(cameraVal.up());
						double fXScreenPos = (imageCenterToIntersectionPointDotRight * imageVal.width()) + imageVal.width() / 2;
						double fYScreenPos = (imageCenterToIntersectionPointDotUp * imageVal.height()) + imageVal.height() / 2;

						if((fXScreenPos > 1) && (fXScreenPos < image().width()-2) && 
							(fYScreenPos > 1) && (fYScreenPos < image().height()-2))
						{
							++voxelsProjectedToScreen;
							double depth = (Vector3DDouble(x,y,z) - cameraVal.position()).length();
							if(depth < fMinDepth)
							{
								fMinDepth = depth;
							}
						}						
						
						xPositions.push_back(fXScreenPos);
						yPositions.push_back(fYScreenPos);
					}
				}
			}
		}

		fMinDepth = fMinDepth - 1.0f;
		if(voxelsProjectedToScreen == 0)
		{
			fMinDepth = 0.0f;
		}
		THERMITE_LOG_DEBUG << fMinDepth <<std::endl;

		double meanX = 0.0f;
		double meanY = 0.0f;
		for(uint4 ct = 0; ct < xPositions.size(); ++ct)
		{
			meanX += xPositions[ct];
			meanY += yPositions[ct];
		}
		meanX /= xPositions.size();
		meanY /= yPositions.size();

		double windowRadius = 0.0f;
		for(uint4 ct = 0; ct < xPositions.size(); ++ct)
		{
			double xDist = static_cast<double>(meanX) - static_cast<double>(xPositions[ct]);
			double yDist = static_cast<double>(meanY) - static_cast<double>(yPositions[ct]);
			double dist = sqrt(xDist*xDist+yDist*yDist);
			if(dist > windowRadius)
			{
				windowRadius = dist;
			}
		}

		windowRadius += 10.0f;
		double stepBack = fMinDepth / 30.0f;

		for(uint4 imagePosY = 0; imagePosY < imageVal.height(); ++imagePosY)
		{   
			for(uint4 imagePosX = 0; imagePosX < imageVal.width(); ++imagePosX)
			{
				double xDist = static_cast<double>(meanX) - static_cast<double>(imagePosX);
				double yDist = static_cast<double>(meanY) - static_cast<double>(imagePosY);
				double dist = sqrt(xDist*xDist+yDist*yDist);

				dist -= windowRadius;
				dist = Thermite::maximum(0.0f,dist);
				if(dist <= 30.0f)
					startDepths.pixelAt(imagePosX,imagePosY) = fMinDepth - (dist * stepBack);
				else
					startDepths.pixelAt(imagePosX,imagePosY) = 0.0f;
			}
		}
		

		//Some globalish values.
		const double ambientFactor = 0.5f;
		//const double ambientFactor = 1.0f;
		const double diffuseFactor = 0.5f;
		const double specularFactor = 0.5f;
		const double specularExponent = 20.0f;

		//Camera properties which aren't dependant on image position
		const Vector3DDouble xDelta = cameraVal.right() / static_cast<double>(imageVal.width());
		const Vector3DDouble yDelta = cameraVal.up() / static_cast<double>(imageVal.width());
		const Vector3DDouble lowerLeftCorner = cameraVal.position() + cameraVal.forward() - (cameraVal.right() / 2.0f) - (cameraVal.up() / 2.0f);

		//Do the non-important pixels

		//For each pixel group in the image:
		for(uint4 imagePosY = 0; imagePosY < imageVal.height(); ++imagePosY)
		{   
			//THERMITE_LOG_DEBUG << imagePosY << std::endl;
			for(uint4 imagePosX = 0; imagePosX < imageVal.width(); ++imagePosX)
			{
				//Check the pixel isn't important
				/*if(importantPixels(imagePosX, imagePosY))
				{
					continue;
				}*/
				//First we compute the starting depth
				//Compute the ray direction
				Vector3DDouble xOffset = xDelta * static_cast<double>(imagePosX); 
				Vector3DDouble yOffset = yDelta * static_cast<double>(imagePosY);
				Vector3DDouble pointOnImagePlane = lowerLeftCorner + xOffset + yOffset;
				Vector3DDouble rayPosition = cameraVal.position();
				Vector3DDouble rayDirection = (pointOnImagePlane - cameraVal.position());
				rayDirection.normalise();

				rayPosition += (rayDirection * startDepths.pixelAt(imagePosX,imagePosY));

				//Do some kind of space skipping
				while(((m_volUtility.voxelAt(static_cast< Vector3DUint4 >(rayPosition)) & CELL_OCCUPIED_FLAG) == false) &&
					((m_volUtility.voxelAt(static_cast< Vector3DUint4 >(rayPosition)) & NEAR_EDGE_FLAG) == false))
				{
					rayPosition += rayDirection;
				}  
				rayPosition -= rayDirection;

				rayDirection /= 5.0f;
				while((rayPosition.x() > 3) && (rayPosition.x() < m_pVolume->width()-4) &&
					(rayPosition.y() > 3) && (rayPosition.y() < m_pVolume->height()-4) &&
					(rayPosition.z() > 3) && (rayPosition.z() < m_pVolume->depth()-4))
				{
					if((m_pVolume->computeTrilinearlyInterpolatedValueAt(rayPosition) > m_fThreshold)			
						&& /*(volume().computeTrilinearlyInterpolatedSobelGradientAt(rayPosition).dot(cameraVal.forward()) > 0.0f)*/ (true))
					{
						RGBA<float> sampleColour(1.0f,0.6f,0.55f,1.0f);
						/*if(m_volImportance.computeTrilinearlyInterpolatedValueAt(rayPosition) > 0.001f)
						{
							sampleColour.set(0.0f,0.0f,1.0f,1.0f);
						}*/

						//Do the lighting
						Vector3DDouble normal = m_pVolume->computeTrilinearlyInterpolatedSobelGradientAt(rayPosition);               

						normal.normalise();
						const Vector3DDouble& lightDirection = cameraVal.forward();

						//Ambient component
						const double ambientIntensity = ambientFactor;

						//Diffuse Component
						const double normalDotLight = normal.dot(lightDirection);
						const double diffuseIntensity = Thermite::maximum(normalDotLight, 0.0f) * diffuseFactor;
						const double specularIntensity = ((normalDotLight) / (specularExponent - specularExponent*normalDotLight + normalDotLight)) * specularFactor;

						const double totalIntensity = ambientIntensity + diffuseIntensity + specularIntensity;
						sampleColour *= totalIntensity;

						(imageVal.rawData())[imagePosY * imageVal.width() + imagePosX] = sampleColour;
						break;
					}
					rayPosition += rayDirection;
				}
			}
		}

#ifdef BLAH

		//do the important pixels
		//For each pixel group in the image:
		for(uint4 imagePosY = 0; imagePosY < imageVal.height(); ++imagePosY)
		{   
			//THERMITE_LOG_DEBUG << imagePosY << std::endl;
			for(uint4 imagePosX = 0; imagePosX < imageVal.width(); ++imagePosX)
			{
				//Check the pixel is important
				if(importantPixels(imagePosX, imagePosY) == false)
				{
					continue;
				}
				//THERMITE_LOG_DEBUG << "Rendering pixel: x = " << imagePosX << " y = " << imagePosY << std::endl;
				//First we compute the starting depth
				//Compute the ray direction
				Vector3DDouble xOffset = xDelta * static_cast<double>(imagePosX); 
				Vector3DDouble yOffset = yDelta * static_cast<double>(imagePosY);
				Vector3DDouble pointOnImagePlane = lowerLeftCorner + xOffset + yOffset;
				Vector3DDouble rayPosition = cameraVal.position();
				Vector3DDouble rayDirection = (pointOnImagePlane - cameraVal.position());
				rayDirection.normalise();

				//Do some kind of space skipping
				while(((m_volUtility.voxelAt(static_cast< Vector3DUint4 >(rayPosition)) & CELL_OCCUPIED_FLAG) == false) &&
					((m_volUtility.voxelAt(static_cast< Vector3DUint4 >(rayPosition)) & NEAR_EDGE_FLAG) == false))
				{
					rayPosition += rayDirection;
				}  
				rayPosition -= rayDirection;

				rayDirection /= 5.0f;
				while((rayPosition.x() > 3) && (rayPosition.x() < m_pVolume->width()-4) &&
					(rayPosition.y() > 3) && (rayPosition.y() < m_pVolume->height()-4) &&
					(rayPosition.z() > 3) && (rayPosition.z() < m_pVolume->depth()-4))
				{
					if((volume().computeTrilinearlyInterpolatedValueAt(rayPosition) > m_fThreshold)			
						&& (m_volImportance.computeTrilinearlyInterpolatedValueAt(rayPosition) > 0.5f)
						&& (cameraVal.forward().dot(volume().computeTrilinearlyInterpolatedSobelGradientAt(rayPosition)) > 0.0f))
					{
						//RGBA<float> sampleColour(0.0f,0.0f,1.0f,1.0f);
						RGBA<float> sampleColour(1.0f,0.6f,0.55f,1.0f);

						//Do the lighting
						Vector3DDouble normal = volume().computeTrilinearlyInterpolatedSobelGradientAt(rayPosition);               

						normal.normalise();
						const Vector3DDouble& lightDirection = cameraVal.forward();

						//Ambient component
						const double ambientIntensity = ambientFactor;

						//Diffuse Component
						const double normalDotLight = normal.dot(lightDirection);
						const double diffuseIntensity = Thermite::maximum(normalDotLight, 0.0f) * diffuseFactor;
						const double specularIntensity = ((normalDotLight) / (specularExponent - specularExponent*normalDotLight + normalDotLight)) * specularFactor;

						const double totalIntensity = ambientIntensity + diffuseIntensity + specularIntensity;
						sampleColour *= totalIntensity;

						(imageVal.rawData())[imagePosY * imageVal.width() + imagePosX] = sampleColour;
						break;
					}
					rayPosition += rayDirection;
				}
			}
		}

#endif
	}

    template <typename VoxelType>
	void XRayEndoscopyRenderer<VoxelType>::initialiseUtilityVolume(void)
	{
		m_volUtility.setDimensions(m_pVolume->width(), m_pVolume->height(),m_pVolume->depth());
		for(uint4 z = 0; z < m_pVolume->depth()-1; ++z)
		{
			for(uint4 y = 0; y < m_pVolume->height()-1; ++y)
			{
				for(uint4 x = 0; x < m_pVolume->width()-1; ++x)
				{                
					m_volUtility.voxelAt(Thermite::Vector3DUint4(x,y,z)) = 0;
				}
			}
		}
		for(uint4 z = 0; z < m_pVolume->depth()-2; ++z)
		{
			for(uint4 y = 0; y < m_pVolume->height()-2; ++y)
			{
				for(uint4 x = 0; x < m_pVolume->width()-2; ++x)
				{
					bool cellOccupied = ((m_pVolume->voxelAt(Thermite::Vector3DUint4(x,y,z)) >= m_fThreshold) ||
						(m_pVolume->voxelAt(Thermite::Vector3DUint4(x,y,z+1)) >= m_fThreshold) ||
						(m_pVolume->voxelAt(Thermite::Vector3DUint4(x,y+1,z)) >= m_fThreshold) ||
						(m_pVolume->voxelAt(Thermite::Vector3DUint4(x,y+1,z+1)) >= m_fThreshold) ||
						(m_pVolume->voxelAt(Thermite::Vector3DUint4(x+1,y,z)) >= m_fThreshold) ||
						(m_pVolume->voxelAt(Thermite::Vector3DUint4(x+1,y,z+1)) >= m_fThreshold) ||
						(m_pVolume->voxelAt(Thermite::Vector3DUint4(x+1,y+1,z)) >= m_fThreshold) ||
						(m_pVolume->voxelAt(Thermite::Vector3DUint4(x+1,y+1,z+1)) >= m_fThreshold));
					if(cellOccupied)
						m_volUtility.voxelAt(Thermite::Vector3DUint4(x,y,z)) = m_volUtility.voxelAt(Thermite::Vector3DUint4(x,y,z)) | CELL_OCCUPIED_FLAG;
				}
			}
		}

		THERMITE_LOG_DEBUG << m_pVolume->width() << " " << m_pVolume->height() << " " << m_pVolume->depth() << std::endl;
		for(uint4 z = 0; z < m_pVolume->depth()-1; ++z)
		{
			for(uint4 y = 0; y < m_pVolume->height()-1; ++y)
			{
				for(uint4 x = 0; x < m_pVolume->width()-1; ++x)
				{
					if((x < 3) || (x > m_pVolume->width()-4) ||
						(y < 3) || (y > m_pVolume->height()-4) ||
						(z < 3) || (z > m_pVolume->depth()-4))
					{
						m_volUtility.voxelAt(Thermite::Vector3DUint4(x,y,z)) = m_volUtility.voxelAt(Thermite::Vector3DUint4(x,y,z)) | NEAR_EDGE_FLAG;
					}
				}
			}
		} 
	}

    template <typename VoxelType>
	void XRayEndoscopyRenderer<VoxelType>::initialiseImportanceVolume(void)
	{
		m_volImportance.load("C:\\VolumeData\\prone16_subvolume\\prone16_subvolume_importance.dat");

		/*m_volCurvature.setDimensions(m_pVolume->width(), m_pVolume->height(),m_pVolume->depth());
		//Clear the volume
		for(uint4 z = 0; z < m_pVolume->depth()-1; ++z)
		{
			for(uint4 y = 0; y < m_pVolume->height()-1; ++y)
			{
				for(uint4 x = 0; x < m_pVolume->width()-1; ++x)
				{                
					m_volCurvature.voxelAt(Thermite::Vector3DUint4(x,y,z)) = 0;
				}
			}
		}

		//Calculate the curvature
		double maxCurvature = 0.0f;
		double minCurvature = 100000.0f;
		for(uint4 z = 5; z < m_pVolume->depth()-6; ++z)
		{
			THERMITE_LOG_DEBUG << z << std::endl;
			for(uint4 y = 5; y < m_pVolume->height()-6; ++y)
			{
				for(uint4 x = 5; x < m_pVolume->width()-6; ++x)
				{                
					//Curvature in x direction
					double meanX = 0.0f;
					double meanY = 0.0f;
					double meanZ = 0.0f;
					int4 ct = 0;
					for(int4 filterZ = -2; filterZ <= 2; ++filterZ)
					{
						for(int4 filterY = -2; filterY <= 2; ++filterY)
						{
							for(int4 filterX = -2; filterX <= 2; ++filterX)
							{
								if(m_pVolume->voxelAt(Vector3DUint4(x+filterX,y+filterY,z+filterZ)) > m_fThreshold)
								{
									meanX += m_pVolume->computeSobelGradientAt(Vector3DUint4(x+filterX,y+filterY,z+filterZ)).x();
									meanY += m_pVolume->computeSobelGradientAt(Vector3DUint4(x+filterX,y+filterY,z+filterZ)).y();
									meanZ += m_pVolume->computeSobelGradientAt(Vector3DUint4(x+filterX,y+filterY,z+filterZ)).z();
									ct++;
								}
							}
						}
					}

					meanX /= static_cast<double>(ct);
					meanY /= static_cast<double>(ct);
					meanZ /= static_cast<double>(ct);
					double sumOfXDifferences = 0.0f;
					double sumOfYDifferences = 0.0f;
					double sumOfZDifferences = 0.0f;
					uint4 noOfDifferences = 0;

					for(int4 filterZ = -2; filterZ <= 2; ++filterZ)
					{
						for(int4 filterY = -2; filterY <= 2; ++filterY)
						{
							for(int4 filterX = -2; filterX <= 2; ++filterX)
							{
								if(m_pVolume->voxelAt(Vector3DUint4(x+filterX,y+filterY,z+filterZ)) > m_fThreshold)
								{
									sumOfXDifferences += fabs(m_pVolume->computeSobelGradientAt(Vector3DUint4(x+filterX,y+filterY,z+filterZ)).x() - meanX);
									sumOfYDifferences += fabs(m_pVolume->computeSobelGradientAt(Vector3DUint4(x+filterX,y+filterY,z+filterZ)).y() - meanY);
									sumOfZDifferences += fabs(m_pVolume->computeSobelGradientAt(Vector3DUint4(x+filterX,y+filterY,z+filterZ)).z() - meanZ);
									noOfDifferences++;
								}
							}
						}
					}

					sumOfXDifferences /= static_cast<double>(noOfDifferences);
					sumOfYDifferences /= static_cast<double>(noOfDifferences);
					sumOfZDifferences /= static_cast<double>(noOfDifferences);

					double curvature = (sumOfXDifferences + sumOfYDifferences + sumOfZDifferences) / 3.0f;

					if(curvature > maxCurvature)
					{
						maxCurvature = curvature;
					}
					if(curvature < minCurvature)
					{
						minCurvature = curvature;
					}	

					m_volCurvature.voxelAt(Vector3DUint4(x,y,z)) = static_cast<uint2>(curvature/1000.0f);
				}
			}
		}

		THERMITE_LOG_DEBUG << "max = " << maxCurvature << " min = " << minCurvature << std::endl;

		m_volCurvature.save("D:\\VolumeData\\prone16curvature_subvolume.dat");*/

	}

    /*template <typename VoxelType>
	void XRayEndoscopyRenderer<VoxelType>::setSize(uint4 uWidth, uint4 uHeight)
	{
		imageVal.resize(uWidth,uHeight);
	}*/
}

#undef CELL_OCCUPIED_FLAG
#undef NEAR_EDGE_FLAG
