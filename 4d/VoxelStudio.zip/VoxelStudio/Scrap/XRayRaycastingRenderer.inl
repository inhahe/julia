#define CELL_OCCUPIED_FLAG 0x8000
#define NEAR_EDGE_FLAG 0x4000

#include<limits>

namespace Thermite
{
    
    template <typename VoxelType>
	XRayRaycastingRenderer<VoxelType>::XRayRaycastingRenderer(Thermite::LinearVolume<uint2>* pVolume,double fThreshold) throw()
        : VolumeRenderer<uint2, RGBA<float> >(pVolume)
		,m_fThreshold(fThreshold)
	{
	}

    template <typename VoxelType>
	XRayRaycastingRenderer<VoxelType>::~XRayRaycastingRenderer() throw()
	{
	}

    template <typename VoxelType>
	void XRayRaycastingRenderer<VoxelType>::render() throw()
	{

		imageVal.clearTo(RGBA<float>(0.0f,0.0f,0.0f,0.0f));
		//m_imgDepth.clearTo(std::numeric_limits<double>::infinity());
		m_imgDepth.clearTo(0.0f);

        generateDepthImage();

		//Some globalish values.
		const double ambientFactor = 0.3f;
		const double diffuseFactor = 0.6f;
		const double specularFactor = 0.2f;
		const double specularExponent = 20.0f;

		//Camera properties which aren't dependant on image position
		const Vector3DDouble rightZoomed = cameraVal.right() / cameraVal.zoom();
		const Vector3DDouble upZoomed = cameraVal.up() / cameraVal.zoom();
		const Vector3DDouble lowerLeftCorner = cameraVal.position() - 
			(cameraVal.forward() * m_pVolume->diagonal()) - 
			(rightZoomed * static_cast<double>(imageVal.width() / 2)) - 
			(upZoomed  * static_cast<double>(imageVal.height() / 2)); 

		//For each pixel in the image:
		for(uint4 yPos = 0; yPos < imageVal.height(); ++ yPos)
		{        
			//THERMITE_LOG_DEBUG << yPos << std::endl;
			for(uint4 xPos = 0; xPos < imageVal.width(); ++ xPos)
			{
				//Compute the ray direction
				Vector3DDouble xOffset = rightZoomed * static_cast<double>(xPos);
				Vector3DDouble yOffset = upZoomed * static_cast<double>(yPos);
				Vector3DDouble rayPosition = lowerLeftCorner + xOffset + yOffset;
				Vector3DDouble rayDirection = cameraVal.forward();
				rayDirection.normalise();				

				rayPosition += rayDirection * m_imgDepth.pixelAt(xPos,yPos);

				//Skip forward into volume
				for(uint4 ct = 0; ct < 2000; ct++)
				{
					if((rayPosition.x() > 5) && (rayPosition.y() > 5) && (rayPosition.z() > 5) && 
						(rayPosition.x() < m_pVolume->width()-5) && (rayPosition.y() < m_pVolume->height()-5) && (rayPosition.z() < m_pVolume->depth()-5))
					{
						break;
					}
					rayPosition += rayDirection;
				}

				//Maybe there was no intersection...
				if((rayPosition.x() < 5) || (rayPosition.y() < 5) || (rayPosition.z() < 5) || 
					(rayPosition.x() > m_pVolume->width()-5) || (rayPosition.y() > m_pVolume->height()-5) || (rayPosition.z() > m_pVolume->depth()-5))
				{
					continue;
				}

				while(((m_volUtility.voxelAt(static_cast< Vector3DUint4 >(rayPosition)) & CELL_OCCUPIED_FLAG) == false)
					&& ((m_volUtility.voxelAt(static_cast< Vector3DUint4 >(rayPosition)) & NEAR_EDGE_FLAG) == false))
				{
					rayPosition += rayDirection;
				}

				RGBA<float> colour(0.0f,0.0f,0.0f,0.0f);
				while((rayPosition.x() > 5) && (rayPosition.y() > 5) && (rayPosition.z() > 5) && 
					(rayPosition.x() < m_pVolume->width()-5) && (rayPosition.y() < m_pVolume->height()-5) && (rayPosition.z() < m_pVolume->depth()-5) &&
					colour.alpha() < 1.0f)
					//while(((m_volUtility.voxelAt(static_cast< Vector3DUint4 >(rayPosition)) & NEAR_EDGE_FLAG) == false) && (runningColour.alpha() < 1.0f))
				{        
					double sample = m_pVolume->computeTrilinearlyInterpolatedValueAt(rayPosition);
					if(sample > m_fThreshold)
					{
						if(m_imgDepth.pixelAt(xPos,yPos) > 1.0f)
						{
							colour = RGBA<float>(0.0f,1.0f,0.0f,1.0f);

							

							//Do the lighting
							Vector3DDouble normal = m_pVolume->computeTrilinearlyInterpolatedCentralDifferenceGradientAt(rayPosition);

							normal.normalise();
							const Vector3DDouble& lightDirection = cameraVal.forward();

							//Ambient component
							const double ambientIntensity = ambientFactor;

							//Diffuse Component
							const double normalDotLight = normal.dot(lightDirection);
							const double diffuseIntensity = Thermite::maximum(normalDotLight, 0.0f) * diffuseFactor;

							colour.green() = 1.0f - std::abs(normalDotLight);

							//Specular Component
							// Schlick's slick approximation for Phong's specular term:
							// Simply replace Sn(t) = t^n with Sn(t) = t / (n - nt + t).
							const double specularIntensity = ((normalDotLight) / (specularExponent - specularExponent*normalDotLight + normalDotLight)) * specularFactor;

							//Total Intensity
							const double totalIntensity = ambientIntensity + diffuseIntensity + specularIntensity;
							//colour *= totalIntensity;
						}
						else
						{							
							colour = RGBA<float>(1.0f,0.55f,0.6f,1.0f);

							//Do the lighting
							Vector3DDouble normal = m_pVolume->computeTrilinearlyInterpolatedCentralDifferenceGradientAt(rayPosition);

							normal.normalise();
							const Vector3DDouble& lightDirection = cameraVal.forward();

							//Ambient component
							const double ambientIntensity = ambientFactor;

							//Diffuse Component
							const double normalDotLight = normal.dot(lightDirection);
							const double diffuseIntensity = Thermite::maximum(normalDotLight, 0.0f) * diffuseFactor;

							//Specular Component
							// Schlick's slick approximation for Phong's specular term:
							// Simply replace Sn(t) = t^n with Sn(t) = t / (n - nt + t).
							const double specularIntensity = ((normalDotLight) / (specularExponent - specularExponent*normalDotLight + normalDotLight)) * specularFactor;

							//Total Intensity
							const double totalIntensity = ambientIntensity + diffuseIntensity + specularIntensity;
							colour *= totalIntensity;
						}
						
						break;
					}
					rayPosition += rayDirection;
				}

				imageVal.rawData()[yPos * imageVal.width() + xPos] = colour;
			}
		}
	}

    /*template <typename VoxelType>
	void XRayRaycastingRenderer<VoxelType>::setSize(uint4 uWidth, uint4 uHeight)
	{
        imageVal.resize(uWidth,uHeight);
        m_imgDepth.resize(uWidth,uHeight);
	}*/

    template <typename VoxelType>
	void XRayRaycastingRenderer<VoxelType>::initialiseImportanceVolume(void)
	{
		m_volImportance.load("C:\\VolumeData\\prone16_subvolume\\prone16_subvolume_importance.dat");
		//m_volImportance.load("c:\\VolumeData\\442_subvolume_large_colon\\442_subvolume_magnitude_large_colon_importance.dat");
		/*m_volImportance.setDimensions(m_pVolume->width(),m_pVolume->height(),m_pVolume->depth());
		for(uint4 z = 0; z < m_volImportance.depth(); z++)
		{
			for(uint4 y = 0; y < m_volImportance.height(); y++)
			{
				for(uint4 x = 0; x < m_volImportance.width(); x++)
				{
					m_volImportance.voxelAt(Vector3DUint4(x,y,z)) = 0;
					if((x >= 125) && (x <= 129) && (y >= 106) && (y <= 110) && (z >= 132) && (z <= 136))
					{
						m_volImportance.voxelAt(Vector3DUint4(x,y,z)) = 1;
					}
				}
			}
		}*/
	}	

    template <typename VoxelType>
	Vector3DDouble XRayRaycastingRenderer<VoxelType>::imageSpacePosition(const Vector3DDouble& position)
	{
		//Orthographic projection so this should be easy...
		Vector3DDouble result;
		Vector3DDouble shiftedPosition  = position - cameraVal.position();
		result.x() = shiftedPosition.dot(cameraVal.right());
		result.y() = shiftedPosition.dot(cameraVal.up());

		//Represents the depth
		result.z() = (position - (cameraVal.position() - cameraVal.forward()*m_pVolume->diagonal() + cameraVal.right()*result.x() + cameraVal.up()*result.y())).length();

		result.x() += imageVal.width() / 2.0f;
		result.y() += imageVal.height() / 2.0f;
		return result;
	}

    template <typename VoxelType>
	void XRayRaycastingRenderer<VoxelType>::initialiseUtilityVolume(void)
	{
		m_volUtility.setDimensions(m_pVolume->width(), m_pVolume->height(),m_pVolume->depth());
		for(uint4 z = 0; z < m_pVolume->depth()-1; ++z)
		{
			for(uint4 y = 0; y < m_pVolume->height()-1; ++y)
			{
				for(uint4 x = 0; x < m_pVolume->width()-1; ++x)
				{                
					m_volUtility.voxelAt(Thermite::Vector3DUint4(x,y,z)) = 0;
				}
			}
		}
		for(uint4 z = 0; z < m_pVolume->depth()-2; ++z)
		{
			for(uint4 y = 0; y < m_pVolume->height()-2; ++y)
			{
				for(uint4 x = 0; x < m_pVolume->width()-2; ++x)
				{
					bool cellOccupied = ((m_pVolume->voxelAt(Thermite::Vector3DUint4(x,y,z)) >= m_fThreshold) ||
						(m_pVolume->voxelAt(Thermite::Vector3DUint4(x,y,z+1)) >= m_fThreshold) ||
						(m_pVolume->voxelAt(Thermite::Vector3DUint4(x,y+1,z)) >= m_fThreshold) ||
						(m_pVolume->voxelAt(Thermite::Vector3DUint4(x,y+1,z+1)) >= m_fThreshold) ||
						(m_pVolume->voxelAt(Thermite::Vector3DUint4(x+1,y,z)) >= m_fThreshold) ||
						(m_pVolume->voxelAt(Thermite::Vector3DUint4(x+1,y,z+1)) >= m_fThreshold) ||
						(m_pVolume->voxelAt(Thermite::Vector3DUint4(x+1,y+1,z)) >= m_fThreshold) ||
						(m_pVolume->voxelAt(Thermite::Vector3DUint4(x+1,y+1,z+1)) >= m_fThreshold));
					if(cellOccupied)
						m_volUtility.voxelAt(Thermite::Vector3DUint4(x,y,z)) = m_volUtility.voxelAt(Thermite::Vector3DUint4(x,y,z)) | CELL_OCCUPIED_FLAG;
				}
			}
		}

		for(uint4 z = 0; z < m_pVolume->depth()-1; ++z)
		{
			for(uint4 y = 0; y < m_pVolume->height()-1; ++y)
			{
				for(uint4 x = 0; x < m_pVolume->width()-1; ++x)
				{
					if((x < 3) || (x > m_pVolume->width()-4) ||
						(y < 3) || (y > m_pVolume->height()-4) ||
						(z < 3) || (z > m_pVolume->depth()-4))
					{
						m_volUtility.voxelAt(Thermite::Vector3DUint4(x,y,z)) = m_volUtility.voxelAt(Thermite::Vector3DUint4(x,y,z)) | NEAR_EDGE_FLAG;
					}
				}
			}
		}    
	}

    template <typename VoxelType>
    void XRayRaycastingRenderer<VoxelType>::initialiseDistanceVolume(void)
    {
        
    }

    template <typename VoxelType>
    void XRayRaycastingRenderer<VoxelType>::generateDepthImage(void)
    {
        std::vector<double> xPositions;
        std::vector<double> yPositions;
        double fMinDepth = std::numeric_limits<double>::infinity();
        uint4 voxelsProjectedToScreen = 0;
        //Project important voxels to screen
        for(uint4 z = 0; z < m_volImportance.depth(); ++z)
        {
            for(uint4 y = 0; y < m_volImportance.height(); ++y)
            {
                for(uint4 x = 0; x < m_volImportance.width(); ++x)
                {
                    if(m_volImportance.voxelAt(Vector3DUint4(x,y,z)) > 0)
                    {
                        Vector3DDouble projectedPos = imageSpacePosition(Vector3DDouble(x,y,z));
                        double fXScreenPos = projectedPos.x();
                        double fYScreenPos = projectedPos.y();

                        if((fXScreenPos > 1) && (fXScreenPos < image().width()-2) && 
                            (fYScreenPos > 1) && (fYScreenPos < image().height()-2))
                        {
                            ++voxelsProjectedToScreen;
                            double depth = projectedPos.z();//(Vector3DDouble(x,y,z) - cameraVal.position()).length();
                            //THERMITE_LOG_DEBUG << voxelsProjectedToScreen << " " << depth <<std::endl;
                            if(depth < fMinDepth)
                            {										
                                fMinDepth = depth;
                            }
                            imageVal.pixelAt(fXScreenPos, fYScreenPos) = RGBA<float>(0.0f,0.0f,1.0f,1.0f);
                        }						

                        xPositions.push_back(fXScreenPos);
                        yPositions.push_back(fYScreenPos);
                    }
                }
            }
        }
        //return;

        fMinDepth = fMinDepth - 1.0f;
        if(voxelsProjectedToScreen == 0)
        {
            fMinDepth = 0.0f;
        }
        THERMITE_LOG_DEBUG << fMinDepth <<std::endl;

        double meanX = 0.0f;
        double meanY = 0.0f;
        for(uint4 ct = 0; ct < xPositions.size(); ++ct)
        {
            meanX += xPositions[ct];
            meanY += yPositions[ct];
        }
        meanX /= xPositions.size();
        meanY /= yPositions.size();

        THERMITE_LOG_DEBUG << "Mean is " << meanX << " " << meanY << std::endl;

        double windowRadius = 0.0f;
        for(uint4 ct = 0; ct < xPositions.size(); ++ct)
        {
            double xDist = static_cast<double>(meanX) - static_cast<double>(xPositions[ct]);
            double yDist = static_cast<double>(meanY) - static_cast<double>(yPositions[ct]);
            double dist = sqrt(xDist*xDist+yDist*yDist);
            if(dist > windowRadius)
            {
                windowRadius = dist;
            }
        }

        THERMITE_LOG_DEBUG << "Window radius = " << windowRadius << std::endl;

        windowRadius += 10.0f;
        double stepBack = fMinDepth / 1.0f;

        for(uint4 imagePosY = 0; imagePosY < imageVal.height(); ++imagePosY)
        {   
            for(uint4 imagePosX = 0; imagePosX < imageVal.width(); ++imagePosX)
            {
                double xDist = static_cast<double>(meanX) - static_cast<double>(imagePosX);
                double yDist = static_cast<double>(meanY) - static_cast<double>(imagePosY);
                double dist = sqrt(xDist*xDist+yDist*yDist);

                dist -= windowRadius;
                dist = Thermite::maximum(0.0f,dist);
                if(dist <= 1.0f)
                    m_imgDepth.pixelAt(imagePosX,imagePosY) = fMinDepth - (dist * stepBack);
                else
                    m_imgDepth.pixelAt(imagePosX,imagePosY) = 0.0f;
            }
        }
    }
}

#undef CELL_OCCUPIED_FLAG
#undef NEAR_EDGE_FLAG
