#include<limits>

namespace Thermite
{
    template <typename VoxelType>
	RaycastingRenderer<VoxelType>::RaycastingRenderer(Thermite::Volume<uint2>* pVolume) throw()
		: VolumeRenderer<SoftwareRenderer, uint2>(pVolume)
	{
		useSobel = false;
		m_fLower = 1000;
		m_fUpper = 2000; 
		frameCounter = 0;

		DensityColourPair node1(0,    RGBA<float>(0.0f,0.0f,1.0f,0.0f));
		DensityColourPair node2(60,   RGBA<float>(0.0f,0.0f,1.0f,0.0f));
		DensityColourPair node3(1060, RGBA<float>(0.0f,1.0f,0.0f,1.0f));
		DensityColourPair node4(1430, RGBA<float>(1.0f,0.0f,0.0f,1.0f));
		DensityColourPair node5(4000, RGBA<float>(1.0f,0.0f,0.0f,1.0f));

		m_TransferFunctionNodes.clear();
		m_TransferFunctionNodes.push_back(node1);
		m_TransferFunctionNodes.push_back(node2);
		m_TransferFunctionNodes.push_back(node3);
		m_TransferFunctionNodes.push_back(node4);
		m_TransferFunctionNodes.push_back(node5);

		computeTransferFunctionFromNodes();

		m_rendScanline = new ScanlineRenderer;		

		Polygon< double > vertices;
		vertices.appendVertex(Vector3DDouble(0.0f,0.0f,m_pVolume->depth()));
		vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,m_pVolume->depth()));
		vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),m_pVolume->depth()));
		vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),m_pVolume->depth()));
		m_rendScanline->addPolygon(vertices);

		vertices.clear();
		vertices.appendVertex(Vector3DDouble(0.0f,0.0f,0.0f));
		vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),0.0f));		
		vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),0.0f));
		vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,0.0f));
		m_rendScanline->addPolygon(vertices);

		vertices.clear();
		vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,m_pVolume->depth()));
		vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,0.0f));		
		vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),0.0f));
		vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),m_pVolume->depth()));
		m_rendScanline->addPolygon(vertices);

		vertices.clear();
		vertices.appendVertex(Vector3DDouble(0.0f,0.0f,m_pVolume->depth()));
		vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),m_pVolume->depth()));
		vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),0.0f));
		vertices.appendVertex(Vector3DDouble(0.0f,0.0f,0.0f));		
		m_rendScanline->addPolygon(vertices);

		vertices.clear();
		vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),0.0f));
		vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),m_pVolume->depth()));
		vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),m_pVolume->depth()));
		vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),0.0f));		
		m_rendScanline->addPolygon(vertices);

		vertices.clear();
		vertices.appendVertex(Vector3DDouble(0.0f,0.0f,0.0f));
		vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,0.0f));		
		vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,m_pVolume->depth()));
		vertices.appendVertex(Vector3DDouble(0.0f,0.0f,m_pVolume->depth()));				
		m_rendScanline->addPolygon(vertices);
	}

    template <typename VoxelType>
	RaycastingRenderer<VoxelType>::~RaycastingRenderer() throw()
	{
	}

    template <typename VoxelType>
	void RaycastingRenderer<VoxelType>::render() throw()
	{
		imageVal.clearTo(RGBA<uint1>(0,0,0,0));
		//imageVal.clearTo(RGBA<float>(1.0f,1.0f,1.0f,1.0f));
		//m_imgDepth.clearTo(0.0f);
		//m_imgDepth.clearTo(std::numeric_limits<double>::infinity());

		++frameCounter;
		THERMITE_LOG_DEBUG << "Frame Counter = " << frameCounter << std::endl;
		m_rendScanline->camera() = cameraVal;
		m_rendScanline->camera().setPosition(m_rendScanline->camera().position() - (cameraVal.forward()*m_pVolume->diagonal()));
		m_rendScanline->render();
		/*THERMITE_LOG_DEBUG << "done scanline rendering" << m_rendScanline->depthImage().width() << std::endl;
		for(uint4 yPos = 0; yPos < imageVal.height(); ++yPos)
		{        
			for(uint4 xPos = 0; xPos < imageVal.width(); ++xPos)
			{
				imageVal.pixelAt(xPos,yPos) = RGBA<float>(
                    m_rendScanline->depthImage().pixelAt(xPos,yPos) / 500.0f,
                    m_rendScanline->depthImage().pixelAt(xPos,yPos) / 500.0f,
                    m_rendScanline->depthImage().pixelAt(xPos,yPos) / 500.0f);
			}
		}
		return;*/

		//Some globalish values.
		const double ambientFactor = 0.3f;
		const double diffuseFactor = 0.6f;
		const double specularFactor = 0.0f;
		const double specularExponent = 20.0f;

		//Camera properties which aren't dependant on image position
		const Vector3DDouble rightZoomed = cameraVal.right() /* cameraVal.zoom()*/;
		const Vector3DDouble upZoomed = cameraVal.up() /* cameraVal.zoom()*/;
		const Vector3DDouble lowerLeftCorner = cameraVal.position() - 
			(cameraVal.forward() * m_pVolume->diagonal()) - 
			(rightZoomed * static_cast<double>(imageVal.width() / 2)) - 
			(upZoomed  * static_cast<double>(imageVal.height() / 2)); 

		//For each pixel in the image:
		for(uint4 yPos = 0; yPos < imageVal.height(); ++yPos)
		{        
			//THERMITE_LOG_DEBUG << yPos << std::endl;
			for(uint4 xPos = 0; xPos < imageVal.width(); ++xPos)
			{
				//Compute the ray direction
				Vector3DDouble xOffset = rightZoomed * static_cast<double>(xPos);
				Vector3DDouble yOffset = upZoomed * static_cast<double>(yPos);
				Vector3DDouble rayPosition = lowerLeftCorner + xOffset + yOffset;
				Vector3DDouble rayDirection = cameraVal.forward();
				rayDirection.normalise();

				if(m_rendScanline->depthImage().pixelAt(xPos,yPos) == std::numeric_limits<double>::infinity())
				{
					continue;
				}
				rayPosition += (rayDirection * m_rendScanline->depthImage().pixelAt(xPos,yPos));

				//Skip forward into volume
				for(uint4 ct = 0; ct < 10; ct++)
				{
					if((rayPosition.x() > 3) && (rayPosition.y() > 3) && (rayPosition.z() > 3) && 
						(rayPosition.x() < m_pVolume->width()-3) && (rayPosition.y() < m_pVolume->height()-3) && (rayPosition.z() < m_pVolume->depth()-3))
					{
						break;
					}
					rayPosition += rayDirection;
				}

				/*double depth = imageSpacePosition(rayPosition).z();
				imageVal(xPos,yPos) = RGBA<float>(depth/500.0f,depth/500.0f,depth/500.0f,1.0f);
				continue;*/

				//Maybe there was no intersection...
				if((rayPosition.x() < 3) || (rayPosition.y() < 3) || (rayPosition.z() < 3) || 
					(rayPosition.x() > m_pVolume->width()-3) || (rayPosition.y() > m_pVolume->height()-3) || (rayPosition.z() > m_pVolume->depth()-3))
				{
					continue;
				}

				RGBA<uint1> runningColour(0,0,0,0);
				while((rayPosition.x() > 3) && (rayPosition.y() > 3) && (rayPosition.z() > 3) && 
					(rayPosition.x() < m_pVolume->width()-3) && (rayPosition.y() < m_pVolume->height()-3) && (rayPosition.z() < m_pVolume->depth()-3) &&
					runningColour.alpha() < 1.0f)
				{        
					double sample = m_pVolume->computeTrilinearlyInterpolatedValueAt(rayPosition);
					RGBA<float> sampleColour;
					/*if(sample > 1700)
					{
					sampleColour = RGBA<float>(1.0,1.0,1.0,1.0);
					}
					else
					{
					sampleColour = RGBA<float>(1.0,1.0,1.0,0.0);
					}*/
					//sampleColour = RGBA<float>(1.0,1.0,1.0,1.0);
					sampleColour = transferFunction[static_cast<uint4>(sample)];
					//Do the lighting
					Vector3DDouble normal; 
					if(useSobel)
					{
						normal = m_pVolume->computeTrilinearlyInterpolatedSobelGradientAt(rayPosition);
					}
					else
					{
						normal = m_pVolume->computeTrilinearlyInterpolatedCentralDifferenceGradientAt(rayPosition);
					}             

					normal.normalise();
					const Vector3DDouble& lightDirection = cameraVal.forward();

					//Ambient component
					const double ambientIntensity = ambientFactor;

					//Diffuse Component
					const double normalDotLight = normal.dot(lightDirection);
					const double diffuseIntensity = (std::max)(normalDotLight, 0.0) * diffuseFactor;

					//Specular Component
					// Schlick's slick approximation for Phong's specular term:
					// Simply replace Sn(t) = t^n with Sn(t) = t / (n - nt + t).
					const double specularIntensity = ((normalDotLight) / (specularExponent - specularExponent*normalDotLight + normalDotLight)) * specularFactor;

					//Total Intensity
					const double totalIntensity = ambientIntensity + diffuseIntensity + specularIntensity;
					sampleColour *= totalIntensity;

					double red = runningColour.red()*runningColour.alpha()*(1-sampleColour.alpha()) + sampleColour.red()*sampleColour.alpha();
					double green = runningColour.green()*runningColour.alpha()*(1-sampleColour.alpha()) + sampleColour.green()*sampleColour.alpha();
					double blue = runningColour.blue()*runningColour.alpha()*(1-sampleColour.alpha()) + sampleColour.blue()*sampleColour.alpha();
					double alpha = runningColour.alpha()*(1-sampleColour.alpha()) + sampleColour.alpha();

					runningColour.set(red,green,blue,alpha);

					rayPosition += rayDirection;
				}

				imageVal.rawData()[yPos * imageVal.width() + xPos] = runningColour;
			}
		}

		//THERMITE_LOG_DEBUG << successRays << "\t" << missedRays << "\t" << missedRays+successRays << std::endl;
	}

    template <typename VoxelType>
	void RaycastingRenderer<VoxelType>::computeTransferFunctionFromNodes(void)
	{
		transferFunction.resize(4200); //NEED TO COMPUTE THIS PROPERLY!

		std::list<DensityColourPair>::iterator first = m_TransferFunctionNodes.begin();
		std::list<DensityColourPair>::iterator second = m_TransferFunctionNodes.begin();
		++second;

		while(second != m_TransferFunctionNodes.end())
		{
			uint4 noInRange = second->m_uDensity - first->m_uDensity;
			uint4 offsetIntoRange = 0;
			double redDelta = (second->m_colColour.red() - first->m_colColour.red()) / static_cast<double>(noInRange);
			double greenDelta = (second->m_colColour.green() - first->m_colColour.green()) / static_cast<double>(noInRange);
			double blueDelta = (second->m_colColour.blue() - first->m_colColour.blue()) / static_cast<double>(noInRange);
			double alphaDelta = (second->m_colColour.alpha() - first->m_colColour.alpha()) / static_cast<double>(noInRange);
			for(uint4 ct = first->m_uDensity; ct < second->m_uDensity; ++ct)
			{
				transferFunction[ct].set(first->m_colColour.red() + redDelta*offsetIntoRange,
					first->m_colColour.green() + greenDelta*offsetIntoRange,
					first->m_colColour.blue() + blueDelta*offsetIntoRange,
					first->m_colColour.alpha() + alphaDelta*offsetIntoRange);
				++offsetIntoRange;
			}
			++first;
			++second;
		}

		//Last node
		transferFunction[first->m_uDensity] = first->m_colColour;

		/*for(uint4 ct = 0; ct < 4100; ct += 20)
		{
		THERMITE_LOG_DEBUG << ct << ": " << transferFunction[ct].red() << "\t" 
		<< transferFunction[ct].green() << "\t"
		<< transferFunction[ct].blue() << "\t"
		<< transferFunction[ct].alpha() << std::endl;
		}*/
	}

    template <typename VoxelType>
	void RaycastingRenderer<VoxelType>::setSize(uint4 uWidth, uint4 uHeight)
	{
		VolumeRenderer<SoftwareRenderer, VoxelType>::setSize(uWidth,uHeight);
		m_rendScanline->setSize(uWidth,uHeight);
	}

#ifdef BLAH

    template <typename VoxelType>
	void RaycastingRenderer<VoxelType>::renderVolumeSidesToDepthBuffer(void)
	{
		Polygon< Vector3DDouble > vertices;
		vertices.push_back(Vector3DDouble(0.0f,0.0f,m_pVolume->depth()));
		vertices.push_back(Vector3DDouble(m_pVolume->width(),0.0f,m_pVolume->depth()));
		vertices.push_back(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),m_pVolume->depth()));
		vertices.push_back(Vector3DDouble(0.0f,m_pVolume->height(),m_pVolume->depth()));
		renderConvexPolygonToDepthBuffer(vertices);

		vertices.clear();
		vertices.push_back(Vector3DDouble(0.0f,0.0f,0.0f));
		vertices.push_back(Vector3DDouble(0.0f,m_pVolume->height(),0.0f));		
		vertices.push_back(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),0.0f));
		vertices.push_back(Vector3DDouble(m_pVolume->width(),0.0f,0.0f));
		renderConvexPolygonToDepthBuffer(vertices);

		vertices.clear();
		vertices.push_back(Vector3DDouble(m_pVolume->width(),0.0f,m_pVolume->depth()));
		vertices.push_back(Vector3DDouble(m_pVolume->width(),0.0f,0.0f));		
		vertices.push_back(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),0.0f));
		vertices.push_back(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),m_pVolume->depth()));
		renderConvexPolygonToDepthBuffer(vertices);

		vertices.clear();
		vertices.push_back(Vector3DDouble(0.0f,0.0f,m_pVolume->depth()));
		vertices.push_back(Vector3DDouble(0.0f,m_pVolume->height(),m_pVolume->depth()));
		vertices.push_back(Vector3DDouble(0.0f,m_pVolume->height(),0.0f));
		vertices.push_back(Vector3DDouble(0.0f,0.0f,0.0f));		
		renderConvexPolygonToDepthBuffer(vertices);

		vertices.clear();
		vertices.push_back(Vector3DDouble(0.0f,m_pVolume->height(),0.0f));
		vertices.push_back(Vector3DDouble(0.0f,m_pVolume->height(),m_pVolume->depth()));
		vertices.push_back(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),m_pVolume->depth()));
		vertices.push_back(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),0.0f));		
		renderConvexPolygonToDepthBuffer(vertices);

		vertices.clear();
		vertices.push_back(Vector3DDouble(0.0f,0.0f,0.0f));
		vertices.push_back(Vector3DDouble(m_pVolume->width(),0.0f,0.0f));		
		vertices.push_back(Vector3DDouble(m_pVolume->width(),0.0f,m_pVolume->depth()));
		vertices.push_back(Vector3DDouble(0.0f,0.0f,m_pVolume->depth()));				
		renderConvexPolygonToDepthBuffer(vertices);
	}

    template <typename VoxelType>
	void RaycastingRenderer<VoxelType>::renderTriangleToDepthBuffer(const Vector3DDouble& v0,const Vector3DDouble& v1,const Vector3DDouble& v2)
	{
		/*double x0,y0,x1,y1,x2,y2;
		imageSpacePosition(v0 - cameraVal.position(),x0,y0);
		imageSpacePosition(v1 - cameraVal.position(),x1,y1);
		imageSpacePosition(v2 - cameraVal.position(),x2,y2);

		imageVal(x0,y0) = RGBA<float>(1.0,1.0,1.0,1.0);
		imageVal(x1,y1) = RGBA<float>(1.0,1.0,1.0,1.0);
		imageVal(x2,y2) = RGBA<float>(1.0,1.0,1.0,1.0);*/
	}

    template <typename VoxelType>
	void RaycastingRenderer<VoxelType>::renderQuadToDepthBuffer(const Vector3DDouble& v0,const Vector3DDouble& v1,const Vector3DDouble& v2,const Vector3DDouble& v3)
	{
		renderTriangleToDepthBuffer(v0,v1,v2);
		renderTriangleToDepthBuffer(v1,v2,v3);
	}

    template <typename VoxelType>
	void RaycastingRenderer<VoxelType>::renderConvexPolygonToDepthBuffer(Polygon< Vector3DDouble > vertices)
	{

		//Find the dot product
		Polygon< Vector3DDouble >::iterator iter = vertices.begin();
		Vector3DDouble vert0 = *iter;
		++iter;
		Vector3DDouble vert1 = *iter;
		++iter;
		Vector3DDouble vert2 = *iter;
		Vector3DDouble v1 = vert2 - vert1;
		Vector3DDouble v2 = vert0 - vert1;
		Vector3DDouble normal = v1.cross(v2);
		if(normal.dot(cameraVal.forward()) >= 0.0f)
		{
			return;
		}
		//Project the vertices into screen space
		iter = vertices.begin();
		Polygon< Vector3DDouble > projectedPositions;
		THERMITE_LOG_DEBUG << "vertices in screen space:" << std::endl;
		do
		{			
			Vector3DDouble imageSpacePos = imageSpacePosition(*iter);
			//imageSpacePos.z() = 1.0f / imageSpacePos.z();
			projectedPositions.push_back(imageSpacePos);
			THERMITE_LOG_DEBUG << "    (" << imageSpacePos.x() << "," << imageSpacePos.y() << ")" << std::endl;
			iter++;
		}while(iter != vertices.end());

		//Identify the top vertex
		Polygon< Vector3DDouble >::iterator iterProjectedPositions;
		iterProjectedPositions = projectedPositions.begin();
		Polygon< Vector3DDouble >::iterator iterTopLeftVertex = projectedPositions.begin();		
		do
		{
			if(iterProjectedPositions->y() > iterTopLeftVertex->y())
			{
				iterTopLeftVertex = iterProjectedPositions;
			}
			++iterProjectedPositions;
		}	while(iterProjectedPositions != projectedPositions.end());	

		//Duplicate the top vertex
		projectedPositions.insert(iterTopLeftVertex,*iterTopLeftVertex);
		Polygon< Vector3DDouble >::iterator iterTopRightVertex = iterTopLeftVertex;
		--iterTopRightVertex;
		THERMITE_LOG_DEBUG << "Top vertices are (" << iterTopLeftVertex->x() << "," << iterTopLeftVertex->y() << ") and  (" << iterTopRightVertex->x() << "," << iterTopRightVertex->y() << ")" << std::endl;
		double currentY = iterTopLeftVertex->y();

		//Calculate heights and deltas
		Polygon< Vector3DDouble >::iterator nextLeft = iterTopLeftVertex;
		++nextLeft;
		/*if(nextLeft == projectedPositions.end())
		{
			nextLeft = projectedPositions.begin();
		}*/
		THERMITE_LOG_DEBUG << "Next left is (" << nextLeft->x() << "," << nextLeft->y() << ")" << std::endl;

		Polygon< Vector3DDouble >::iterator nextRight = iterTopRightVertex;		
		/*if(nextRight == projectedPositions.begin())
		{
			nextRight = projectedPositions.end();
		}*/	
		--nextRight;
		THERMITE_LOG_DEBUG << "Next right is (" << nextRight->x() << "," << nextRight->y() << ")" << std::endl;

		double leftHeight = iterTopLeftVertex->y() - nextLeft->y();
		double rightHeight = iterTopRightVertex->y() - nextRight->y();
		double leftDelta = static_cast<double>(nextLeft->x() - iterTopLeftVertex->x()) / leftHeight;
		double rightDelta = static_cast<double>(nextRight->x() - iterTopRightVertex->x()) / rightHeight;
		double leftDepthDelta = static_cast<double>(nextLeft->z() - iterTopLeftVertex->z()) / leftHeight;
		double rightDepthDelta = static_cast<double>(nextRight->z() - iterTopRightVertex->z()) / rightHeight;

		while(true)
		{
			double height = Thermite::minimum(leftHeight, rightHeight);
			//double height = std::min(iterTopLeftVertex->y() - nextLeft->y(), iterTopRightVertex->y() - nextRight->y());
			THERMITE_LOG_DEBUG << "lheight = " << leftHeight 
				<< " rheight = " << rightHeight
				<< " height = " << height
				<< " ldelta = " << leftDelta 
				<< " rdelta  = " << rightDelta << std::endl;

			//exit(1);

			if(height < 0.0f)
			{
				break;
			}

			for(double i = 0.0f; i < height; i = i + 1.0f)
			{
				//THERMITE_LOG_DEBUG << "rendering span" << std::endl;
				renderSpanToDepthBuffer(iterTopLeftVertex->x(),iterTopLeftVertex->z(), iterTopRightVertex->x(),iterTopRightVertex->z(), currentY);
				--currentY;
				iterTopLeftVertex->x() += leftDelta;
				iterTopRightVertex->x() += rightDelta;
				iterTopLeftVertex->z() += leftDepthDelta;
				iterTopRightVertex->z() += rightDepthDelta;
				--leftHeight;
				--rightHeight;
			}

			if(leftHeight <= 0.0f)
			{
				iterTopLeftVertex = nextLeft;
				++nextLeft;
				/*if(nextLeft == projectedPositions.end())
				{
					nextLeft = projectedPositions.begin();
				}*/
				leftHeight = iterTopLeftVertex->y() - nextLeft->y();
				leftDelta = static_cast<double>(nextLeft->x() - iterTopLeftVertex->x()) / leftHeight;
				leftDepthDelta = static_cast<double>(nextLeft->z() - iterTopLeftVertex->z()) / leftHeight;
				THERMITE_LOG_DEBUG << "Reset: lheight = " << leftHeight << " ldelta = " << leftDelta << std::endl;
			}

			if(rightHeight <= 0.0f)
			{
				iterTopRightVertex = nextRight;
				/*if(nextRight == projectedPositions.begin())
				{
					nextRight = projectedPositions.end();
				}*/	
				--nextRight;
				rightHeight = iterTopRightVertex->y() - nextRight->y();
				rightDelta = static_cast<double>(nextRight->x() - iterTopRightVertex->x()) / rightHeight;
				rightDepthDelta = static_cast<double>(nextRight->z() - iterTopRightVertex->z()) / rightHeight;
				THERMITE_LOG_DEBUG << "Reset: rheight = " << rightHeight << " rdelta = " << rightDelta << std::endl;
			}

			//exit(1);
		}

	}

    template <typename VoxelType>
	void RaycastingRenderer<VoxelType>::renderSpanToDepthBuffer(uint4 x1, double depth1, uint4 x2, double depth2, uint4 y)
	{
		if(y < imageVal.height())
		{
			double xDelta = (depth2 - depth1) / (x2-x1);
			for(uint4 x = x1; x <= x2; ++x)
			{
				if(x < imageVal.width())
				{
					double temp = /*1.0f / */depth1;
					temp /= 500.0f;
					imageVal.pixelAt(x,y) = RGBA<float>(temp,temp,temp,1.0f);
					m_imgDepth.pixelAt(x,y) = depth1;
				}
				depth1 += xDelta;
			}
		}
	}

    template <typename VoxelType>
	Vector3DDouble RaycastingRenderer<VoxelType>::imageSpacePosition(const Vector3DDouble& position)
	{
		//Orthographic projection so this should be easy...
		Vector3DDouble result;
		Vector3DDouble shiftedPosition  = position - cameraVal.position();
		result.x() = shiftedPosition.dot(cameraVal.right());
		result.y() = shiftedPosition.dot(cameraVal.up());

		//Represents the depth
		result.z() = /*1.0f / */((position - (cameraVal.position() - cameraVal.forward()*m_pVolume->diagonal() + cameraVal.right()*result.x() + cameraVal.up()*result.y())).length());

		result.x() += imageVal.width() / 2.0f;
		result.y() += imageVal.height() / 2.0f;

		//THERMITE_LOG_DEBUG << x << " " << y << std::endl;
		return result;
	}

#endif
}
