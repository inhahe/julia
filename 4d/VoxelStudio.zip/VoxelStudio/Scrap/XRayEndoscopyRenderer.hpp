#ifndef XRAYENDOSCOPYRENDERER_HEADER_INCLUDED
#define XRAYENDOSCOPYRENDERER_HEADER_INCLUDED

#include "VolumeRenderer.hpp"
#include "..\Images\RGBA.hpp"
#include "..\Base\Typedef.hpp"

namespace Thermite
{
    template <typename VoxelType>
	class XRayEndoscopyRenderer : public VolumeRenderer<VoxelType >
	{
	public:
		XRayEndoscopyRenderer(Thermite::LinearVolume<uint2>* pVolume,double threshold) throw();
		virtual ~XRayEndoscopyRenderer() throw();
		virtual void render(void) throw();
		bool useSobel;
		void initialiseUtilityVolume(void);
		void initialiseImportanceVolume(void);
		//void setSize(Thermite::uint4 uWidth, Thermite::uint4 uHeight);
	private:
		LinearVolume<uint2> m_volUtility;
		LinearVolume<uint2> m_volImportance;
		double m_fThreshold;
		//Image<bool> importantPixels;
		Image<double> startDepths;

	};
}

#include "XRayEndoscopyRenderer.inl"

#endif
