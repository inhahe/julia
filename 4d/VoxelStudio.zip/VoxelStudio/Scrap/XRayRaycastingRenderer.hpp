#ifndef XRAYRAYCASTINGRENDERER_HEADER_INCLUDED
#define XRAYRAYCASTINGRENDERER_HEADER_INCLUDED

#include <list>
#include <vector>

#include "VolumeRenderer.hpp"
#include "..\Images\RGBA.hpp"
#include "..\Base\Typedef.hpp"

namespace Thermite
{
    template <typename VoxelType>
	class XRayRaycastingRenderer : public VolumeRenderer<VoxelType>
	{
	public:
		XRayRaycastingRenderer(Thermite::LinearVolume<uint2>* pVolume,double fThreshold) throw();
		virtual ~XRayRaycastingRenderer() throw();

		virtual void render(void) throw();
		//void setSize(Thermite::uint4 uWidth, Thermite::uint4 uHeight);
		Vector3DDouble imageSpacePosition(const Vector3DDouble& position); //FIXME - define Vector2D and return this.
		void initialiseImportanceVolume(void);
		void initialiseUtilityVolume(void);
        void initialiseDistanceVolume(void);
	private:
        void generateDepthImage(void);
		double m_fThreshold;
		Image<double> m_imgDepth;      
		LinearVolume<uint2> m_volImportance;
		LinearVolume<uint2> m_volUtility;

	};
}

#include "XRayRaycastingRenderer.inl"

#endif
