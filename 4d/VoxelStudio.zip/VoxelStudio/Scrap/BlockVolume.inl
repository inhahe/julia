#include <algorithm>

namespace Thermite
{
    /*-------------------------------------------------------------------------
    *Constructors, etc.
    *------------------------------------------------------------------------*/

    template <typename Type>
        BlockVolume<Type>::BlockVolume() throw()
        :m_pBlocks(0)
        ,m_uWidthInBlocks(0)
        ,m_uHeightInBlocks(0)
        ,m_uDepthInBlocks(0)
    {
    }

    template <typename Type>
    BlockVolume<Type>::BlockVolume(uint4 widthToSet, uint4 heightToSet, uint4 depthToSet) throw()
        :Volume<Type>(widthToSet, heightToSet, depthToSet)
        ,m_pBlocks(0)
		,m_uWidthInBlocks(0)
        ,m_uHeightInBlocks(0)
        ,m_uDepthInBlocks(0)
    {
        setDimensions(widthToSet,heightToSet,depthToSet);
    }

    /*template <typename Type>
    BlockVolume<Type>::BlockVolume(const BlockVolume<Type>& rhs) throw()
    {
        *this = rhs;
    }*/

    template <typename Type>
    BlockVolume<Type>::~BlockVolume() throw()
    {
        /*if(m_pBlocks != 0)
            delete[] m_pBlocks;*/
    }

    /*-------------------------------------------------------------------------
    *Operations
    *------------------------------------------------------------------------*/

    /**
    *Performs a deep copy.
    */
    /*template <typename Type>
    BlockVolume<Type>& BlockVolume<Type>::operator=(const BlockVolume<Type>& rhs) throw()
    {
        assert(this != &rhs);
        m_uWidth = rhs.m_uWidth;
        m_uHeight = rhs.m_uHeight;
        m_uDepth = rhs.m_uDepth;
        m_pData = new Type[m_uWidth * m_uHeight * m_uDepth];
        std::memcpy(m_pData, rhs.m_pData, sizeof(Type) * m_uWidth * m_uHeight * m_uDepth);
        return *this;
    }*/

    /*-------------------------------------------------------------------------
    *General getters/setters
    *------------------------------------------------------------------------*/

    template <typename Type>
    void BlockVolume<Type>::setDimensions(const uint4 widthToSet,const uint4 heightToSet,const uint4 depthToSet) throw()
    {
        m_uWidth = widthToSet;
        m_uHeight = heightToSet;
        m_uDepth = depthToSet;

        m_uWidthInBlocks = widthToSet / 32;
        if(widthToSet % 32 != 0)
            ++m_uWidthInBlocks;

        m_uHeightInBlocks = heightToSet / 32;
        if(heightToSet % 32 != 0)
            ++m_uHeightInBlocks;

        m_uDepthInBlocks = depthToSet / 32;
        if(depthToSet % 32 != 0)
            ++m_uDepthInBlocks;

        //Allocate the blocks...
        m_pBlocks = new Block[m_uWidthInBlocks * m_uHeightInBlocks * m_uDepthInBlocks];
        for(uint4 ct = 0; ct < (m_uWidthInBlocks * m_uHeightInBlocks * m_uDepthInBlocks); ct++)
        {
            m_pBlocks[ct].setBlockSize(36);
        }
    }

    /*-------------------------------------------------------------------------
    *Value accessors
    *------------------------------------------------------------------------*/

    template <typename Type>
    inline const Type& BlockVolume<Type>::voxelAt(const Vector3DUint4& position) const
    {
        assert((position.x() < m_uWidth) && (position.y() < m_uHeight) && (position.z() < m_uDepth));

        const uint4 blockX = (position.x() >> 5);
        const uint4 blockY = (position.y() >> 5);
        const uint4 blockZ = (position.z() >> 5);

        const uint4 offsetX = (position.x() & 31);
        const uint4 offsetY = (position.y() & 31);
        const uint4 offsetZ = (position.z() & 31);

        const uint4 blockPosition = blockZ * m_uWidthInBlocks * m_uHeightInBlocks + blockY * m_uWidthInBlocks + blockX;
        const uint4 offsetPosition = (offsetZ+2) * 1296 + (offsetY+2) * 36 + (offsetX+2);

        Type* block = m_pBlocks[blockPosition].getRawData();

        return block[offsetPosition];
    }

    template <typename Type>
    inline Type& BlockVolume<Type>::voxelAt(const Vector3DUint4& position)
    {
        assert((position.x() < m_uWidth) && (position.y() < m_uHeight) && (position.z() < m_uDepth));

        const uint4 blockX = (position.x() >> 5);
        const uint4 blockY = (position.y() >> 5);
        const uint4 blockZ = (position.z() >> 5);

        const uint4 offsetX = (position.x() & 31);
        const uint4 offsetY = (position.y() & 31);
        const uint4 offsetZ = (position.z() & 31);

        const uint4 blockPosition = blockZ * m_uWidthInBlocks * m_uHeightInBlocks + blockY * m_uWidthInBlocks + blockX;
        const uint4 offsetPosition = (offsetZ+2) * 1296 + (offsetY+2) * 36 + (offsetX+2);

        Type* block = m_pBlocks[blockPosition].getRawData();

        return block[offsetPosition];
    }

    /*-------------------------------------------------------------------------
    *Interpolated value accessors
    *------------------------------------------------------------------------*/  

    template <typename Type>
        inline double BlockVolume<Type>::computeTrilinearlyInterpolatedValueAt(const Vector3DDouble& position) const throw()
    {
        assert((position.x() <= static_cast<double>(width() - 1)) && (position.x() >= 0.0f)
            && (position.y() <= static_cast<double>(height() - 1)) && (position.y() >= 0.0f)
            && (position.z() <= static_cast<double>(depth() - 1)) && (position.z() >= 0.0f));

        const uint4 floorX = static_cast<uint4>(position.x());
        const uint4 floorY = static_cast<uint4>(position.y());
        const uint4 floorZ = static_cast<uint4>(position.z()); 

        const uint4 blockX = (floorX >> 5);
        const uint4 blockY = (floorY >> 5);
        const uint4 blockZ = (floorZ >> 5);

        const uint4 offsetX = (floorX & 31);
        const uint4 offsetY = (floorY & 31);
        const uint4 offsetZ = (floorZ & 31);

        const uint4 blockPosition = blockZ * m_uWidthInBlocks * m_uHeightInBlocks + blockY * m_uWidthInBlocks + blockX;
        const uint4 offsetPosition = (offsetZ+2) * 1296 + (offsetY+2) * 36 + (offsetX+2);

        Type* block = m_pBlocks[blockPosition].getRawData();

        const Type* v000 = block + offsetPosition;
        const Type* v100 = v000 + 1;
        const Type* v010 = v000 + 36;
        const Type* v110 = v010 + 1;
        const Type* v001 = v000 + 1296;
        const Type* v101 = v001 + 1;
        const Type* v011 = v001 + 36;
        const Type* v111 = v011 + 1;

        return trilinearlyInterpolate<double>(*v000,*v100,*v010,*v110,*v001,*v101,*v011,*v111,position.x() - floorX,position.y() - floorY,position.z() - floorZ);
    }

    /*-------------------------------------------------------------------------
    *Gradient accessors
    *------------------------------------------------------------------------*/

    template <typename Type>
        inline Vector3DInt4 BlockVolume<Type>::computeCentralDifferenceGradientAt(const Vector3DUint4& position) const throw()
    {
        assert((position.x() <= (width()-2)) && (position.x() >= 1)
            && (position.y() <= (height()-2)) && (position.y() >= 1)
            && (position.z() <= (depth()-2)) && (position.z() >= 1));

        const uint4 blockX = (position.x() >> 5);
        const uint4 blockY = (position.y() >> 5);
        const uint4 blockZ = (position.z() >> 5);

        const uint4 offsetX = (position.x() & 31);
        const uint4 offsetY = (position.y() & 31);
        const uint4 offsetZ = (position.z() & 31);

        const uint4 blockPosition = blockZ * m_uWidthInBlocks * m_uHeightInBlocks + blockY * m_uWidthInBlocks + blockX;
        const uint4 offsetPosition = (offsetZ+2) * 1296 + (offsetY+2) * 36 + (offsetX+2);

        Type* block = m_pBlocks[blockPosition].getRawData();

        const Type* pBase = block + offsetPosition;

        const int4 xGrad = (*(pBase + 1)) - (*(pBase - 1));
        const int4 yGrad = (*(pBase + 36)) - (*(pBase - 36));
        const int4 zGrad = (*(pBase + 1296)) - (*(pBase - 1296));

        return Vector3DInt4(xGrad,yGrad,zGrad);
    }

    /*-------------------------------------------------------------------------
    *Interpolated gradient accessors
    *------------------------------------------------------------------------*/

    template <typename Type>
        inline Vector3DDouble BlockVolume<Type>::computeTrilinearlyInterpolatedCentralDifferenceGradientAt(const Vector3DDouble& position) const throw()
    {
        assert((position.x() <= static_cast<double>(width() - 1)) && (position.x() >= 0.0f)
            && (position.y() <= static_cast<double>(height() - 1)) && (position.y() >= 0.0f)
            && (position.z() <= static_cast<double>(depth() - 1)) && (position.z() >= 0.0f));

        const uint4 floorX = static_cast<uint4>(position.x());
        const uint4 floorY = static_cast<uint4>(position.y());
        const uint4 floorZ = static_cast<uint4>(position.z());

        const uint4 ceilX = floorX + 1;
        const uint4 ceilY = floorY + 1;
        const uint4 ceilZ = floorZ + 1;

        const Vector3DInt4 v000 = computeCentralDifferenceGradientAt(Vector3DUint4(floorX, floorY, floorZ));
        const Vector3DInt4 v100 = computeCentralDifferenceGradientAt(Vector3DUint4(ceilX,  floorY, floorZ));
        const Vector3DInt4 v010 = computeCentralDifferenceGradientAt(Vector3DUint4(floorX, ceilY,  floorZ));
        const Vector3DInt4 v110 = computeCentralDifferenceGradientAt(Vector3DUint4(ceilX,  ceilY,  floorZ));
        const Vector3DInt4 v001 = computeCentralDifferenceGradientAt(Vector3DUint4(floorX, floorY, ceilZ));
        const Vector3DInt4 v101 = computeCentralDifferenceGradientAt(Vector3DUint4(ceilX,  floorY, ceilZ));
        const Vector3DInt4 v011 = computeCentralDifferenceGradientAt(Vector3DUint4(floorX, ceilY,  ceilZ));
        const Vector3DInt4 v111 = computeCentralDifferenceGradientAt(Vector3DUint4(ceilX,  ceilY,  ceilZ));

        return trilinearlyInterpolate< Vector3DDouble >(
            static_cast< Vector3DDouble >(v000),
            static_cast< Vector3DDouble >(v100),
            static_cast< Vector3DDouble >(v010),
            static_cast< Vector3DDouble >(v110),
            static_cast< Vector3DDouble >(v001),
            static_cast< Vector3DDouble >(v101),
            static_cast< Vector3DDouble >(v011),
            static_cast< Vector3DDouble >(v111),
            position.x() - floorX,position.y() - floorY,position.z() - floorZ);
    }

    /*-------------------------------------------------------------------------
    *File access
    *------------------------------------------------------------------------*/

    /*template <typename Type>
        bool BlockVolume<Type>::importDAT(const std::string& filename) throw()
    {
		THERMITE_LOG_DEBUG << "Calling base class" << std::endl;
        bool result = Volume<Type>::importDAT(filename);
		THERMITE_LOG_DEBUG << "Finished calling base class" << std::endl;

        //For each block:
        for(uint4 blockZ = 0; blockZ < m_uDepthInBlocks; ++blockZ)
        {
            for(uint4 blockY = 0; blockY < m_uHeightInBlocks; ++blockY)
            {
                for(uint4 blockX = 0; blockX < m_uWidthInBlocks; ++blockX)
                {
                    //THERMITE_LOG_DEBUG << "Block: x = " << blockX << "y = " << blockY << "z = " << blockZ << std::endl;
                    for(int4 offsetZ = -2; offsetZ < 34; ++offsetZ)
                    {
                        for(int4 offsetY = -2; offsetY < 34; ++offsetY)
                        {
                            for(int4 offsetX = -2; offsetX < 34; ++offsetX)
                            {
                                if((offsetX <= -1) || (offsetX >= 32) || (offsetY <= -1) || (offsetY >= 32) || (offsetZ <= -1) || (offsetZ >= 32))
                                {
                                    int4 realX = blockX * 32 + offsetX;
                                    int4 realY = blockY * 32 + offsetY;
                                    int4 realZ = blockZ * 32 + offsetZ;

                                    realX = (realX < 0 ? 0 : realX);
                                    realY = (realY < 0 ? 0 : realY);
                                    realZ = (realZ < 0 ? 0 : realZ);

                                    realX = (realX > m_uWidth-1 ? m_uWidth-1 : realX);
                                    realY = (realY > m_uHeight-1 ? m_uHeight-1 : realY);
                                    realZ = (realZ > m_uDepth-1 ? m_uDepth-1 : realZ);

                                    uint4 blockPosition = blockZ * m_uWidthInBlocks * m_uHeightInBlocks + blockY * m_uWidthInBlocks + blockX;
                                    m_pBlocks[blockPosition].voxelAt(Vector3DInt4(offsetX,offsetY,offsetZ)) = voxelAt(Vector3DUint4(realX,realY,realZ));

                                }
                            }
                        }
                    }
                }
            }
        }

        return result;
    }*/

    

    template <typename Type>
    BlockVolume<Type>::Block::Block() throw()
    :m_pData(0)
    {        
    }

    template <typename Type>
        BlockVolume<Type>::Block::~Block() throw()
    {
        if(m_pData != 0)
            delete[] m_pData;
    }

    template <typename Type>
        void BlockVolume<Type>::Block::setBlockSize(uint4 size) throw()
    {
        if(m_pData != 0)
            delete[] m_pData;
        m_pData = 0;
        m_pData = new Type[size*size*size];
        assert(m_pData != 0);
    }

    template <typename Type>
        inline const Type& BlockVolume<Type>::Block::voxelAt(const Vector3DInt4& position) const
    {
        assert((position.x() >= -2) && (position.y() >= -2) && (position.z() >= -2)
            && (position.x() <= 33) && (position.y() <= 33) && (position.z() <= 33));
        return m_pData[(position.z() + 2) * 36 * 36 + (position.y() + 2) * 36 + (position.x() + 2)];
    }

    template <typename Type>
        inline Type& BlockVolume<Type>::Block::voxelAt(const Vector3DInt4& position)
    {
        assert((position.x() >= -2) && (position.y() >= -2) && (position.z() >= -2)
            && (position.x() <= 33) && (position.y() <= 33) && (position.z() <= 33));
        return m_pData[(position.z() + 2) * 36 * 36 + (position.y() + 2) * 36 + (position.x() + 2)];
    }

    template <typename Type>
        inline Type* BlockVolume<Type>::Block::getRawData(void) const throw()
    {
        return m_pData;
    }
}
