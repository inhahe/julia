#ifndef THERMITE_HEADER_INCLUDED
#define THERMITE_HEADER_INCLUDED

void initThermite(void);

#endif