#include "Thermite.hpp"
#include "Base\Logging.hpp"

void initThermite(void)
{
	THERMITE_LOG_INFO << "Thermite Volume Rendering Engine - By David Williams" << std::endl;
	initLogs();
}