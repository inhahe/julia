#include <boost/log/functions.hpp>

#include "Logging.hpp"

boost::logging::logger thermite("Thermite");

void initLogs()
{
	using namespace boost::logging;

	manipulate_logs("Thermite").add_modifier( prepend_time("$hh:$mm:$ss "), DEFAULT_INDEX + 1 );
	manipulate_logs("Thermite").add_modifier( &prepend_prefix);
	manipulate_logs("Thermite").add_modifier( &append_enter);
	manipulate_logs("Thermite").add_appender( write_to_file("c:\\log.txt") );

	flush_log_cache();
}