#include <fstream>
#include <vector>

#include "Logging.hpp"
#include "PropertyValueMap.hpp"

namespace Thermite
{
	PropertyValueMap::PropertyValueMap()
	{
	}

	PropertyValueMap::PropertyValueMap(const std::string& strFilename)
	{
		load(strFilename);
	}

	PropertyValueMap::~PropertyValueMap() throw()
	{
	}	

	void PropertyValueMap::load(const std::string& strFilename)
	{
		std::fstream streamFile;
		streamFile.open(strFilename.c_str(), std::ios::in);
		if(!streamFile.is_open())
		{
			THERMITE_LOG_ERROR << "Fail to open file " << strFilename;
			return;
		}

		std::string strLine;
		while(!streamFile.eof())
		{
			std::getline(streamFile, strLine, '\n');
			parseLine(strLine);
		}

		streamFile.close();
	}

	void PropertyValueMap::save(const std::string& strFilename)
	{
		std::fstream streamFile;
		streamFile.open(strFilename.c_str(), std::ios::out);
		if(!streamFile.is_open())
		{
			THERMITE_LOG_ERROR << "Fail to open file " << strFilename;
			return;
		}
		
		std::map<std::string, std::string>::iterator iter = m_mapPropVal.begin();
		while(iter != m_mapPropVal.end())
		{
			std::string strLine = iter->first + " = " + iter->second;
			streamFile << strLine << std::endl;
			iter++;
		}

		streamFile.close();
	}

	void PropertyValueMap::parseLine(std::string& strLine)
	{
		if(strLine.length() == 0) //Empty line
		{
			return;
		}

		boost::to_lower(strLine);
		boost::erase_all(strLine, " "); //Remove spaces
		boost::erase_all(strLine, "\t"); //Remove tabs

		if(strLine.at(0) == '#') //Comment
		{
			return;
		}

		std::vector<std::string> vecParts;
		boost::split(vecParts, strLine, boost::is_any_of("="));

		if(vecParts.size() != 2) //Bad line
		{
			return;
		}

		THERMITE_LOG_DEBUG << "Adding property " << vecParts[0] << " = " << vecParts[1];
		m_mapPropVal.insert(make_pair(vecParts[0],vecParts[1]));
	}
}