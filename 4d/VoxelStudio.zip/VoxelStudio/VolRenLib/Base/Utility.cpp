#include <cassert>
#include <cmath>

#include "Utility.hpp"

namespace Thermite
{
    bool is_approx(const double val1, const double val2, const double epsilon) throw()
    {
        return((val1 >= (val2 - epsilon)) && (val1 <= (val2 + epsilon)));
    }

    double diff(const double a, const double b) throw()
    {
        return (a < b ? b-a : a-b);
    }

    double fast_inv_sqrt (double x) throw()
    {
        assert(x >= 0.0f);
        double xhalf = 0.5f*x;
        int i = *(int*)&x;
        i = 0x5f3759df - (i >> 1);
        x = *(double*)&i;
        x = x*(1.5f - xhalf*x*x);
        return x;
    }

    double fast_sqrt(double x) throw()
    {
        assert(x >= 0.0f);
        return 1.0f/(fast_inv_sqrt(x));
    } 

	double linearlyInterpolate(double v1, double v2, double t) throw()
	{
		return v1 + (v2-v1)*t;
	}

	uint4 computeNextPowerOfTwo(const uint4 uInput) throw()
	{
		int4 currentPower = 0;
		while(pow(2.0f,currentPower) < uInput)
		{
			 ++currentPower;
		}
		return pow(2.0f,currentPower);
	}

	double CheckTimer(LARGE_INTEGER iFreq)
	{

		static LARGE_INTEGER oldTimerVal;
		LARGE_INTEGER newTimerVal;

		QueryPerformanceCounter(&newTimerVal);

		LONGLONG diff = newTimerVal.QuadPart-oldTimerVal.QuadPart;

		oldTimerVal = newTimerVal;

		return double(diff)/double(iFreq.QuadPart);
	} 

}//namespace Thermite

