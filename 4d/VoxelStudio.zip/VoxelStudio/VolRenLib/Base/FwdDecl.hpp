#ifndef FWDDECL_HEADER_INCLUDED
#define FWDDECL_HEADER_INCLUDED

#include "Typedef.hpp"

namespace Thermite
{
	//Maths
	template <uint4 Size, typename Type> class Vector;

	//Images
	template <typename Type> class RGBA;

	//Volumes
	template <typename VoxelType> class Volume;

	//Renderers
	class Renderer;
	class HardwareRenderer;
	class SoftwareRenderer;
	template <typename VoxelType> class EndoscopyRenderer;
	template <typename VoxelType> class IPRenderer;
	template <typename VoxelType> class MarchingCubesRenderer;
	template <typename VoxelType> class ShadedSurfaceRenderer;
	template <typename VoxelType> class SliceRenderer;
}

#endif