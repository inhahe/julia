#ifndef PROPERTY_VALUE_MAP_HEADER_INCLUDED
#define PROPERTY_VALUE_MAP_HEADER_INCLUDED

#include <map>

#include <boost\algorithm\string.hpp>
#include <boost\lexical_cast.hpp>
#include <boost\optional.hpp>

#include "Typedef.hpp"

//FIXME - use exceptions?
namespace Thermite
{
	class PropertyValueMap
	{
	public:
		PropertyValueMap();
		PropertyValueMap(const std::string& strFilename);
		~PropertyValueMap() throw();

		template <typename Type>
		boost::optional<Type> getValueAs(std::string strProperty);
		template <typename Type>
		void addPropertyValuePair(std::string strProperty, const Type& tValue);

		void load(const std::string& strFilename);
		void save(const std::string& strFilename);

	private:
		std::map<std::string, std::string> m_mapPropVal;

		//Parsing functions
		void parseLine(std::string& strLine);
	};

	template <typename Type>
		boost::optional<Type> PropertyValueMap::getValueAs(std::string strProperty)
	{
		boost::to_lower(strProperty);
		std::map<std::string, std::string>::iterator iterMap = m_mapPropVal.find(strProperty);

		//Return empty if the value wasn't found
		if(iterMap == m_mapPropVal.end())
		{
			THERMITE_LOG_WARN << "Failed to find property " << strProperty;
			return boost::optional<Type>();
		}

		try
		{
			return boost::optional<Type>(boost::lexical_cast<Type>(iterMap->second));
		}
		catch(boost::bad_lexical_cast &)
		{
			THERMITE_LOG_WARN << "Cast failed when converting " << iterMap->second;
			return boost::optional<Type>();
		}		
	}

	template <typename Type>
		void PropertyValueMap::addPropertyValuePair(std::string strProperty, const Type& tValue)
	{
		boost::to_lower(strProperty);
		std::string strValue;
		
		try
		{
			strValue = boost::lexical_cast<std::string>(tValue);
		}
		catch(boost::bad_lexical_cast &)
		{
			THERMITE_LOG_WARN << "Cast failed when converting " << tValue;
			return;
		}

		m_mapPropVal.insert(make_pair(strProperty,strValue));
	}
}

#endif