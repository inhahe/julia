#ifndef UTILITY_H
#define UTILITY_H

#include "windows.h"


#include "Typedef.hpp"

namespace Thermite
{
    bool is_approx(const double val1, const double val2, const double epsilon = 0.001f) throw();
    double diff(const double a, const double b) throw();
    double fast_inv_sqrt (double x) throw();
    double fast_sqrt (double x) throw();
	double linearlyInterpolate(double v1, double v2, double t) throw();
	uint4 computeNextPowerOfTwo(const uint4 uInput) throw();

	template <typename Type>
        Type trilinearlyInterpolate(
        const Type& v000,const Type& v100,
        const Type& v010,const Type& v110,
        const Type& v001,const Type& v101,
        const Type& v011,const Type& v111,
        const double x, const double y, const double z);

	template <typename Type>
        Type trilinearlyInterpolate(
        const Type& v000,const Type& v100,const Type& v010,const Type& v110,
        const Type& v001,const Type& v101,const Type& v011,const Type& v111,
        const double x, const double y, const double z)
    {
        assert((x >= 0.0f) && (y >= 0.0f) && (z >= 0.0f) && 
            (x <= 1.0f) && (y <= 1.0f) && (z <= 1.0f));

		//Interpolate along X
		Type v000_v100 = (v100 - v000) * x + v000;
		Type v001_v101 = (v101 - v001) * x + v001;
		Type v010_v110 = (v110 - v010) * x + v010;
		Type v011_v111 = (v111 - v011) * x + v011;

		//Interpolate along Y
		Type v000_v100__v010_v110 = (v010_v110 - v000_v100) * y + v000_v100;
		Type v001_v101__v011_v111 = (v011_v111 - v001_v101) * y + v001_v101;

		//Interpolate along Z
		Type v000_v100__v010_v110____v001_v101__v011_v111 = (v001_v101__v011_v111 - v000_v100__v010_v110) * z + v000_v100__v010_v110;

		return v000_v100__v010_v110____v001_v101__v011_v111;
    }

	double CheckTimer(LARGE_INTEGER iFreq);
}//namespace Thermite

#endif
