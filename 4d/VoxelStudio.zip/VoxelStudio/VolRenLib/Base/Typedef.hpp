#ifndef TYPEDEF_HEADER_INCLUDED
#define TYPEDEF_HEADER_INCLUDED

namespace Thermite
{
    typedef char int1;
    typedef short int2;
    typedef long int4;

    typedef unsigned char uint1;
    typedef unsigned short uint2;
    typedef unsigned long uint4;    
}

#endif
