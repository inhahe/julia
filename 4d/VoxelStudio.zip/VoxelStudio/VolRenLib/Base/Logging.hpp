#ifndef LOGGING_HEADER_INCLUDED
#define LOGGING_HEADER_INCLUDED

//Include boost logging
#include <boost/log/log.hpp>

//The log file
extern boost::logging::logger thermite;

//Initialises the log file
void initLogs();

//Macros to write messages
#define THERMITE_LOG_DEBUG BOOST_SCOPEDLOGL(thermite, dbg)   << "DEBUG: "
#define THERMITE_LOG_INFO  BOOST_SCOPEDLOGL(thermite, info)  << "INFO : "
#define THERMITE_LOG_WARN  BOOST_SCOPEDLOGL(thermite, warn)  << "WARN : "
#define THERMITE_LOG_ERROR BOOST_SCOPEDLOGL(thermite, err)   << "ERROR: "
#define THERMITE_LOG_FATAL BOOST_SCOPEDLOGL(thermite, fatal) << "FATAL: "

#endif