#ifndef EXCEPTIONS_HEADER_INCLUDED
#define EXCEPTIONS_HEADER_INCLUDED

#include <stdexcept>

namespace Thermite
{
	class file_error : public std::logic_error
	{
	public:
		file_error(const std::string& strWhat)
			:logic_error(strWhat)
		{
		}
	};
}

#endif