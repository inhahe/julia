TEMPLATE = lib
CONFIG += staticlib
CONFIG -= qt

INCLUDEPATH = c:\Boost\include\boost-1_33_1

SOURCES += Thermite.cpp
SOURCES += Base\Logging.cpp
SOURCES += Renderers\Camera.cpp
SOURCES += Volumes\ReconstructionFilter.cpp
SOURCES += Base\Utility.cpp

DESTDIR = ..\exe