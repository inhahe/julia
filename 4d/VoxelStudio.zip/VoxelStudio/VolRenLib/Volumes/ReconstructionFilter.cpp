#include "ReconstructionFilter.hpp"

#include <cmath>

namespace Thermite
{
	ReconstructionFilter* ReconstructionFilter::createLinearInterpolationFilter(void) throw()
	{
		ReconstructionFilter* filterToBuild = new ReconstructionFilter(2,2);

		filterToBuild->m_vecFilter[1][0] = 1.0f;
		filterToBuild->m_vecFilter[1][1] = 0.0f;
		filterToBuild->m_vecFilter[0][0] = -1.0f;
		filterToBuild->m_vecFilter[0][1] = 1.0f;

		return filterToBuild;
	}

	ReconstructionFilter* ReconstructionFilter::createCatmullRomInterpolationFilter(void) throw()
	{
		ReconstructionFilter* filterToBuild = new ReconstructionFilter(4,4);

		filterToBuild->m_vecFilter[0][0] = -0.5f;
		filterToBuild->m_vecFilter[0][1] = 1.0f;
		filterToBuild->m_vecFilter[0][2] = -0.5f;
		filterToBuild->m_vecFilter[0][3] = 0.0f;

		filterToBuild->m_vecFilter[1][0] = 1.5f;
		filterToBuild->m_vecFilter[1][1] = -2.5f;
		filterToBuild->m_vecFilter[1][2] = 0.0f;
		filterToBuild->m_vecFilter[1][3] = 1.0f;

		filterToBuild->m_vecFilter[2][0] = -1.5f;
		filterToBuild->m_vecFilter[2][1] = 2.0f;
		filterToBuild->m_vecFilter[2][2] = 0.5f;
		filterToBuild->m_vecFilter[2][3] = 0.0f;

		filterToBuild->m_vecFilter[3][0] = 0.5f;
		filterToBuild->m_vecFilter[3][1] = -0.5f;
		filterToBuild->m_vecFilter[3][2] = 0.0f;
		filterToBuild->m_vecFilter[3][3] = 0.0f;

		return filterToBuild;
	}

	ReconstructionFilter* ReconstructionFilter::createFirstDerivativeFilter(void) throw()
	{
		ReconstructionFilter* filterToBuild = new ReconstructionFilter(4,2);		

		filterToBuild->m_vecFilter[0][0] = 0.5f;
		filterToBuild->m_vecFilter[0][1] = -0.5f;

		filterToBuild->m_vecFilter[1][0] = -0.5f;
		filterToBuild->m_vecFilter[1][1] = 0.0f;

		filterToBuild->m_vecFilter[2][0] = -0.5f;
		filterToBuild->m_vecFilter[2][1] = 0.5f;

		filterToBuild->m_vecFilter[3][0] = 0.5f;
		filterToBuild->m_vecFilter[3][1] = 0.0f;

		return filterToBuild;
	}

	ReconstructionFilter* ReconstructionFilter::createHighQualityFirstDerivativeFilter(void) throw()
	{
		ReconstructionFilter* filterToBuild = new ReconstructionFilter(6,7);		

		filterToBuild->m_vecFilter[0][0] = 0.25f;
		filterToBuild->m_vecFilter[0][1] = -0.75f;
		filterToBuild->m_vecFilter[0][2] = 7.0f/12.0f;
		filterToBuild->m_vecFilter[0][3] = 0.16666f;
		filterToBuild->m_vecFilter[0][4] = -0.25;
		filterToBuild->m_vecFilter[0][5] = -1.0f/12.0f;
		filterToBuild->m_vecFilter[0][6] = 1.0f/12.0f;

		filterToBuild->m_vecFilter[1][0] = -5.0f/4.0f;
		filterToBuild->m_vecFilter[1][1] = 15.0f/4.0f;;
		filterToBuild->m_vecFilter[1][2] = -35.0f/12.0f;
		filterToBuild->m_vecFilter[1][3] = -2.0f/3.0f;
		filterToBuild->m_vecFilter[1][4] = 1.0f/2.0f;
		filterToBuild->m_vecFilter[1][5] = 4.0f/3.0f;
		filterToBuild->m_vecFilter[1][6] = -2.0f/3.0f;

		filterToBuild->m_vecFilter[2][0] = 5.0f/2.0f;
		filterToBuild->m_vecFilter[2][1] = -15.0f/2.0f;;
		filterToBuild->m_vecFilter[2][2] = 35.0f/6.0f;
		filterToBuild->m_vecFilter[2][3] = 1.0f;
		filterToBuild->m_vecFilter[2][4] = 0.0f;
		filterToBuild->m_vecFilter[2][5] = -5.0f/2.0f;
		filterToBuild->m_vecFilter[2][6] = 0.0f;

		filterToBuild->m_vecFilter[3][0] = -5.0f/2.0f;
		filterToBuild->m_vecFilter[3][1] = 15.0f/2.0f;
		filterToBuild->m_vecFilter[3][2] = -35.0f/6.0;
		filterToBuild->m_vecFilter[3][3] = -2.0f/3.0f;
		filterToBuild->m_vecFilter[3][4] = -1.0f/2.0f;
		filterToBuild->m_vecFilter[3][5] = 4.0f/3.0f;
		filterToBuild->m_vecFilter[3][6] = 2.0f/3.0f;

		filterToBuild->m_vecFilter[4][0] = 5.0f/4.0f;
		filterToBuild->m_vecFilter[4][1] = -15.0f/4.0f;;
		filterToBuild->m_vecFilter[4][2] = 35.0f/12.0f;
		filterToBuild->m_vecFilter[4][3] = 1.0f/6.0f;
		filterToBuild->m_vecFilter[4][4] = 1.0f/4.0f;
		filterToBuild->m_vecFilter[4][5] = -1.0f/12.0f;
		filterToBuild->m_vecFilter[4][6] = -1.0f/12.0f;

		filterToBuild->m_vecFilter[5][0] = -0.25f;
		filterToBuild->m_vecFilter[5][1] = 0.75f;
		filterToBuild->m_vecFilter[5][2] = -7.0f/12.0f;
		filterToBuild->m_vecFilter[5][3] = 0.0f;
		filterToBuild->m_vecFilter[5][4] = 0.0f;
		filterToBuild->m_vecFilter[5][5] = 0.0f;
		filterToBuild->m_vecFilter[5][6] = 0.0f;


		return filterToBuild;
	}

	ReconstructionFilter* ReconstructionFilter::createSecondDerivativeFilter(void) throw()
	{
		ReconstructionFilter* filterToBuild = new ReconstructionFilter(6,2);		

		filterToBuild->m_vecFilter[5][0] = 0.25f;
		filterToBuild->m_vecFilter[5][1] = 0.0f;

		filterToBuild->m_vecFilter[4][0] = -0.25f;
		filterToBuild->m_vecFilter[4][1] = 0.25f;

		filterToBuild->m_vecFilter[3][0] = -0.5f;
		filterToBuild->m_vecFilter[3][1] = 0.0f;

		filterToBuild->m_vecFilter[2][0] = 0.5f;
		filterToBuild->m_vecFilter[2][1] = -0.5f;

		filterToBuild->m_vecFilter[1][0] = 0.25f;
		filterToBuild->m_vecFilter[1][1] = 0.0f;

		filterToBuild->m_vecFilter[0][0] = -0.25f;
		filterToBuild->m_vecFilter[0][1] = 0.25f;

		return filterToBuild;
	}

	ReconstructionFilter::ReconstructionFilter(uint4 uNoOfWeights, uint4 uNoOfCoefficients)
	{
		m_vecFilter.resize(uNoOfWeights);
		std::vector< std::vector< double > >::iterator weightsIter = m_vecFilter.begin();
		while(weightsIter != m_vecFilter.end())
		{
			weightsIter->resize(uNoOfCoefficients);
			++weightsIter;
		}
	}

	/*ReconstructionFilter::ReconstructionFilter(const uint4 size, const uint4 noOfCoefficients) throw()
	{
		m_vecFilter.resize(size);
		std::vector< std::vector< double > >::iterator weightsIter = m_vecFilter.begin();
		while(weightsIter != m_vecFilter.end())
		{
			weightsIter->resize(noOfCoefficients);
			++weightsIter;
		}*/

		//First derivitive
		/*m_vecFilter[0][0] = 0.5f;
		m_vecFilter[0][1] = -0.5f;

		m_vecFilter[1][0] = -0.5f;
		m_vecFilter[1][1] = 0.0f;

		m_vecFilter[2][0] = -0.5f;
		m_vecFilter[2][1] = 0.5f;

		m_vecFilter[3][0] = 0.5f;
		m_vecFilter[3][1] = 0.0f;*/

		//Second Derivitive
		/*m_vecFilter[5][0] = 0.25f;
		m_vecFilter[5][1] = 0.0f;

		m_vecFilter[4][0] = -0.25f;
		m_vecFilter[4][1] = 0.25f;

		m_vecFilter[3][0] = -0.5f;
		m_vecFilter[3][1] = 0.0f;

		m_vecFilter[2][0] = 0.5f;
		m_vecFilter[2][1] = -0.5f;

		m_vecFilter[1][0] = 0.25f;
		m_vecFilter[1][1] = 0.0f;

		m_vecFilter[0][0] = -0.25f;
		m_vecFilter[0][1] = 0.25f;*/

	//}

	uint4 ReconstructionFilter::size(void) const throw()
	{
		return m_vecFilter.size();
	}

	double& ReconstructionFilter::tau(void) throw()
	{
		return m_fTau;
	}

	double ReconstructionFilter::weightAt(const int4 iWeightIndex) const throw()
	{
		double fWeight = 0.0f;
		for(uint4 coefficient = 0; coefficient < m_vecFilter[iWeightIndex].size(); ++coefficient)
		{
			uint4 exponent = m_vecFilter[iWeightIndex].size() - 1 - coefficient;
			fWeight += m_vecFilter[iWeightIndex][coefficient] * pow(m_fTau,static_cast<int4>(exponent));
		}
		return fWeight;
	}
}