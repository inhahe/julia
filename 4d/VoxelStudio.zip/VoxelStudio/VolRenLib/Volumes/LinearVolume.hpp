#ifndef LINEAR_VOLUME_HEADER_INCLUDED
#define LINEAR_VOLUME_HEADER_INCLUDED

#include <fstream> //For file access

#include "Volume.hpp" //Base class

namespace Thermite
{
    template <typename Type>
    class LinearVolume : public Volume<Type>
    {
    public:
        //Constructors, etc. FIXME - call base class constructors.
        LinearVolume() throw();
        LinearVolume(uint4 widthToSet, uint4 heightToSet, uint4 depthToSet) throw();
		template <typename CastType> LinearVolume(const LinearVolume<CastType>& volumeToSet) throw();
        LinearVolume(const LinearVolume& rhs) throw();
        ~LinearVolume() throw();

        //Operators
        LinearVolume<Type>& operator=(const LinearVolume<Type>& rhs) throw();

        //General getters/setters
        void setDimensions(const uint4 widthToSet,const uint4 heightToSet,const uint4 depthToSet) throw(std::bad_alloc);

        //Value accessors
        const Type& voxelAt(const Vector3DUint4& position) const throw();
        Type& voxelAt(const Vector3DUint4& position) throw();
        const Type& voxelAtSafe(const Vector3DUint4& position) const throw();
        Type& voxelAtSafe(const Vector3DUint4& position) throw();

        //Interpolated value accessors
        double computeTrilinearlyInterpolatedValueAt(const Vector3DDouble& position) const throw();

        //Gradient accesors
        Vector3DInt4 computeCentralDifferenceGradientAt(const Vector3DUint4& position) const throw();

        //Interpolated gradient accessors
        Vector3DDouble computeTrilinearlyInterpolatedCentralDifferenceGradientAt(const Vector3DDouble& position) const throw();

		//Other
		virtual bool cellCornersBelowThreshold(const Vector3DDouble& position, const Type& tThreshold) const throw();

    protected:
        //Internal data
        Type* m_pData;       
    };
    
}//namespace Thermite

#include "LinearVolume.inl"

#endif	//LINEAR_VOLUME_HEADER_INCLUDED

