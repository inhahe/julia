#ifndef OCTREENODE_HEADER_INCLUDED
#define OCTREENODE_HEADER_INCLUDED

#include "..\Maths\Vector.hpp"

namespace Thermite
{
    template <typename Type>
    class OctreeNode
    {
	public:
		OctreeNode();
		bool containsPoint(const Vector3DDouble& point) const;

		bool isLeaf(void) const throw();
		void setIsLeaf(bool bIsLeaf) throw();

		uint1 depth(void) const throw();
		void setDepth(uint1 uDepth) throw();

		const Vector3DDouble& maxPosition(void) const throw();
		Vector3DDouble& maxPosition(void) throw();
		const Vector3DDouble& minPosition(void) const throw();
		Vector3DDouble& minPosition(void) throw();

		const Type& maxVoxelValue(void) const throw();
		Type& maxVoxelValue(void) throw();
		const Type& minVoxelValue(void) const throw();
		Type& minVoxelValue(void) throw();

		bool m_bChanged;

		

	private:
		bool m_bIsLeaf;
		Type m_tMinVoxelValue;
		Type m_tMaxVoxelValue;
		Vector3DDouble m_vecMinPos;
		Vector3DDouble m_vecMaxPos;
		uint1 m_uDepth;
		
	};
}

#include "OctreeNode.inl"

#endif