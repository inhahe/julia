#ifndef VOLUMEPROCESSOR_HEADER_INCLUDED
#define VOLUMEPROCESSOR_HEADER_INCLUDED

#include <boost/function.hpp>

#include "LinearVolume.hpp"

namespace Thermite
{
	template <typename Type>
	class VolumeProcessor
	{
	public:
		static std::vector< std::vector< Vector3DDouble > > extractMeshForIsosurface(const Volume<Type>* pVolume, const double fIsovalue, boost::function<void (std::string, double)> progress = 0);
		static std::vector< std::vector< Vector3DDouble > > extractMeshForIsosurfaceForCell(const Volume<Type>* pVolume, Vector3DUint4 cell, const double fIsovalue);
	private:
		static Vector3DDouble VertexInterpolateBasic(const Volume<Type>* pVolume, Vector3DUint4 p1,Vector3DUint4 p2,const double fIsovalue);	
	};
}

#include "VolumeProcessor.inl"

#endif