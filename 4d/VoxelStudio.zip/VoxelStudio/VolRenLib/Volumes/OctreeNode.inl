#include <limits>

namespace Thermite
{
	template<typename Type>
	OctreeNode<Type>::OctreeNode()
	:m_tMaxVoxelValue((std::numeric_limits<Type>::max)())
	,m_tMinVoxelValue((std::numeric_limits<Type>::min)())
	{
	}	

	template<typename Type>
	bool OctreeNode<Type>::containsPoint(const Vector3DDouble& point) const
	{
		return ((point.x() >= m_vecMinPos.x()) && (point.y() >= m_vecMinPos.y()) && (point.z() >= m_vecMinPos.z()) &&
			(point.x() < m_vecMaxPos.x()) && (point.y() < m_vecMaxPos.y()) && (point.z() < m_vecMaxPos.z()));
	}

	template<typename Type>
	bool OctreeNode<Type>::isLeaf(void) const throw()
	{
		return m_bIsLeaf;
	}

	template<typename Type>
	void OctreeNode<Type>::setIsLeaf(bool bIsLeaf) throw()
	{
		m_bIsLeaf = bIsLeaf;
	}

	template<typename Type>
	const Type& OctreeNode<Type>::maxVoxelValue(void) const throw()
	{
		return m_tMaxVoxelValue;
	}

	template<typename Type>
		Type& OctreeNode<Type>::maxVoxelValue(void) throw()
	{
		return m_tMaxVoxelValue;
	}

	template<typename Type>
		const Type& OctreeNode<Type>::minVoxelValue(void) const throw()
	{
		return m_tMinVoxelValue;
	}

	template<typename Type>
		Type& OctreeNode<Type>::minVoxelValue(void) throw()
	{
		return m_tMinVoxelValue;
	}

	template<typename Type>
	const Vector3DDouble& OctreeNode<Type>::maxPosition(void) const throw()
	{
		return m_vecMaxPos;
	}

	template<typename Type>
		Vector3DDouble& OctreeNode<Type>::maxPosition(void) throw()
	{
		return m_vecMaxPos;
	}

	template<typename Type>
		const Vector3DDouble& OctreeNode<Type>::minPosition(void) const throw()
	{
		return m_vecMinPos;
	}

	template<typename Type>
		Vector3DDouble& OctreeNode<Type>::minPosition(void) throw()
	{
		return m_vecMinPos;
	}

	template<typename Type>
		uint1 OctreeNode<Type>::depth(void) const throw()
	{
		return m_uDepth;
	}

	template<typename Type>
		void OctreeNode<Type>::setDepth(uint1 uDepth) throw()
	{
		m_uDepth = uDepth;
	}
}