#include "OctreeNode.hpp"
#include "Volume.hpp"
#include "..\Base\Utility.hpp"

namespace Thermite
{
	template<typename Type>
	Octree<Type>::Octree(const Volume<Type>& pVolume)
		:m_Volume(pVolume)
	{
	}

	template<typename Type>
		Octree<Type>::~Octree()
	{
		m_vecNodes.clear();
	}

	template<typename Type>
	uint4 Octree<Type>::buildOctree(boost::function<void (std::string, double)> progress) throw()
	{
		if(progress)
		{
			progress("Building Octree",0.0);
		}
		OctreeNode<Type> nodeRoot;
		nodeRoot.minPosition() = Vector3DDouble(0.0f,0.0f,0.0f);
		nodeRoot.maxPosition() = Vector3DDouble(
			static_cast<double>(m_Volume.width()-1.0f),
			static_cast<double>(m_Volume.height()-1.0f),
			static_cast<double>(m_Volume.depth()-1.0f));
		nodeRoot.setDepth(0);
		m_vecNodes.clear();
		m_vecNodes.push_back(nodeRoot);
		
		//The m_vecNodes vector grows as we iterate over it...
		for(uint4 ct = 0; ct < m_vecNodes.size(); ++ct)
		{
			Vector3DDouble vecNodeSize = (m_vecNodes[ct].maxPosition() - m_vecNodes[ct].minPosition());
			if((vecNodeSize.x() * vecNodeSize.y() * vecNodeSize.z()) > 512.0)
			{
				vecNodeSize /= 2;

				OctreeNode<Type> node000;
				node000.minPosition() = Vector3DDouble(m_vecNodes[ct].minPosition().x(),m_vecNodes[ct].minPosition().y(),m_vecNodes[ct].minPosition().z());
				node000.maxPosition() = node000.minPosition() + vecNodeSize;
				node000.setDepth(m_vecNodes[ct].depth() + 1);
				m_vecNodes.push_back(node000);

				OctreeNode<Type> node001;
				node001.minPosition() = Vector3DDouble(m_vecNodes[ct].minPosition().x(),m_vecNodes[ct].minPosition().y(),m_vecNodes[ct].minPosition().z() + vecNodeSize.z());
				node001.maxPosition() = node001.minPosition() + vecNodeSize;
				node001.setDepth(m_vecNodes[ct].depth() + 1);
				m_vecNodes.push_back(node001);

				OctreeNode<Type> node010;
				node010.minPosition() = Vector3DDouble(m_vecNodes[ct].minPosition().x(),m_vecNodes[ct].minPosition().y() + vecNodeSize.y(),m_vecNodes[ct].minPosition().z());
				node010.maxPosition() = node010.minPosition() + vecNodeSize;
				node010.setDepth(m_vecNodes[ct].depth() + 1);
				m_vecNodes.push_back(node010);

				OctreeNode<Type> node011;
				node011.minPosition() = Vector3DDouble(m_vecNodes[ct].minPosition().x(),m_vecNodes[ct].minPosition().y() + vecNodeSize.y(),m_vecNodes[ct].minPosition().z() + vecNodeSize.z());
				node011.maxPosition() = node011.minPosition() + vecNodeSize;
				node011.setDepth(m_vecNodes[ct].depth() + 1);
				m_vecNodes.push_back(node011);

				OctreeNode<Type> node100;
				node100.minPosition() = Vector3DDouble(m_vecNodes[ct].minPosition().x() + vecNodeSize.x(),m_vecNodes[ct].minPosition().y(),m_vecNodes[ct].minPosition().z());
				node100.maxPosition() = node100.minPosition() + vecNodeSize;
				node100.setDepth(m_vecNodes[ct].depth() + 1);
				m_vecNodes.push_back(node100);

				OctreeNode<Type> node101;
				node101.minPosition() = Vector3DDouble(m_vecNodes[ct].minPosition().x() + vecNodeSize.x(),m_vecNodes[ct].minPosition().y(),m_vecNodes[ct].minPosition().z() + vecNodeSize.z());
				node101.maxPosition() = node101.minPosition() + vecNodeSize;
				node101.setDepth(m_vecNodes[ct].depth() + 1);
				m_vecNodes.push_back(node101);

				OctreeNode<Type> node110;
				node110.minPosition() = Vector3DDouble(m_vecNodes[ct].minPosition().x() + vecNodeSize.x(),m_vecNodes[ct].minPosition().y() + vecNodeSize.y(),m_vecNodes[ct].minPosition().z());
				node110.maxPosition() = node110.minPosition() + vecNodeSize;
				node110.setDepth(m_vecNodes[ct].depth() + 1);
				m_vecNodes.push_back(node110);

				OctreeNode<Type> node111;
				node111.minPosition() = Vector3DDouble(m_vecNodes[ct].minPosition().x() + vecNodeSize.x(),m_vecNodes[ct].minPosition().y() + vecNodeSize.y(),m_vecNodes[ct].minPosition().z() + vecNodeSize.z());
				node111.maxPosition() = node111.minPosition() + vecNodeSize;
				node111.setDepth(m_vecNodes[ct].depth() + 1);
				m_vecNodes.push_back(node111);

				m_vecNodes[ct].setIsLeaf(false);
			}
			else
			{
				m_vecNodes[ct].setIsLeaf(true);
			}
		}

		for(uint4 ct = m_vecNodes.size()-1; ct < (std::numeric_limits<uint4>::max)(); --ct) //FIXME - works because of wrap around - should probably use iterators...
		{
			if(progress)
			{
				progress("Building Octree...",1.0 - (static_cast<double>(ct) / static_cast<double>(m_vecNodes.size())));
			}

			if(m_vecNodes[ct].isLeaf() == false)
			{
				m_vecNodes[ct].minVoxelValue() = (std::numeric_limits<Type>::max)();
				m_vecNodes[ct].maxVoxelValue() = (std::numeric_limits<Type>::min)();
				for(int childCt = 1; childCt <= 8; ++childCt)
				{
					m_vecNodes[ct].minVoxelValue() = (std::min)(m_vecNodes[ct].minVoxelValue(),m_vecNodes[ct*8+childCt].minVoxelValue());
					m_vecNodes[ct].maxVoxelValue() = (std::max)(m_vecNodes[ct].maxVoxelValue(),m_vecNodes[ct*8+childCt].maxVoxelValue());
				}
			}
			else
			{
				m_vecNodes[ct].minVoxelValue() = (std::numeric_limits<Type>::max)();
				m_vecNodes[ct].maxVoxelValue() = (std::numeric_limits<Type>::min)();
				for(int4 z = floor(m_vecNodes[ct].minPosition().z()); z <= ceil(m_vecNodes[ct].maxPosition().z()); ++z)
				{
					for(int4 y = floor(m_vecNodes[ct].minPosition().y()); y <= ceil(m_vecNodes[ct].maxPosition().y()); ++y)
					{
						for(int4 x = floor(m_vecNodes[ct].minPosition().x()); x <= ceil(m_vecNodes[ct].maxPosition().x()); ++x)
						{						
							if((x >= 0) && (y >= 0) && (z >= 0) && 
								(x < m_Volume.width()) && (y < m_Volume.height()) && (z < m_Volume.depth()))
							{
								//FIXME - use boost::minmax here?
								m_vecNodes[ct].minVoxelValue() = (std::min)(m_vecNodes[ct].minVoxelValue(), m_Volume.voxelAt(Vector3DUint4(x,y,z)));
								m_vecNodes[ct].maxVoxelValue() = (std::max)(m_vecNodes[ct].maxVoxelValue(), m_Volume.voxelAt(Vector3DUint4(x,y,z)));
							}
						}
					}
				}
			}
			m_vecNodes[ct].m_bChanged = false;
		}

		return m_vecNodes.size();
	}

	template<typename Type>
	void Octree<Type>::repairOctree(void)
	{
		for(uint4 ct = m_vecNodes.size()-1; ct < (std::numeric_limits<uint4>::max)(); --ct) //FIXME - works because of wrap around - should probably use iterators...
		{
			if(m_vecNodes[ct].m_bChanged)
			{
				if(m_vecNodes[ct].isLeaf() == false)
				{
					m_vecNodes[ct].minVoxelValue() = (std::numeric_limits<Type>::max)();
					m_vecNodes[ct].maxVoxelValue() = (std::numeric_limits<Type>::min)();
					for(int childCt = 1; childCt <= 8; ++childCt)
					{
						m_vecNodes[ct].minVoxelValue() = (std::min)(m_vecNodes[ct].minVoxelValue(),m_vecNodes[ct*8+childCt].minVoxelValue());
						m_vecNodes[ct].maxVoxelValue() = (std::max)(m_vecNodes[ct].maxVoxelValue(),m_vecNodes[ct*8+childCt].maxVoxelValue());
					}
				}
				else
				{
					m_vecNodes[ct].minVoxelValue() = (std::numeric_limits<Type>::max)();
					m_vecNodes[ct].maxVoxelValue() = (std::numeric_limits<Type>::min)();
					for(int4 z = floor(m_vecNodes[ct].minPosition().z()); z <= ceil(m_vecNodes[ct].maxPosition().z()); ++z)
					{
						for(int4 y = floor(m_vecNodes[ct].minPosition().y()); y <= ceil(m_vecNodes[ct].maxPosition().y()); ++y)
						{
							for(int4 x = floor(m_vecNodes[ct].minPosition().x()); x <= ceil(m_vecNodes[ct].maxPosition().x()); ++x)
							{						
								if((x >= 0) && (y >= 0) && (z >= 0) && 
									(x < m_Volume.width()) && (y < m_Volume.height()) && (z < m_Volume.depth()))
								{
									//FIXME - use boost::minmax here?
									m_vecNodes[ct].minVoxelValue() = (std::min)(m_vecNodes[ct].minVoxelValue(), m_Volume.voxelAt(Vector3DUint4(x,y,z)));
									m_vecNodes[ct].maxVoxelValue() = (std::max)(m_vecNodes[ct].maxVoxelValue(), m_Volume.voxelAt(Vector3DUint4(x,y,z)));
								}
							}
						}
					}
				}
				m_bChanged = false;
			}
		}
	}

	template<typename Type>
		uint4 Octree<Type>::findChildforPoint(uint4 node, const Vector3DDouble& point) const throw()
	{
		Vector3DDouble vecNodeSize = (m_vecNodes[node].maxPosition() - m_vecNodes[node].minPosition());
		vecNodeSize /= 2;
		Vector3DDouble vecCentre = m_vecNodes[node].minPosition() + vecNodeSize;
		if(point.x() >= vecCentre.x())
		{
			if(point.y() >= vecCentre.y())
			{
				if(point.z() >= vecCentre.z())
				{
					return 8 * node + 8;
				}
				else
				{
					return 8 * node + 7;
				}
			}
			else
			{
				if(point.z() >= vecCentre.z())
				{
					return 8 * node + 6;
				}
				else
				{
					return 8 * node + 5;
				}
			}
		}
		else
		{
			if(point.y() >= vecCentre.y())
			{
				if(point.z() >= vecCentre.z())
				{
					return 8 * node + 4;
				}
				else
				{
					return 8 * node + 3;
				}
			}
			else
			{
				if(point.z() >= vecCentre.z())
				{
					return 8 * node + 2;
				}
				else
				{
					return 8 * node + 1;
				}
			}
		}
	}

	template<typename Type>
		const OctreeNode<Type>& Octree<Type>::nodeAt(uint4 index) const throw()
	{
		return m_vecNodes[index];
	}

	template<typename Type>
	const OctreeNode<Type>& Octree<Type>::rootNode(void) const throw()
	{
		return m_vecNodes[0];
	}	

	template<typename Type>
		uint4 Octree<Type>::noOfNodes(void) const throw()
	{
		return m_vecNodes.size();
	}

	//////////////////////////////////////////////////////////////////////////

	template<typename Type>
		OctreeIterator<Type>::OctreeIterator(const Octree<Type>& octree)
		:m_pOctree(&octree)
		,uCurrentNode(0)
	{
	}

	/*template<typename Type>
		OctreeIterator<Type>::moveToChild(uint4 child)
	{
		assert(child < 8);

		uCurrentNode = 8 * uCurrentNode + child;
	}*/

	template<class Type>
		const OctreeNode<Type>& OctreeIterator<Type>::operator*() const
	{
		return m_pOctree->nodeAt(uCurrentNode);
	}

	template<class Type>
		const OctreeNode<Type>* OctreeIterator<Type>::operator->() const
	{
		return (&(operator*()));
	}
}