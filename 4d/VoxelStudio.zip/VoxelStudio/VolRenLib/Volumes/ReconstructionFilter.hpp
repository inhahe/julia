#ifndef RECONSTRUCTION_FILTER_H
#define RECONSTRUCTION_FILTER_H

#include "..\Base\Typedef.hpp"

#include <vector>

namespace Thermite
{
	class ReconstructionFilter
	{
	public:
		static ReconstructionFilter* createLinearInterpolationFilter(void) throw();
		static ReconstructionFilter* createCatmullRomInterpolationFilter(void) throw();
		static ReconstructionFilter* createFirstDerivativeFilter(void) throw();
		static ReconstructionFilter* createHighQualityFirstDerivativeFilter(void) throw();
		static ReconstructionFilter* createSecondDerivativeFilter(void) throw();

		uint4 size(void) const throw();
		double& tau(void) throw();
		double weightAt(const int4 iWeightIndex) const throw();

	private:
		ReconstructionFilter(uint4 uNoOfWeights, uint4 uNoOfCoefficients);

		std::vector< std::vector< double > > m_vecFilter;
		double m_fTau;
	};
}


#endif