namespace Thermite
{
    template <typename VoxelType, typename VolumeType>
    VolumeType* VolumeGenerator<VoxelType,VolumeType>::generatePerlinNoiseVolume(const uint4 uWidth, const uint4 uHeight, const uint4 uDepth, const uint4 tMin, const uint4 tMax, boost::function<void (std::string, double)> progress)
    {
        VolumeType* result = new VolumeType(uWidth,uHeight,uDepth);

        const uint4 tNoiseRange = tMax - tMin;
        const uint4 uLevels = 5;
        const uint4 tNoiseRangePerLevel = tNoiseRange / uLevels;
        for(uint4 z = 0; z < result->depth(); ++z)
        {
            for(uint4 y = 0; y < result->height(); ++y)
            {
                for(uint4 x = 0; x < result->width(); ++x)
                {
                    //VoxelType xVal = (noise(x) + 1.0f) * 1000;
                    int factor = 1;                    
                    VoxelType noiseLevel = 0;
                    for(uint4 ct = 0; ct < uLevels; ++ct)
                    {
                        double xScaled = double(x) / factor;
                        double yScaled = double(y) / factor;
                        double zScaled = double(z) / factor;
                        //int4 pos = zScaled * result->height() * result->width() + yScaled * result->width() + xScaled;
                        double value = (interpolatedNoise(result,xScaled,yScaled,zScaled));
                        noiseLevel += value * tNoiseRangePerLevel;
                        factor = factor << 1;
                    }
                    result->voxelAt(Vector3DUint4(x,y,z)) = noiseLevel + tMin;
                }
            }
			if(progress)
			{
				progress("Generating Perlin Noise Volume...", static_cast<double>(z+1) / static_cast<double>(result->depth()));
			}
        }
        return result;
    }

	template <typename VoxelType, typename VolumeType>
		VolumeType* VolumeGenerator<VoxelType,VolumeType>::generateResampledVolume(const VolumeType& volOld, uint4 uNewWidth, uint4 uNewHeight, uint4 uNewDepth, boost::function<void (std::string, double)> progress)
	{
		VolumeType* result = new VolumeType(uNewWidth,uNewHeight,uNewDepth);

		//Compute the ratios...
		double fWidthRatio = static_cast<double>(volOld.width()) / static_cast<double>(uNewWidth);
		double fHeightRatio = static_cast<double>(volOld.height()) / static_cast<double>(uNewHeight);
		double fDepthRatio = static_cast<double>(volOld.depth()) / static_cast<double>(uNewDepth);

		//And iterate over the new volume, filling it in.
		for(uint4 z = 0; z < uNewDepth; ++z)
		{
			for(uint4 y = 0; y < uNewHeight; ++y)
			{
				for(uint4 x = 0; x < uNewWidth; ++x)
				{		
					double fXInThisVolume = (static_cast<double>(x) * fWidthRatio);
					double fYInThisVolume = (static_cast<double>(y) * fHeightRatio);
					double fZInThisVolume = (static_cast<double>(z) * fDepthRatio);

					//Watch out for the edges - could look outside the volume if not careful
					if(x == 0)
						fXInThisVolume += 0.001;
					if(x == (volOld.width() - 1))
						fXInThisVolume -= 0.001;
					if(y == 0)
						fYInThisVolume += 0.001;
					if(y == (volOld.height() - 1))
						fYInThisVolume -= 0.001;
					if(z == 0)
						fZInThisVolume += 0.001;
					if(z == (volOld.depth() - 1))
						fZInThisVolume -= 0.001;

					//THERMITE_LOG_DEBUG << "pos in this = " << Vector3DDouble(fXInThisVolume,fYInThisVolume,fZInThisVolume) << std::endl;

					result->voxelAt(Vector3DUint4(x,y,z)) = volOld.computeTrilinearlyInterpolatedValueAt(Vector3DDouble(fXInThisVolume,fYInThisVolume,fZInThisVolume));
				}
			}
			if(progress)
			{
				progress("Generating Resampled Volume...", static_cast<double>(z+1) / static_cast<double>(uNewDepth));
			}
		}
		return result;
	}

	template <typename VoxelType, typename VolumeType>
		VolumeType* VolumeGenerator<VoxelType,VolumeType>::generateSubVolume(const VolumeType& volOld, const Vector3DUint4& minCorner, const Vector3DUint4& maxCorner, boost::function<void (std::string, double)> progress)
	{
		THERMITE_LOG_DEBUG << "Generating Subvolume - Min Corner = " << minCorner << " Max Corner = " << maxCorner;
		Vector3DUint4 vecResultSize = maxCorner - minCorner;		
		VolumeType* result = new VolumeType(vecResultSize.x(),vecResultSize.y(),vecResultSize.z());
		for(uint4 z = 0; z < vecResultSize.z(); ++z)
		{            
			for(uint4 y = 0; y < vecResultSize.y(); ++y)
			{
				for(uint4 x = 0; x < vecResultSize.x(); ++x)
				{                   
					Vector3DUint4 vecPosInNewVolume(x,y,z);
					//THERMITE_LOG_DEBUG << vecPosInNewVolume << "    " << (minCorner + vecPosInNewVolume) << std::endl;
					result->voxelAt(vecPosInNewVolume) = volOld.voxelAt(minCorner + vecPosInNewVolume);
				}
			}
			if(progress)
			{
				progress("Generating Subvolume...", static_cast<double>(z+1) / static_cast<double>(vecResultSize.z()));
			}
		}
		return result;
	}

	template <typename VoxelType, typename VolumeType>
		VolumeType* VolumeGenerator<VoxelType,VolumeType>::generateFilteredVolume(const VolumeType& volOld, boost::function<void (std::string, double)> progress)
	{
		VolumeType* result = new VolumeType(volOld.width(),volOld.height(),volOld.depth());
		for(uint4 z = 1; z < volOld.depth()-1; ++z)
		{
			for(uint4 y = 1; y < volOld.height()-1; ++y)
			{
				for(uint4 x = 1; x < volOld.width()-1; ++x)
				{
					double voxel = 
						volOld.voxelAt(Vector3DUint4(x-1,y-1,z-1)) + 
						volOld.voxelAt(Vector3DUint4(x-1,y-1,z  )) + 
						volOld.voxelAt(Vector3DUint4(x-1,y-1,z+1)) + 
						volOld.voxelAt(Vector3DUint4(x-1,y  ,z-1)) + 
						volOld.voxelAt(Vector3DUint4(x-1,y  ,z  )) + 
						volOld.voxelAt(Vector3DUint4(x-1,y  ,z+1)) + 
						volOld.voxelAt(Vector3DUint4(x-1,y+1,z-1)) + 
						volOld.voxelAt(Vector3DUint4(x-1,y+1,z  )) + 
						volOld.voxelAt(Vector3DUint4(x-1,y+1,z+1)) + 

						volOld.voxelAt(Vector3DUint4(x  ,y-1,z-1)) + 
						volOld.voxelAt(Vector3DUint4(x  ,y-1,z  )) + 
						volOld.voxelAt(Vector3DUint4(x  ,y-1,z+1)) + 
						volOld.voxelAt(Vector3DUint4(x  ,y  ,z-1)) + 
						volOld.voxelAt(Vector3DUint4(x  ,y  ,z  )) + 
						volOld.voxelAt(Vector3DUint4(x  ,y  ,z+1)) + 
						volOld.voxelAt(Vector3DUint4(x  ,y+1,z-1)) + 
						volOld.voxelAt(Vector3DUint4(x  ,y+1,z  )) + 
						volOld.voxelAt(Vector3DUint4(x  ,y+1,z+1)) + 

						volOld.voxelAt(Vector3DUint4(x+1,y-1,z-1)) + 
						volOld.voxelAt(Vector3DUint4(x+1,y-1,z  )) + 
						volOld.voxelAt(Vector3DUint4(x+1,y-1,z+1)) + 
						volOld.voxelAt(Vector3DUint4(x+1,y  ,z-1)) + 
						volOld.voxelAt(Vector3DUint4(x+1,y  ,z  )) + 
						volOld.voxelAt(Vector3DUint4(x+1,y  ,z+1)) + 
						volOld.voxelAt(Vector3DUint4(x+1,y+1,z-1)) + 
						volOld.voxelAt(Vector3DUint4(x+1,y+1,z  )) + 
						volOld.voxelAt(Vector3DUint4(x+1,y+1,z+1));

					voxel /= 27;
					result->voxelAt(Vector3DUint4(x,y,z)) = voxel;
				}
			}
			if(progress)
			{
				progress("Generating Filtered Volume...", static_cast<double>(z+1) / static_cast<double>(volOld.depth()));
			}
		}
		return result;
	}

	template <typename VoxelType, typename VolumeType>
	VolumeType* VolumeGenerator<VoxelType,VolumeType>::generateShapeVolume(const uint4 uWidth, const uint4 uHeight, const uint4 uDepth)
	{
		VolumeType* result = new VolumeType(uWidth,uHeight,uDepth);

		for(uint4 z = 0; z < result->depth(); ++z)
		{
			for(uint4 y = 0; y < result->height(); ++y)
			{
				for(uint4 x = 0; x < result->width(); ++x)
				{
					result->voxelAt(Vector3DUint4(x,y,z)) = 0;

					if((x > 10) && (y > 10) && (z > 10) && (x < 110) && (y < 110) && (z < 110))
					{
						result->voxelAt(Vector3DUint4(x,y,z)) = 1000;
					}

					Vector3DDouble v3dSphereCenter(192.0,192.0,192.0);
					Vector3DDouble v3dOffset = v3dSphereCenter - Vector3DDouble(x,y,z);
					if(v3dOffset.length() < 60)
					{
						result->voxelAt(Vector3DUint4(x,y,z)) = 1000;
					}
				}
			}
		}

		return result;
	}

	template <typename VoxelType, typename VolumeType>
		VolumeType* VolumeGenerator<VoxelType,VolumeType>::generateLevelVolume(const uint4 uWidth, const uint4 uHeight, const uint4 uDepth)
	{
		VolumeType* result = new VolumeType(uWidth,uHeight,uDepth);

		for(uint4 z = 0; z < result->depth(); ++z)
		{
			for(uint4 y = 0; y < result->height(); ++y)
			{
				for(uint4 x = 0; x < result->width(); ++x)
				{
					result->voxelAt(Vector3DUint4(x,y,z)) = 1000;
				}
			}
		}

		//Rooms
		createCube(*result, Vector3DUint4(64,64,64), Vector3DUint4(100,100,100), 0);
		createCube(*result, Vector3DUint4(64,192,192), Vector3DUint4(100,100,100), 0);
		createCube(*result, Vector3DUint4(192,192,64), Vector3DUint4(100,100,100), 0);
		createCube(*result, Vector3DUint4(192,64,192), Vector3DUint4(100,100,100), 0);

		createSphere(*result, Vector3DUint4(64,64,192), 50.0, 0);
		createSphere(*result, Vector3DUint4(64,192,64), 50.0, 0);
		createSphere(*result, Vector3DUint4(192,64,64), 50.0, 0);
		createSphere(*result, Vector3DUint4(192,192,192), 50.0, 0);

		//Corridors along x
		createCube(*result, Vector3DUint4(128,64,64), Vector3DUint4(100,25,25), 0);
		createCube(*result, Vector3DUint4(128,64,192), Vector3DUint4(100,25,25), 0);
		createCube(*result, Vector3DUint4(128,192,64), Vector3DUint4(100,25,25), 0);
		createCube(*result, Vector3DUint4(128,192,192), Vector3DUint4(100,25,25), 0);

		//Corridors along y
		createCube(*result, Vector3DUint4(64,128,64), Vector3DUint4(25,100,25), 0);
		createCube(*result, Vector3DUint4(64,128,192), Vector3DUint4(25,100,25), 0);
		createCube(*result, Vector3DUint4(192,128,64), Vector3DUint4(25,100,25), 0);
		createCube(*result, Vector3DUint4(192,128,192), Vector3DUint4(25,100,25), 0);

		//Corridors along y
		createCube(*result, Vector3DUint4(64,64,128), Vector3DUint4(25,25,100), 0);
		createCube(*result, Vector3DUint4(64,192,128), Vector3DUint4(25,25,100), 0);
		createCube(*result, Vector3DUint4(192,64,128), Vector3DUint4(25,25,100), 0);
		createCube(*result, Vector3DUint4(192,192,128), Vector3DUint4(25,25,100), 0);

		return result;
	}

    template <typename VoxelType, typename VolumeType>
    double VolumeGenerator<VoxelType,VolumeType>::noise(VolumeType* pVolume, uint4 x, uint4 y, uint4 z)
    {
        int4 iSeed  = z * pVolume->height() * pVolume->width() + y * pVolume->width() + x;
        iSeed = (iSeed<<13) ^ iSeed;
        double fSeed = static_cast<double>(iSeed);
        double result =  ( 1.0f - ( (iSeed * (iSeed * iSeed * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824);
        //result = (result + 1.0f) / 2.0f;
        return result;
    }

    template <typename VoxelType, typename VolumeType>
    double VolumeGenerator<VoxelType,VolumeType>::interpolatedNoise(VolumeType* pVolume, double x, double y, double z)
    {
        int floorX = static_cast<int>(x);
        int floorY = static_cast<int>(y);
        int floorZ = static_cast<int>(z);

        double offsetX = x - floorX;
        double offsetY = y - floorY;
        double offsetZ = z - floorZ;

        double result = trilinearlyInterpolate(
            noise(pVolume,floorX,floorY,floorZ),
            noise(pVolume,floorX+1,floorY,floorZ),
            noise(pVolume,floorX,floorY+1,floorZ),
            noise(pVolume,floorX+1,floorY+1,floorZ),
            noise(pVolume,floorX,floorY,floorZ+1),
            noise(pVolume,floorX+1,floorY,floorZ+1),
            noise(pVolume,floorX,floorY+1,floorZ+1),
            noise(pVolume,floorX+1,floorY+1,floorZ+1),
            offsetX,
            offsetY,
            offsetZ
            );

        return result;
    }

	template <typename VoxelType, typename VolumeType>
	void VolumeGenerator<VoxelType,VolumeType>::createCube(VolumeType& volume, Vector3DUint4 v3dCentre, Vector3DUint4 v3dSize, VoxelType value)
	{
		uint4 uHalfX = v3dSize.x() / 2;
		uint4 uHalfY = v3dSize.y() / 2;
		uint4 uHalfZ = v3dSize.z() / 2;
		for(uint4 z = v3dCentre.z() - uHalfZ; z < v3dCentre.z() + uHalfZ; z++)
		{
			for(uint4 y = v3dCentre.y() - uHalfY; y < v3dCentre.y() + uHalfY; y++)
			{
				for(uint4 x = v3dCentre.x() - uHalfX; x < v3dCentre.x() + uHalfX; x++)
				{
					volume.voxelAt(Vector3DUint4(x,y,z)) = value;
				}
			}
		}
	}

	template <typename VoxelType, typename VolumeType>
		void VolumeGenerator<VoxelType,VolumeType>::createSphere(VolumeType& volume, Vector3DUint4 v3dCentre, double dRadius, VoxelType value)
	{
		for(uint4 z = 0; z < volume.depth(); z++)
		{
			for(uint4 y = 0; y < volume.height(); y++)
			{
				for(uint4 x = 0; x < volume.width(); x++)
				{
					double dXDist = static_cast<double>(x) - static_cast<double>(v3dCentre.x());
					double dYDist = static_cast<double>(y) - static_cast<double>(v3dCentre.y());
					double dZDist = static_cast<double>(z) - static_cast<double>(v3dCentre.z());

					double dDist = sqrt(dXDist*dXDist+dYDist*dYDist+dZDist*dZDist);
					if(dDist <= dRadius)
					{
						volume.voxelAt(Vector3DUint4(x,y,z)) = value;
					}
				}
			}
		}
	}
}