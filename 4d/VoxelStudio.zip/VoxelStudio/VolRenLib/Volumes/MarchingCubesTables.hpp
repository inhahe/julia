#ifndef MARCHING_CUBES_TABLES_HEADER_INCLUDED
#define MARCHING_CUBES_TABLES_HEADER_INCLUDED

namespace Thermite
{
	extern int edgeTable[256];
	extern int triTable[256][16];
}

#endif