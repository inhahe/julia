#ifndef VOLUMEGENERATOR_HEADER_INCLUDED
#define VOLUMEGENERATOR_HEADER_INCLUDED

#include <boost/function.hpp>

namespace Thermite
{
    template <typename VoxelType, typename VolumeType>
    class VolumeGenerator
    {
    public:
        static VolumeType* generatePerlinNoiseVolume(const uint4 uWidth, const uint4 uHeight, const uint4 uDepth, const uint4 tMin, const uint4 tMax, boost::function<void (std::string, double)> progress = 0);

		static VolumeType* generateResampledVolume(const VolumeType& volOld, uint4 uNewWidth, uint4 uNewHeight, uint4 uNewDepth, boost::function<void (std::string, double)> progress = 0);
		static VolumeType* generateSubVolume(const VolumeType& volOld, const Vector3DUint4& minCorner, const Vector3DUint4& maxCorner, boost::function<void (std::string, double)> progress = 0);
		static VolumeType* generateFilteredVolume(const VolumeType& volOld, boost::function<void (std::string, double)> progress = 0);

		static VolumeType* generateShapeVolume(const uint4 uWidth, const uint4 uHeight, const uint4 uDepth);
		static VolumeType* generateLevelVolume(const uint4 uWidth, const uint4 uHeight, const uint4 uDepth);
    private:
        static double noise(VolumeType* pVolume, uint4 x, uint4 y, uint4 z);
        static double interpolatedNoise(VolumeType* pVolume, double x, double y, double z);

		static void createCube(VolumeType& volume, Vector3DUint4 v3dCentre, Vector3DUint4 v3dSize, VoxelType value);
		static void createSphere(VolumeType& volume, Vector3DUint4 v3dCentre, double dRadius, VoxelType value);
    };
}

#include "VolumeGenerator.inl"

#endif