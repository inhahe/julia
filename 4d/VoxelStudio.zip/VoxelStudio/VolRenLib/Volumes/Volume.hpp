#ifndef VOLUME_HEADER_INCLUDED
#define VOLUME_HEADER_INCLUDED

#include <cassert> //For assertions
#include <new> //For memory management
#include <vector> //For histogram

#include <boost/function.hpp>

#include "..\Base\Exceptions.hpp"
#include "..\Base\Typedef.hpp"
#include "..\Maths\Vector.hpp"

namespace Thermite
{
	template<typename Type> class Octree;
	class ReconstructionFilter;

	enum CompressionMethod
	{
		NONE,
		BZIP2,
		GZIP,
		ZLIB
	};

    template <typename Type>
    class Volume
    {
    public:
        //Constructors, etc. FIXME - does it make sense to have constructors in the abstract base class?!
        Volume() throw();
        Volume(uint4 widthToSet, uint4 heightToSet, uint4 depthToSet) throw();
		///Copy Constructor.
		template <typename CastType> explicit Volume(const Volume<CastType>& volumeToSet) throw();
        Volume(const Volume& rhs) throw();
        virtual ~Volume() throw();

        //General getters/setters
        uint4 width(void) const throw();
        uint4 height(void) const throw();
        uint4 depth(void) const throw();
		double diagonal(void) const throw();
		virtual void setDimensions(const uint4 widthToSet,const uint4 heightToSet,const uint4 depthToSet) throw(std::bad_alloc);
        Type minimum(void) const throw();
        Type maximum(void) const throw();

        //Value accessors
        const virtual Type& voxelAt(const Vector3DUint4& position) const throw() = 0;
        virtual Type& voxelAt(const Vector3DUint4& position) throw() = 0;
        const virtual Type& voxelAtSafe(const Vector3DUint4& position) const throw() = 0;
        virtual Type& voxelAtSafe(const Vector3DUint4& position) throw() = 0;

        //Interpolated value accessors
        virtual double computeNearestNeighbourInterpolatedValueAt(const Vector3DDouble& position) const throw();
        virtual double computeTrilinearlyInterpolatedValueAt(const Vector3DDouble& position) const throw();
        virtual double computeNearestNeighbourInterpolatedValueAtSafe(const Vector3DDouble& position) const throw();
        virtual double computeTrilinearlyInterpolatedValueAtSafe(const Vector3DDouble& position) const throw();

        //Gradient accesors
        virtual Vector3DInt4 computeCentralDifferenceGradientAt(const Vector3DUint4& position) const throw();
        virtual Vector3DInt4 computeSobelGradientAt(const Vector3DUint4& position) const throw();
        virtual Vector3DInt4 computeCentralDifferenceGradientAtSafe(const Vector3DUint4& position) const throw();
        virtual Vector3DInt4 computeSobelGradientAtSafe(const Vector3DUint4& position) const throw();

        //Interpolated gradient accessors
        virtual Vector3DDouble computeNearestNeighbourInterpolatedCentralDifferenceGradientAt(const Vector3DDouble& position) const throw();
        virtual Vector3DDouble computeTrilinearlyInterpolatedCentralDifferenceGradientAt(const Vector3DDouble& position) const throw();
        virtual Vector3DDouble computeNearestNeighbourInterpolatedSobelGradientAt(const Vector3DDouble& position) const throw();
        virtual Vector3DDouble computeTrilinearlyInterpolatedSobelGradientAt(const Vector3DDouble& position) const throw();
        virtual Vector3DDouble computeNearestNeighbourInterpolatedCentralDifferenceGradientAtSafe(const Vector3DDouble& position) const throw();
        virtual Vector3DDouble computeTrilinearlyInterpolatedCentralDifferenceGradientAtSafe(const Vector3DDouble& position) const throw();
        virtual Vector3DDouble computeNearestNeighbourInterpolatedSobelGradientAtSafe(const Vector3DDouble& position) const throw();
        virtual Vector3DDouble computeTrilinearlyInterpolatedSobelGradientAtSafe(const Vector3DDouble& position) const throw();

		//Filters
		double applyFilter(const Vector3DDouble& position, ReconstructionFilter* xFilter, ReconstructionFilter* yFilter, ReconstructionFilter* zFilter) throw();
		//void computeCurvatureAt(const Vector3DDouble& position, double&k1, double& k2) throw();
		double computeCurvatureAt(const Vector3DUint4& v3dPosition);
		double computeTrilinearlyInterpolatedCurvatureAt(const Vector3DDouble& v3dPosition);

        //Other stuff
		virtual bool cellCornersBelowThreshold(const Vector3DDouble& position, const Type& tThreshold) const throw();
        std::vector<uint4> histogram(void) const throw();
		bool contains(const Vector3DDouble& point, uint4 uBorderinCells = 0) const throw();	

		Octree<Type>& octree() throw();       


        //File access
		virtual void load(std::string strDir, boost::function<void (std::string, double)> progress = 0) throw(file_error);
		virtual bool save(std::string strDir, CompressionMethod compressionMethod) throw(file_error);
		virtual void importDAT(const std::string& filename, boost::function<void (std::string, double)> progress = 0) throw(file_error);
        virtual bool exportDAT(const std::string& filename) const throw(file_error);

    protected:
        //Internal data
        uint4 m_uWidth;
        uint4 m_uHeight;
        uint4 m_uDepth;  

        //Value returned by 'safe' functions in case of error
        //Needs to be in the class because we return a reference...
        Type m_tSafe;

		//Scratchpads for use when applying filters.
		std::vector< std::vector< double> > interpolatedX;
		std::vector< double > interpolatedXandY;
		double interpolatedXandYandZ;

		//The volumes Octree if present
		Octree<Type>* m_pOctree;

		//Called when any of the volumes data is changed
		void dataChanged(boost::function<void (std::string, double)> progress = 0);
    };
    
}//namespace Thermite

#include "Volume.inl"

#endif	//VOLUME_HEADER_INCLUDED

