#ifndef OCTREE_HEADER_INCLUDED
#define OCTREE_HEADER_INCLUDED

#include <vector>

#include <boost/function.hpp>

namespace Thermite
{
	template <typename Type> class OctreeNode;
	template <typename Type> class Volume;

    template <typename Type>
    class Octree
    {
	public:
		Octree(const Volume<Type>& pVolume);
		~Octree();

		uint4 buildOctree(boost::function<void (std::string, double)> progress = 0) throw();
		uint4 findChildforPoint(uint4 node, const Vector3DDouble& point) const throw();
		const OctreeNode<Type>& nodeAt(uint4 index) const throw();
		const OctreeNode<Type>& rootNode(void) const throw();	
		uint4 noOfNodes(void) const throw();

		void repairOctree(void);
		
	private:
		std::vector< OctreeNode<Type> > m_vecNodes;
		const Volume<Type>& m_Volume;
	};

	template <typename Type>
	class OctreeIterator
	{
	public:
		OctreeIterator(const Octree<Type>& octree);

		const OctreeNode<Type>& operator*() const;
		const OctreeNode<Type>* operator->() const;

		//moveToChild(uint4 child);

	private:
		const Octree<Type>* m_pOctree;
		uint4 uCurrentNode;
	};
}

#include "Octree.inl"

#endif