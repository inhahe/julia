namespace Thermite
{
		template class LinearVolume<uint2>;
    /*-------------------------------------------------------------------------
    *Constructors, etc.
    *------------------------------------------------------------------------*/

    template <typename Type>
        LinearVolume<Type>::LinearVolume() throw()
        :m_pData(0)

    {
    }

    template <typename Type>
    LinearVolume<Type>::LinearVolume(uint4 widthToSet, uint4 heightToSet, uint4 depthToSet) throw()
        :Volume<Type>(widthToSet, heightToSet, depthToSet)
        ,m_pData(0)
    {
        m_pData = new Type[m_uWidth * m_uHeight * m_uDepth];
				memset(m_pData,0,m_uWidth * m_uHeight * m_uDepth);
        assert(m_pData != 0);
    }

	template <typename Type>
		template <typename CastType>
		LinearVolume<Type>::LinearVolume(const LinearVolume<CastType>& volumeToSet) throw()
	{
		THERMITE_LOG_DEBUG << "Warning - Casting linear volume type" << std::endl;
		setDimensions(volumeToSet.width(),volumeToSet.height(),volumeToSet.depth());
		for(uint4 z = 0; z < depth(); ++z)
		{
			for(uint4 y = 0; y < height(); ++y)
			{
				for(uint4 x = 0; x < width(); ++x)
				{
					voxelAt(Vector3DUint4(x,y,z)) = static_cast<Type>(volumeToSet.voxelAt(Vector3DUint4(x,y,z)));
				}
			}
		}
	}

    template <typename Type>
    LinearVolume<Type>::LinearVolume(const LinearVolume<Type>& rhs) throw()
    {
        *this = rhs;
    }

    template <typename Type>
    LinearVolume<Type>::~LinearVolume() throw()
    {
        if(m_pData != 0)
            delete[] m_pData;
        m_pData = 0;
    }

    /*-------------------------------------------------------------------------
    *Operations
    *------------------------------------------------------------------------*/

    /**
    *Performs a deep copy.
    */
    template <typename Type>
    LinearVolume<Type>& LinearVolume<Type>::operator=(const LinearVolume<Type>& rhs) throw()
    {
        assert(this != &rhs);
        m_uWidth = rhs.m_uWidth;
        m_uHeight = rhs.m_uHeight;
        m_uDepth = rhs.m_uDepth;
        m_pData = new Type[m_uWidth * m_uHeight * m_uDepth];
        std::memcpy(m_pData, rhs.m_pData, sizeof(Type) * m_uWidth * m_uHeight * m_uDepth);
        return *this;
    }

    /*-------------------------------------------------------------------------
    *General getters/setters
    *------------------------------------------------------------------------*/


    //FIXME - find out why 'this->' is needed for accessing some members and not others?!
    template <typename Type>
    void LinearVolume<Type>::setDimensions(const uint4 widthToSet,const uint4 heightToSet,const uint4 depthToSet) throw(std::bad_alloc)
    {
        Volume<Type>::setDimensions(widthToSet, heightToSet, depthToSet);
        if(m_pData != 0)
            delete[] m_pData;
        m_pData = 0;
        m_pData = new Type[this->m_uWidth * this->m_uHeight * this->m_uDepth];
    }

    /*-------------------------------------------------------------------------
    *Value accessors
    *------------------------------------------------------------------------*/

    template <typename Type>
    inline const Type& LinearVolume<Type>::voxelAt(const Vector3DUint4& position) const throw()
    {
        return m_pData[position.z() * this->m_uHeight * this->m_uWidth + position.y() * this->m_uWidth + position.x()];
    }

    template <typename Type>
    inline Type& LinearVolume<Type>::voxelAt(const Vector3DUint4& position) throw()
    {
        return m_pData[position.z() * this->m_uHeight * this->m_uWidth + position.y() * this->m_uWidth + position.x()];
    }

    template <typename Type>
        inline const Type& LinearVolume<Type>::voxelAtSafe(const Vector3DUint4& position) const throw()
    {
        if((position.x() < m_uWidth) && (position.y() < m_uHeight) && (position.z() < m_uDepth))
        {
            return voxelAt(position);
        }
        else
        {
            return m_tSafe;
        }
    }

    template <typename Type>
        inline Type& LinearVolume<Type>::voxelAtSafe(const Vector3DUint4& position) throw()
    {
        if((position.x() < m_uWidth) && (position.y() < m_uHeight) && (position.z() < m_uDepth))
        {
            return voxelAt(position);
        }
        else
        {
            return m_tSafe;
        }
    }

    /*-------------------------------------------------------------------------
    *Interpolated value accessors
    *------------------------------------------------------------------------*/  

    template <typename Type>
        inline double LinearVolume<Type>::computeTrilinearlyInterpolatedValueAt(const Vector3DDouble& position) const throw()
    {
        assert((position.x() <= static_cast<double>(width() - 1)) && (position.x() >= 0.0f)
            && (position.y() <= static_cast<double>(height() - 1)) && (position.y() >= 0.0f)
            && (position.z() <= static_cast<double>(depth() - 1)) && (position.z() >= 0.0f));

        const uint4 floorX = static_cast<uint4>(position.x());
        const uint4 floorY = static_cast<uint4>(position.y());
        const uint4 floorZ = static_cast<uint4>(position.z());     

        const Type* v000 = m_pData + (floorZ * this->m_uHeight * this->m_uWidth + floorY * this->m_uWidth + floorX);
        const Type* v100 = v000 + 1;
        const Type* v010 = v000 + this->m_uWidth;
        const Type* v110 = v010 + 1;
        const Type* v001 = v000 + this->m_uWidth * this->m_uHeight;
        const Type* v101 = v001 + 1;
        const Type* v011 = v001 + this->m_uWidth;
        const Type* v111 = v011 + 1;

        return trilinearlyInterpolate<double>(*v000,*v100,*v010,*v110,*v001,*v101,*v011,*v111,position.x() - floorX,position.y() - floorY,position.z() - floorZ);
    }

    /*-------------------------------------------------------------------------
    *Gradient accessors
    *------------------------------------------------------------------------*/

    template <typename Type>
        inline Vector3DInt4 LinearVolume<Type>::computeCentralDifferenceGradientAt(const Vector3DUint4& position) const throw()
    {
        assert((position.x() <= (width()-2)) && (position.x() >= 1)
            && (position.y() <= (height()-2)) && (position.y() >= 1)
            && (position.z() <= (depth()-2)) && (position.z() >= 1));
        //THERMITE_LOG_DEBUG << "in compute gradient for " << position.x() << " " << position.y() << " " position.z() << std::endl;

        const Type* pBase = m_pData + (position.z() * this->m_uHeight * this->m_uWidth + position.y() * this->m_uWidth + position.x());

        const int4 xGrad = (*(pBase + 1)) - (*(pBase - 1));
        const int4 yGrad = (*(pBase + this->m_uWidth)) - (*(pBase - this->m_uWidth));
        const int4 zGrad = (*(pBase + this->m_uWidth * this->m_uHeight)) - (*(pBase - this->m_uWidth * this->m_uHeight));

       // THERMITE_LOG_DEBUG << "done compute gradient" << std::endl;

        return Vector3DInt4(xGrad,yGrad,zGrad);
    }

    /*-------------------------------------------------------------------------
    *Interpolated gradient accessors
    *------------------------------------------------------------------------*/

    template <typename Type>
        inline Vector3DDouble LinearVolume<Type>::computeTrilinearlyInterpolatedCentralDifferenceGradientAt(const Vector3DDouble& position) const throw()
    {
        assert((position.x() <= static_cast<double>(width() - 1)) && (position.x() >= 0.0f)
            && (position.y() <= static_cast<double>(height() - 1)) && (position.y() >= 0.0f)
            && (position.z() <= static_cast<double>(depth() - 1)) && (position.z() >= 0.0f));

        const uint4 floorX = static_cast<uint4>(position.x());
        const uint4 floorY = static_cast<uint4>(position.y());
        const uint4 floorZ = static_cast<uint4>(position.z());

        const uint4 ceilX = floorX + 1;
        const uint4 ceilY = floorY + 1;
        const uint4 ceilZ = floorZ + 1;

        const Vector3DInt4 v000 = computeCentralDifferenceGradientAt(Vector3DUint4(floorX, floorY, floorZ));
        const Vector3DInt4 v100 = computeCentralDifferenceGradientAt(Vector3DUint4(ceilX,  floorY, floorZ));
        const Vector3DInt4 v010 = computeCentralDifferenceGradientAt(Vector3DUint4(floorX, ceilY,  floorZ));
        const Vector3DInt4 v110 = computeCentralDifferenceGradientAt(Vector3DUint4(ceilX,  ceilY,  floorZ));
        const Vector3DInt4 v001 = computeCentralDifferenceGradientAt(Vector3DUint4(floorX, floorY, ceilZ));
        const Vector3DInt4 v101 = computeCentralDifferenceGradientAt(Vector3DUint4(ceilX,  floorY, ceilZ));
        const Vector3DInt4 v011 = computeCentralDifferenceGradientAt(Vector3DUint4(floorX, ceilY,  ceilZ));
        const Vector3DInt4 v111 = computeCentralDifferenceGradientAt(Vector3DUint4(ceilX,  ceilY,  ceilZ));

        return trilinearlyInterpolate< Vector3DDouble >(
            static_cast< Vector3DDouble >(v000),
            static_cast< Vector3DDouble >(v100),
            static_cast< Vector3DDouble >(v010),
            static_cast< Vector3DDouble >(v110),
            static_cast< Vector3DDouble >(v001),
            static_cast< Vector3DDouble >(v101),
            static_cast< Vector3DDouble >(v011),
            static_cast< Vector3DDouble >(v111),
            position.x() - floorX,position.y() - floorY,position.z() - floorZ);
    }

	template <typename Type>
	bool LinearVolume<Type>::cellCornersBelowThreshold(const Vector3DDouble& position, const Type& tThreshold) const throw()
	{
		const uint4 floorX = static_cast<uint4>(position.x());
		const uint4 floorY = static_cast<uint4>(position.y());
		const uint4 floorZ = static_cast<uint4>(position.z());     

		const Type* v000 = m_pData + (floorZ * this->m_uHeight * this->m_uWidth + floorY * this->m_uWidth + floorX);
		const Type* v100 = v000 + 1;
		const Type* v010 = v000 + this->m_uWidth;
		const Type* v110 = v010 + 1;
		const Type* v001 = v000 + this->m_uWidth * this->m_uHeight;
		const Type* v101 = v001 + 1;
		const Type* v011 = v001 + this->m_uWidth;
		const Type* v111 = v011 + 1;

		return ((*v000 < tThreshold) &&
		(*v100 < tThreshold) &&
		(*v010 < tThreshold) &&
		(*v110 < tThreshold) &&
		(*v000 < tThreshold) &&
		(*v100 < tThreshold) &&
		(*v010 < tThreshold) &&
		(*v110 < tThreshold));

	}
}
