#include <algorithm>
#include <limits>

#include <boost/iostreams/device/file.hpp>
#include <boost/iostreams/stream.hpp>
#include <boost/iostreams/device/file_descriptor.hpp>
#include <boost/iostreams/filtering_stream.hpp>
#include <boost/iostreams/filter/bzip2.hpp>
#include <boost/iostreams/filter/gzip.hpp>
#include <boost/iostreams/filter/zlib.hpp>

#include "..\Base\PropertyValueMap.hpp"
#include "..\Base\Utility.hpp"
#include "..\Base\Logging.hpp"
#include "..\Maths\Matrix.hpp"
#include "Octree.hpp"
#include "ReconstructionFilter.hpp"

namespace Thermite
{
    /*-------------------------------------------------------------------------
    *Constructors, etc.
    *------------------------------------------------------------------------*/

    template <typename Type>
        Volume<Type>::Volume() throw()
        :m_uWidth(0)
        ,m_uHeight(0)
        ,m_uDepth(0)
		,m_pOctree(0)
        ,m_tSafe(static_cast<Type>(0))
    {
    }

    template <typename Type>
        Volume<Type>::Volume(uint4 widthToSet, uint4 heightToSet, uint4 depthToSet) throw()
        :m_uWidth(widthToSet)
        ,m_uHeight(heightToSet)
        ,m_uDepth(depthToSet)
		,m_pOctree(0)
        ,m_tSafe(static_cast<Type>(0))
    { 
    }

    template <typename Type>
        template <typename CastType>
        Volume<Type>::Volume(const Volume<CastType>& volumeToSet) throw()
		:m_pOctree(0)
        ,m_tSafe(static_cast<Type>(0))
    {
		setDimensions(volumeToSet.width(),volumeToSet.height(),volumeToSet.depth());
        for(uint4 z = 0; z < depth(); ++z)
        {
            for(uint4 y = 0; y < height(); ++y)
            {
                for(uint4 x = 0; x < width(); ++x)
                {
                    voxelAt(x,y,z) = static_cast<Type>(volumeToSet.voxelAt(x,y,z));
                }
            }
        }
    }

    template <typename Type>
        Volume<Type>::Volume(const Volume<Type>& rhs) throw()
    {
        *this = rhs;
    }

    template <typename Type>
        Volume<Type>::~Volume() throw()
    {
    }

    /*-------------------------------------------------------------------------
    *General getters/setters
    *------------------------------------------------------------------------*/

    template <typename Type>
        inline uint4 Volume<Type>::width(void) const throw()
    {
        return m_uWidth;
    }

    template <typename Type>
        inline uint4 Volume<Type>::height(void) const throw()
    {
        return m_uHeight;
    }

    template <typename Type>
        inline uint4 Volume<Type>::depth(void) const throw()
    {
        return m_uDepth;
    }

    template <typename Type>
        inline double Volume<Type>::diagonal(void) const throw()
    {
        return sqrt(static_cast<double>(m_uWidth*m_uWidth+m_uHeight*m_uHeight+m_uDepth*m_uDepth));
    }

    template <typename Type>
        void Volume<Type>::setDimensions(const uint4 widthToSet,const uint4 heightToSet,const uint4 depthToSet) throw(std::bad_alloc)
    {
        m_uWidth = widthToSet;
        m_uHeight = heightToSet;
        m_uDepth = depthToSet;
    }

    template <typename Type>
    Type Volume<Type>::minimum(void) const throw()
    {
        Type tMin = (std::numeric_limits<Type>::max)();
        for(uint4 z = 0; z < depth(); ++z)
        {
            for(uint4 y = 0; y < height(); ++y)
            {
                for(uint4 x = 0; x < width(); ++x)
                {
                    Type value = voxelAt(Vector3DUint4(x,y,z));
                    if(value < tMin)
                    {
                        tMin = value;
                    }
                }
            }
        }
        return tMin;
    }

    template <typename Type>
    Type Volume<Type>::maximum(void) const throw()
    {
        Type tMax = (std::numeric_limits<Type>::min)();
        for(uint4 z = 0; z < depth(); ++z)
        {
            for(uint4 y = 0; y < height(); ++y)
            {
                for(uint4 x = 0; x < width(); ++x)
                {
                    Type value = voxelAt(Vector3DUint4(x,y,z));
                    if(value > tMax)
                    {
                        tMax = value;
                    }
                }
            }
        }
        return tMax;
    }

    /*-------------------------------------------------------------------------
    *Interpolated value accessors
    *------------------------------------------------------------------------*/    

    template <typename Type>
        double Volume<Type>::computeNearestNeighbourInterpolatedValueAt(const Vector3DDouble& position) const throw()
    {
        assert((position.x() <= static_cast<double>(width() - 1)) && (position.x() >= 0.0f)
            && (position.y() <= static_cast<double>(height() - 1)) && (position.y() >= 0.0f)
            && (position.z() <= static_cast<double>(depth() - 1)) && (position.z() >= 0.0f));

        const uint4 roundedX = static_cast<uint4>(position.x() + 0.5f);
        const uint4 roundedY = static_cast<uint4>(position.y() + 0.5f);
        const uint4 roundedZ = static_cast<uint4>(position.z() + 0.5f);

        return voxelAt(Vector3DUint4(roundedX,  roundedY, roundedZ));
    }

    template <typename Type>
        double Volume<Type>::computeTrilinearlyInterpolatedValueAt(const Vector3DDouble& position) const throw()
    {
        assert((position.x() <= static_cast<double>(width() - 1)) && (position.x() >= 0.0f)
            && (position.y() <= static_cast<double>(height() - 1)) && (position.y() >= 0.0f)
            && (position.z() <= static_cast<double>(depth() - 1)) && (position.z() >= 0.0f));

        const uint4 floorX = static_cast<uint4>(position.x());
        const uint4 floorY = static_cast<uint4>(position.y());
        const uint4 floorZ = static_cast<uint4>(position.z());

        const uint4 ceilX = floorX + 1;
        const uint4 ceilY = floorY + 1;
        const uint4 ceilZ = floorZ + 1;

        const Type v000 = voxelAt(Vector3DUint4(floorX, floorY, floorZ));
        const Type v100 = voxelAt(Vector3DUint4(ceilX,  floorY, floorZ));
        const Type v010 = voxelAt(Vector3DUint4(floorX, ceilY,  floorZ));
        const Type v110 = voxelAt(Vector3DUint4(ceilX,  ceilY,  floorZ));
        const Type v001 = voxelAt(Vector3DUint4(floorX, floorY, ceilZ));
        const Type v101 = voxelAt(Vector3DUint4(ceilX,  floorY, ceilZ));
        const Type v011 = voxelAt(Vector3DUint4(floorX, ceilY,  ceilZ));
        const Type v111 = voxelAt(Vector3DUint4(ceilX,  ceilY,  ceilZ));

        return trilinearlyInterpolate<double>(v000,v100,v010,v110,v001,v101,v011,v111,position.x() - floorX,position.y() - floorY,position.z() - floorZ);
    }

    template <typename Type>
        double Volume<Type>::computeNearestNeighbourInterpolatedValueAtSafe(const Vector3DDouble& position) const throw()
    {
        if((position.x() <= static_cast<double>(width() - 1)) && (position.x() >= 0.0f)
            && (position.y() <= static_cast<double>(height() - 1)) && (position.y() >= 0.0f)
            && (position.z() <= static_cast<double>(depth() - 1)) && (position.z() >= 0.0f))
        {
            return computeNearestNeighbourInterpolatedValueAt(position);
        }
        else
        {
            return 0.0f;
        }
    }

    template <typename Type>
        double Volume<Type>::computeTrilinearlyInterpolatedValueAtSafe(const Vector3DDouble& position) const throw()
    {
        if((position.x() <= static_cast<double>(width() - 1)) && (position.x() >= 0.0f)
            && (position.y() <= static_cast<double>(height() - 1)) && (position.y() >= 0.0f)
            && (position.z() <= static_cast<double>(depth() - 1)) && (position.z() >= 0.0f))
        {
            return computeNearestNeighbourInterpolatedValueAt(position);
        }
        else
        {
            return 0.0f;
        }
    }

    /*-------------------------------------------------------------------------
    *Gradient accessors
    *------------------------------------------------------------------------*/

    template <typename Type>
        Vector3DInt4 Volume<Type>::computeCentralDifferenceGradientAt(const Vector3DUint4& position) const throw()
    {
        assert((position.x() <= (width()-2)) && (position.x() >= 1)
            && (position.y() <= (height()-2)) && (position.y() >= 1)
            && (position.z() <= (depth()-2)) && (position.z() >= 1));

        const uint4 x = position.x();
        const uint4 y = position.y();
        const uint4 z = position.z();

        const int4 xGrad = voxelAt(Vector3DUint4(x+1,y,z)) - voxelAt(Vector3DUint4(x-1,y,z));
        const int4 yGrad = voxelAt(Vector3DUint4(x,y+1,z)) - voxelAt(Vector3DUint4(x,y-1,z));
        const int4 zGrad = voxelAt(Vector3DUint4(x,y,z+1)) - voxelAt(Vector3DUint4(x,y,z-1));

        return Vector3DInt4(xGrad,yGrad,zGrad);
    }

    template <typename Type>
        Vector3DInt4 Volume<Type>::computeSobelGradientAt(const Vector3DUint4& position) const throw()
    {
        assert((position.x() <= (width()-2)) && (position.x() >= 1)
            && (position.y() <= (height()-2)) && (position.y() >= 1)
            && (position.z() <= (depth()-2)) && (position.z() >= 1));

        const uint4 x = position.x();
        const uint4 y = position.y();
        const uint4 z = position.z();

        static const int4 weights[3][3][3] = {  {  {2,3,2}, {3,6,3}, {2,3,2}  },  {
            {3,6,3},  {6,0,6},  {3,6,3} },  { {2,3,2},  {3,6,3},  {2,3,2} } };

            Vector3DUint4 pVoxel1nx1ny1nz(x-1,y-1,z-1);
            Vector3DUint4 pVoxel1nx1ny0pz(x-1,y-1,z  );
            Vector3DUint4 pVoxel1nx1ny1pz(x-1,y-1,z+1);
            Vector3DUint4 pVoxel1nx0py1nz(x-1,y,  z-1);
            Vector3DUint4 pVoxel1nx0py0pz(x-1,y,  z  );
            Vector3DUint4 pVoxel1nx0py1pz(x-1,y,  z+1);
            Vector3DUint4 pVoxel1nx1py1nz(x-1,y+1,z-1);
            Vector3DUint4 pVoxel1nx1py0pz(x-1,y+1,z  );
            Vector3DUint4 pVoxel1nx1py1pz(x-1,y+1,z+1);

            Vector3DUint4 pVoxel0px1ny1nz(x,y-1,z-1);
            Vector3DUint4 pVoxel0px1ny0pz(x,y-1,z  );
            Vector3DUint4 pVoxel0px1ny1pz(x,y-1,z+1);
            Vector3DUint4 pVoxel0px0py1nz(x,y,  z-1);

            Vector3DUint4 pVoxel0px0py1pz(x,y,  z+1);
            Vector3DUint4 pVoxel0px1py1nz(x,y+1,z-1);
            Vector3DUint4 pVoxel0px1py0pz(x,y+1,z  );
            Vector3DUint4 pVoxel0px1py1pz(x,y+1,z+1);

            Vector3DUint4 pVoxel1px1ny1nz(x+1,y-1,z-1);
            Vector3DUint4 pVoxel1px1ny0pz(x+1,y-1,z  );
            Vector3DUint4 pVoxel1px1ny1pz(x+1,y-1,z+1);
            Vector3DUint4 pVoxel1px0py1nz(x+1,y,  z-1);
            Vector3DUint4 pVoxel1px0py0pz(x+1,y,  z  );
            Vector3DUint4 pVoxel1px0py1pz(x+1,y,  z+1);
            Vector3DUint4 pVoxel1px1py1nz(x+1,y+1,z-1);
            Vector3DUint4 pVoxel1px1py0pz(x+1,y+1,z  );
            Vector3DUint4 pVoxel1px1py1pz(x+1,y+1,z+1);



            const int4 xGrad(- weights[0][0][0] * voxelAt( pVoxel1nx1ny1nz) -
                weights[1][0][0] * voxelAt( pVoxel1nx1ny0pz) - weights[2][0][0] *
                voxelAt( pVoxel1nx1ny1pz) - weights[0][1][0] * voxelAt( pVoxel1nx0py1nz) -
                weights[1][1][0] * voxelAt( pVoxel1nx0py0pz) - weights[2][1][0] *
                voxelAt( pVoxel1nx0py1pz) - weights[0][2][0] * voxelAt( pVoxel1nx1py1nz) -
                weights[1][2][0] * voxelAt( pVoxel1nx1py0pz) - weights[2][2][0] *
                voxelAt( pVoxel1nx1py1pz) + weights[0][0][2] * voxelAt( pVoxel1px1ny1nz) +
                weights[1][0][2] * voxelAt( pVoxel1px1ny0pz) + weights[2][0][2] *
                voxelAt( pVoxel1px1ny1pz) + weights[0][1][2] * voxelAt( pVoxel1px0py1nz) +
                weights[1][1][2] * voxelAt( pVoxel1px0py0pz) + weights[2][1][2] *
                voxelAt( pVoxel1px0py1pz) + weights[0][2][2] * voxelAt( pVoxel1px1py1nz) +
                weights[1][2][2] * voxelAt( pVoxel1px1py0pz) + weights[2][2][2] *
                voxelAt( pVoxel1px1py1pz));

            const int4 yGrad(- weights[0][0][0] * voxelAt( pVoxel1nx1ny1nz) -
                weights[1][0][0] * voxelAt( pVoxel1nx1ny0pz) - weights[2][0][0] *
                voxelAt( pVoxel1nx1ny1pz) + weights[0][2][0] * voxelAt( pVoxel1nx1py1nz) +
                weights[1][2][0] * voxelAt( pVoxel1nx1py0pz) + weights[2][2][0] *
                voxelAt( pVoxel1nx1py1pz) - weights[0][0][1] * voxelAt( pVoxel0px1ny1nz) -
                weights[1][0][1] * voxelAt( pVoxel0px1ny0pz) - weights[2][0][1] *
                voxelAt( pVoxel0px1ny1pz) + weights[0][2][1] * voxelAt( pVoxel0px1py1nz) +
                weights[1][2][1] * voxelAt( pVoxel0px1py0pz) + weights[2][2][1] *
                voxelAt( pVoxel0px1py1pz) - weights[0][0][2] * voxelAt( pVoxel1px1ny1nz) -
                weights[1][0][2] * voxelAt( pVoxel1px1ny0pz) - weights[2][0][2] *
                voxelAt( pVoxel1px1ny1pz) + weights[0][2][2] * voxelAt( pVoxel1px1py1nz) +
                weights[1][2][2] * voxelAt( pVoxel1px1py0pz) + weights[2][2][2] *
                voxelAt( pVoxel1px1py1pz));

            const int4 zGrad(- weights[0][0][0] * voxelAt( pVoxel1nx1ny1nz) +
                weights[2][0][0] * voxelAt( pVoxel1nx1ny1pz) - weights[0][1][0] *
                voxelAt( pVoxel1nx0py1nz) + weights[2][1][0] * voxelAt( pVoxel1nx0py1pz) -
                weights[0][2][0] * voxelAt( pVoxel1nx1py1nz) + weights[2][2][0] *
                voxelAt( pVoxel1nx1py1pz) - weights[0][0][1] * voxelAt( pVoxel0px1ny1nz) +
                weights[2][0][1] * voxelAt( pVoxel0px1ny1pz) - weights[0][1][1] *
                voxelAt( pVoxel0px0py1nz) + weights[2][1][1] * voxelAt( pVoxel0px0py1pz) -
                weights[0][2][1] * voxelAt( pVoxel0px1py1nz) + weights[2][2][1] *
                voxelAt( pVoxel0px1py1pz) - weights[0][0][2] * voxelAt( pVoxel1px1ny1nz) +
                weights[2][0][2] * voxelAt( pVoxel1px1ny1pz) - weights[0][1][2] *
                voxelAt( pVoxel1px0py1nz) + weights[2][1][2] * voxelAt( pVoxel1px0py1pz) -
                weights[0][2][2] * voxelAt( pVoxel1px1py1nz) + weights[2][2][2] *
                voxelAt( pVoxel1px1py1pz));

            return Vector3DInt4(xGrad,yGrad,zGrad);
    }

    template <typename Type>
        Vector3DInt4 Volume<Type>::computeCentralDifferenceGradientAtSafe(const Vector3DUint4& position) const throw()
    {       
        if((position.x() <= (width()-2)) && (position.x() >= 1)
            && (position.y() <= (height()-2)) && (position.y() >= 1)
            && (position.z() <= (depth()-2)) && (position.z() >= 1))
        {
            return computeCentralDifferenceGradientAt(position);
        }
        else
        {
            return Vector3DInt4(0,0,0);
        }
    }

    template <typename Type>
        Vector3DInt4 Volume<Type>::computeSobelGradientAtSafe(const Vector3DUint4& position) const throw()
    {
        if((position.x() <= (width()-2)) && (position.x() >= 1)
            && (position.y() <= (height()-2)) && (position.y() >= 1)
            && (position.z() <= (depth()-2)) && (position.z() >= 1))
        {
            return computeSobelGradientAt(position);
        }
        else
        {
            return Vector3DInt4(0,0,0);
        }
    }

    /*-------------------------------------------------------------------------
    *Interpolated gradient accessors
    *------------------------------------------------------------------------*/

    template <typename Type>
        Vector3DDouble Volume<Type>::computeNearestNeighbourInterpolatedCentralDifferenceGradientAt(const Vector3DDouble& position) const throw()
    {
        assert((position.x() <= static_cast<double>(width() - 1)) && (position.x() >= 0.0f)
            && (position.y() <= static_cast<double>(height() - 1)) && (position.y() >= 0.0f)
            && (position.z() <= static_cast<double>(depth() - 1)) && (position.z() >= 0.0f));

        const uint4 roundedX = static_cast<uint4>(position.x() + 0.5f);
        const uint4 roundedY = static_cast<uint4>(position.y() + 0.5f);
        const uint4 roundedZ = static_cast<uint4>(position.z() + 0.5f);

        return static_cast< Vector3DDouble >(computeCentralDifferenceGradientAt(Vector3DUint4(roundedX,  roundedY, roundedZ)));
    }

    template <typename Type>
        Vector3DDouble Volume<Type>::computeTrilinearlyInterpolatedCentralDifferenceGradientAt(const Vector3DDouble& position) const throw()
    {
        assert((position.x() <= static_cast<double>(width() - 1)) && (position.x() >= 0.0f)
            && (position.y() <= static_cast<double>(height() - 1)) && (position.y() >= 0.0f)
            && (position.z() <= static_cast<double>(depth() - 1)) && (position.z() >= 0.0f));

        const uint4 floorX = static_cast<uint4>(position.x());
        const uint4 floorY = static_cast<uint4>(position.y());
        const uint4 floorZ = static_cast<uint4>(position.z());

        const uint4 ceilX = floorX + 1;
        const uint4 ceilY = floorY + 1;
        const uint4 ceilZ = floorZ + 1;

        const Vector3DInt4 v000 = computeCentralDifferenceGradientAt(Vector3DUint4(floorX, floorY, floorZ));
        const Vector3DInt4 v100 = computeCentralDifferenceGradientAt(Vector3DUint4(ceilX,  floorY, floorZ));
        const Vector3DInt4 v010 = computeCentralDifferenceGradientAt(Vector3DUint4(floorX, ceilY,  floorZ));
        const Vector3DInt4 v110 = computeCentralDifferenceGradientAt(Vector3DUint4(ceilX,  ceilY,  floorZ));
        const Vector3DInt4 v001 = computeCentralDifferenceGradientAt(Vector3DUint4(floorX, floorY, ceilZ));
        const Vector3DInt4 v101 = computeCentralDifferenceGradientAt(Vector3DUint4(ceilX,  floorY, ceilZ));
        const Vector3DInt4 v011 = computeCentralDifferenceGradientAt(Vector3DUint4(floorX, ceilY,  ceilZ));
        const Vector3DInt4 v111 = computeCentralDifferenceGradientAt(Vector3DUint4(ceilX,  ceilY,  ceilZ));

        return trilinearlyInterpolate< Vector3DDouble >(
            static_cast< Vector3DDouble >(v000),
            static_cast< Vector3DDouble >(v100),
            static_cast< Vector3DDouble >(v010),
            static_cast< Vector3DDouble >(v110),
            static_cast< Vector3DDouble >(v001),
            static_cast< Vector3DDouble >(v101),
            static_cast< Vector3DDouble >(v011),
            static_cast< Vector3DDouble >(v111),
            position.x() - floorX,position.y() - floorY,position.z() - floorZ);
    }

    template <typename Type>
        Vector3DDouble Volume<Type>::computeNearestNeighbourInterpolatedSobelGradientAt(const Vector3DDouble& position) const throw()
    {
        assert((position.x() <= static_cast<double>(width() - 1)) && (position.x() >= 0.0f)
            && (position.y() <= static_cast<double>(height() - 1)) && (position.y() >= 0.0f)
            && (position.z() <= static_cast<double>(depth() - 1)) && (position.z() >= 0.0f));

        const uint4 roundedX = static_cast<uint4>(position.x() + 0.5f);
        const uint4 roundedY = static_cast<uint4>(position.y() + 0.5f);
        const uint4 roundedZ = static_cast<uint4>(position.z() + 0.5f);

        return static_cast< Vector3DDouble >(computeSobelGradientAt(Vector3DUint4(roundedX,  roundedY, roundedZ)));
    }

    template <typename Type>
        Vector3DDouble Volume<Type>::computeTrilinearlyInterpolatedSobelGradientAt(const Vector3DDouble& position) const throw()
    {
        assert((position.x() <= static_cast<double>(width() - 1)) && (position.x() >= 0.0f)
            && (position.y() <= static_cast<double>(height() - 1)) && (position.y() >= 0.0f)
            && (position.z() <= static_cast<double>(depth() - 1)) && (position.z() >= 0.0f));

        const uint4 floorX = static_cast<uint4>(position.x());
        const uint4 floorY = static_cast<uint4>(position.y());
        const uint4 floorZ = static_cast<uint4>(position.z());

        const uint4 ceilX = floorX + 1;
        const uint4 ceilY = floorY + 1;
        const uint4 ceilZ = floorZ + 1;

        const Vector3DInt4 v000 = computeSobelGradientAt(Vector3DUint4(floorX, floorY, floorZ));
        const Vector3DInt4 v100 = computeSobelGradientAt(Vector3DUint4(ceilX,  floorY, floorZ));
        const Vector3DInt4 v010 = computeSobelGradientAt(Vector3DUint4(floorX, ceilY,  floorZ));
        const Vector3DInt4 v110 = computeSobelGradientAt(Vector3DUint4(ceilX,  ceilY,  floorZ));
        const Vector3DInt4 v001 = computeSobelGradientAt(Vector3DUint4(floorX, floorY, ceilZ));
        const Vector3DInt4 v101 = computeSobelGradientAt(Vector3DUint4(ceilX,  floorY, ceilZ));
        const Vector3DInt4 v011 = computeSobelGradientAt(Vector3DUint4(floorX, ceilY,  ceilZ));
        const Vector3DInt4 v111 = computeSobelGradientAt(Vector3DUint4(ceilX,  ceilY,  ceilZ));

        return trilinearlyInterpolate< Vector3DDouble >(
            static_cast< Vector3DDouble >(v000),
            static_cast< Vector3DDouble >(v100),
            static_cast< Vector3DDouble >(v010),
            static_cast< Vector3DDouble >(v110),
            static_cast< Vector3DDouble >(v001),
            static_cast< Vector3DDouble >(v101),
            static_cast< Vector3DDouble >(v011),
            static_cast< Vector3DDouble >(v111),
            position.x() - floorX,position.y() - floorY,position.z() - floorZ);
    }

    template <typename Type>
        Vector3DDouble Volume<Type>::computeNearestNeighbourInterpolatedCentralDifferenceGradientAtSafe(const Vector3DDouble& position) const throw()
    {
        if((position.x() <= static_cast<double>(width() - 2)) && (position.x() >= 1.0f)
            && (position.y() <= static_cast<double>(height() - 2)) && (position.y() >= 1.0f)
            && (position.z() <= static_cast<double>(depth() - 2)) && (position.z() >= 1.0f))
        {
            return computeNearestNeighbourInterpolatedCentralDifferenceGradientAt(position);
        }
        else
        {
            return Vector3DDouble(0.0f,0.0f,0.0f);
        }
    }

    template <typename Type>
        Vector3DDouble Volume<Type>::computeTrilinearlyInterpolatedCentralDifferenceGradientAtSafe(const Vector3DDouble& position) const throw()
    {        
        if((position.x() <= static_cast<double>(width() - 2)) && (position.x() >= 1.0f)
            && (position.y() <= static_cast<double>(height() - 2)) && (position.y() >= 1.0f)
            && (position.z() <= static_cast<double>(depth() - 2)) && (position.z() >= 1.0f))
        {
            return computeTrilinearlyInterpolatedCentralDifferenceGradientAt(position);
        }
        else
        {
            return Vector3DDouble(0.0f,0.0f,0.0f);
        }
    }

    template <typename Type>
        Vector3DDouble Volume<Type>::computeNearestNeighbourInterpolatedSobelGradientAtSafe(const Vector3DDouble& position) const throw()
    {
        if((position.x() <= static_cast<double>(width() - 2)) && (position.x() >= 1.0f)
            && (position.y() <= static_cast<double>(height() - 2)) && (position.y() >= 1.0f)
            && (position.z() <= static_cast<double>(depth() - 2)) && (position.z() >= 1.0f))
        {
            return computeNearestNeighbourInterpolatedSobelGradientAt(position);
        }
        else
        {
            return Vector3DDouble(0.0f,0.0f,0.0f);
        }
    }

    template <typename Type>
        Vector3DDouble Volume<Type>::computeTrilinearlyInterpolatedSobelGradientAtSafe(const Vector3DDouble& position) const throw()
    {
        if((position.x() <= static_cast<double>(width() - 2)) && (position.x() >= 1.0f)
            && (position.y() <= static_cast<double>(height() - 2)) && (position.y() >= 1.0f)
            && (position.z() <= static_cast<double>(depth() - 2)) && (position.z() >= 1.0f))
        {
            return computeTrilinearlyInterpolatedSobelGradientAt(position);
        }
        else
        {
            return Vector3DDouble(0.0f,0.0f,0.0f);
        }
    }

    /*-------------------------------------------------------------------------
    *Reconstruction Filters
    -------------------------------------------------------------------------*/
    template <typename Type>
        double Volume<Type>::applyFilter(const Vector3DDouble& position, ReconstructionFilter* xFilter, ReconstructionFilter* yFilter, ReconstructionFilter* zFilter) throw()
    {
        assert((position.x() <= static_cast<double>(width() - 1)) && (position.x() >= 0.0f)
            && (position.y() <= static_cast<double>(height() - 1)) && (position.y() >= 0.0f)
            && (position.z() <= static_cast<double>(depth() - 1)) && (position.z() >= 0.0f));

        const uint4 floorX = static_cast<uint4>(position.x());
        const uint4 floorY = static_cast<uint4>(position.y());
        const uint4 floorZ = static_cast<uint4>(position.z());

        const double offsetX = position.x() - floorX;
        const double offsetY = position.y() - floorY;
        const double offsetZ = position.z() - floorZ;

        interpolatedX.resize(yFilter->size());
        std::vector< std::vector< double> >::iterator interpolatedXIter = interpolatedX.begin();
        while(interpolatedXIter != interpolatedX.end())
        {
            interpolatedXIter->resize(yFilter->size());
            ++interpolatedXIter;
        }
        interpolatedXandY.resize(zFilter->size());

        xFilter->tau() = offsetX;	
        for(uint4 y = 0; y < yFilter->size(); ++y)
        {
            for(uint4 z = 0; z < zFilter->size(); ++z)
            {
                interpolatedX[y][z] = 0.0f;
                for(uint4 weightIndex = 0; weightIndex < xFilter->size(); ++weightIndex)
                {
                    interpolatedX[y][z] += xFilter->weightAt(weightIndex) * voxelAt(Vector3DUint4(floorX+weightIndex,floorY+y,floorZ+z));
                    //interpolatedX[y][z] = filter.weight(0) * voxelAt(Vector3DUint4(floorX,floorY+y,floorZ+z)) + filter.weight(1) * voxelAt(Vector3DUint4(floorX+1, floorY+y, floorZ+z));
                }
            }
        }
        /*interpolatedX[0][0] = filter.weight(0) * voxelAt(Vector3DUint4(floorX,floorY,floorZ)) + filter.weight(1) * voxelAt(Vector3DUint4(floorX+1, floorY, floorZ));
        interpolatedX[1][0] = filter.weight(0) * voxelAt(Vector3DUint4(floorX,floorY+1,floorZ)) + filter.weight(1) * voxelAt(Vector3DUint4(floorX+1, floorY+1, floorZ));
        interpolatedX[0][1] = filter.weight(0)* voxelAt(Vector3DUint4(floorX,floorY,floorZ+1)) + filter.weight(1) * voxelAt(Vector3DUint4(floorX+1, floorY, floorZ+1));
        interpolatedX[1][1] = filter.weight(0) * voxelAt(Vector3DUint4(floorX,floorY+1,floorZ+1)) + filter.weight(1) * voxelAt(Vector3DUint4(floorX+1, floorY+1, floorZ+1));*/

        yFilter->tau() = offsetY;
        for(uint4 z = 0; z < zFilter->size(); ++z)
        {
            interpolatedXandY[z] = 0.0f;
            for(uint4 weightIndex = 0; weightIndex < yFilter->size(); ++weightIndex)
            {
                interpolatedXandY[z] += yFilter->weightAt(weightIndex) * interpolatedX[weightIndex][z];
            }
            //interpolatedXandY[z] = filter.weight(0) * interpolatedX[0][z] + filter.weight(1) * interpolatedX[1][z];
        }
        /*interpolatedXandY[0] = filter.weight(0) * interpolatedX[0][0] + filter.weight(1) * interpolatedX[1][0];
        interpolatedXandY[1] = filter.weight(0) * interpolatedX[0][1] + filter.weight(1) * interpolatedX[1][1];*/

        zFilter->tau() = offsetZ;
        interpolatedXandYandZ = 0.0f;
        for(uint4 weightIndex = 0; weightIndex < zFilter->size(); ++weightIndex)
        {
            interpolatedXandYandZ += zFilter->weightAt(weightIndex) * interpolatedXandY[weightIndex];
        }
        //const double resultZ = filter.weightAt(0) * interpolatedXandY[0] + filter.weightAt(1) * interpolatedXandY[1];

        //const double final = resultZ;

        return interpolatedXandYandZ;
    }

	template <typename Type>
		double Volume<Type>::computeCurvatureAt(const Vector3DUint4& v3dPosition)
	{
		uint4 x = v3dPosition.x();
		uint4 y = v3dPosition.y();
		uint4 z = v3dPosition.z();

		Vector3DDouble v3dNormals[27];
		v3dNormals[ 0] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x-1,y-1,z-1)));
		v3dNormals[ 1] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x-1,y-1,z  )));
		v3dNormals[ 2] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x-1,y-1,z+1)));

		v3dNormals[ 3] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x-1,y  ,z-1)));
		v3dNormals[ 4] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x-1,y  ,z  )));
		v3dNormals[ 5] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x-1,y  ,z+1)));

		v3dNormals[ 6] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x-1,y+1,z-1)));
		v3dNormals[ 7] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x-1,y+1,z  )));
		v3dNormals[ 8] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x-1,y+1,z+1)));


		v3dNormals[ 9] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x  ,y-1,z-1)));
		v3dNormals[10] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x  ,y-1,z  )));
		v3dNormals[11] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x  ,y-1,z+1)));

		v3dNormals[12] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x  ,y  ,z-1)));
		v3dNormals[13] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x  ,y  ,z  )));
		v3dNormals[14] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x  ,y  ,z+1)));

		v3dNormals[15] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x  ,y+1,z-1)));
		v3dNormals[16] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x  ,y+1,z  )));
		v3dNormals[17] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x  ,y+1,z+1)));


		v3dNormals[18] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x+1,y-1,z-1)));
		v3dNormals[19] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x+1,y-1,z  )));
		v3dNormals[20] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x+1,y-1,z+1)));

		v3dNormals[21] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x+1,y  ,z-1)));
		v3dNormals[22] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x+1,y  ,z  )));
		v3dNormals[23] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x+1,y  ,z+1)));

		v3dNormals[24] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x+1,y+1,z-1)));
		v3dNormals[25] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x+1,y+1,z  )));
		v3dNormals[26] = static_cast<Vector3DDouble>(computeSobelGradientAt(Vector3DUint4(x+1,y+1,z+1)));					

		for(uint4 ct = 0; ct < 27; ct++)
		{
			v3dNormals[ct].normalise();
		}

		Vector3DDouble v3dAverageNormal(0.0,0.0,0.0);
		for(uint4 ct = 0; ct < 27; ct++)
		{
			v3dAverageNormal += v3dNormals[ct];
		}
		v3dAverageNormal /= 27.0;

		Vector3DDouble xMinusXBar[27];
		for(uint4 ct = 0; ct < 27; ct++)
		{
			xMinusXBar[ct] = v3dNormals[ct] - v3dAverageNormal;
		}

		Vector3DDouble xMinusXBarSquared[27];
		for(uint4 ct = 0; ct < 27; ct++)
		{
			xMinusXBarSquared[ct].setX(xMinusXBar[ct].x()*xMinusXBar[ct].x());
			xMinusXBarSquared[ct].setY(xMinusXBar[ct].y()*xMinusXBar[ct].y());
			xMinusXBarSquared[ct].setZ(xMinusXBar[ct].z()*xMinusXBar[ct].z());
		}

		Vector3DDouble averageOfXMinusXBarSquared(0.0,0.0,0.0);
		for(uint4 ct = 0; ct < 27; ct++)
		{
			averageOfXMinusXBarSquared += xMinusXBarSquared[ct];
		}
		averageOfXMinusXBarSquared /= 27.0;

		Vector3DDouble standardDeviation;
		standardDeviation.setX(sqrt(averageOfXMinusXBarSquared.x()));
		standardDeviation.setY(sqrt(averageOfXMinusXBarSquared.y()));
		standardDeviation.setZ(sqrt(averageOfXMinusXBarSquared.z()));

		return standardDeviation.x() + standardDeviation.y() + standardDeviation.z();
	}

	template <typename Type>
		double Volume<Type>::computeTrilinearlyInterpolatedCurvatureAt(const Vector3DDouble& v3dPosition)
	{
		const uint4 floorX = static_cast<uint4>(v3dPosition.x());
		const uint4 floorY = static_cast<uint4>(v3dPosition.y());
		const uint4 floorZ = static_cast<uint4>(v3dPosition.z());

		const uint4 ceilX = floorX + 1;
		const uint4 ceilY = floorY + 1;
		const uint4 ceilZ = floorZ + 1;

		const double v000 = computeCurvatureAt(Vector3DUint4(floorX, floorY, floorZ));
		const double v100 = computeCurvatureAt(Vector3DUint4(ceilX,  floorY, floorZ));
		const double v010 = computeCurvatureAt(Vector3DUint4(floorX, ceilY,  floorZ));
		const double v110 = computeCurvatureAt(Vector3DUint4(ceilX,  ceilY,  floorZ));
		const double v001 = computeCurvatureAt(Vector3DUint4(floorX, floorY, ceilZ));
		const double v101 = computeCurvatureAt(Vector3DUint4(ceilX,  floorY, ceilZ));
		const double v011 = computeCurvatureAt(Vector3DUint4(floorX, ceilY,  ceilZ));
		const double v111 = computeCurvatureAt(Vector3DUint4(ceilX,  ceilY,  ceilZ));

		return trilinearlyInterpolate<double>(v000,v100,v010,v110,v001,v101,v011,v111,v3dPosition.x() - floorX,v3dPosition.y() - floorY,v3dPosition.z() - floorZ);
	}

    /*template <typename Type>
        void Volume<Type>::computeCurvatureAt(const Vector3DDouble& position, double&k1, double& k2) throw()
    {
        ReconstructionFilter* interpolationFilter = ReconstructionFilter::createCatmullRomInterpolationFilter();
        //ReconstructionFilter* firstDerivativeFilter = ReconstructionFilter::createHighQualityFirstDerivativeFilter();
        ReconstructionFilter* firstDerivativeFilter = ReconstructionFilter::createFirstDerivativeFilter();
        ReconstructionFilter* secondDerivativeFilter = ReconstructionFilter::createSecondDerivativeFilter();

        //(1)
        double df_by_dx = applyFilter(position, firstDerivativeFilter, interpolationFilter, interpolationFilter);
        double df_by_dy = applyFilter(position, interpolationFilter, firstDerivativeFilter, interpolationFilter);
        double df_by_dz = applyFilter(position, interpolationFilter, interpolationFilter, firstDerivativeFilter);

        if((fabs(df_by_dx) < 0.001f) && (fabs(df_by_dy) < 0.001f) && (fabs(df_by_dz) < 0.001f))
        {
            k1 = 0;
            k2 = 0;
            return;
        }


        //THERMITE_LOG_DEBUG << "\tFirst derivatives: x = " << df_by_dx << " y = " << df_by_dy << " z = " << df_by_dz << std::endl;

        Vector3DDouble g(df_by_dx, df_by_dy, df_by_dz);
        double mod_g = g.length();

        Vector3DDouble n = g / mod_g;
        Vector3DDouble nT = n;

        Matrix3DDouble nnT;
        nnT(1,1) = n.x() * nT.x();
        nnT(1,2) = n.y() * nT.x();
        nnT(1,3) = n.z() * nT.x();

        nnT(2,1) = n.x() * nT.y();
        nnT(2,2) = n.y() * nT.y();
        nnT(2,3) = n.z() * nT.y();

        nnT(3,1) = n.x() * nT.z();
        nnT(3,2) = n.y() * nT.z();
        nnT(3,3) = n.z() * nT.z();

        Matrix3DDouble I = Matrix3DDouble::identity();

        Matrix3DDouble P = I - nnT;

        //(2)
        double d2f_by_dx2 = applyFilter(position, secondDerivativeFilter, interpolationFilter, interpolationFilter);
        double d2f_by_dy2 = applyFilter(position, interpolationFilter, secondDerivativeFilter, interpolationFilter);
        double d2f_by_dz2 = applyFilter(position, interpolationFilter, interpolationFilter, secondDerivativeFilter);

        double d2f_by_dxdy = applyFilter(position, firstDerivativeFilter, firstDerivativeFilter, interpolationFilter);
        double d2f_by_dxdz = applyFilter(position, firstDerivativeFilter, interpolationFilter, firstDerivativeFilter);
        double d2f_by_dydz = applyFilter(position, interpolationFilter, firstDerivativeFilter, firstDerivativeFilter);

        Matrix3DDouble H;
        H(1,1) = d2f_by_dx2;
        H(1,2) = d2f_by_dxdy;
        H(1,3) = d2f_by_dxdz;

        H(2,1) = d2f_by_dxdy;
        H(2,2) = d2f_by_dy2;
        H(2,3) = d2f_by_dydz;

        H(3,1) = d2f_by_dxdz;
        H(3,2) = d2f_by_dydz;
        H(3,3) = d2f_by_dz2;

        Matrix3DDouble minus_P = P * (-1.0f);

        Matrix3DDouble G = (minus_P * H) * P;
        G /= mod_g;

        //(3)
        double T = G(1,1) + G(2,2) + G(3,3);

        Matrix3DDouble GT = G.transpose();

        Matrix3DDouble GGT = G * GT;

        double F = sqrt(GGT(1,1) + GGT(2,2) + GGT(3,3));

        k1 = (T + sqrt(2*F*F - T*T))/2;
        k2 = (T - sqrt(2*F*F - T*T))/2;
        //THERMITE_LOG_DEBUG << "\tk1 = " << k1 << " k2 = " << k2 << std::endl;
    }*/

    /*-------------------------------------------------------------------------
    *Other stuff
    *------------------------------------------------------------------------*/

	template <typename Type>
	bool Volume<Type>::cellCornersBelowThreshold(const Vector3DDouble& position, const Type& tThreshold) const throw()
	{
		const uint4 floorX = static_cast<uint4>(position.x());
		const uint4 floorY = static_cast<uint4>(position.y());
		const uint4 floorZ = static_cast<uint4>(position.z());

		const uint4 ceilX = floorX + 1;
		const uint4 ceilY = floorY + 1;
		const uint4 ceilZ = floorZ + 1;

		return ((voxelAt(Vector3DUint4(floorX, floorY, floorZ)) < tThreshold) &&
		(voxelAt(Vector3DUint4(ceilX,  floorY, floorZ)) < tThreshold) &&
		(voxelAt(Vector3DUint4(floorX, ceilY,  floorZ)) < tThreshold) &&
		(voxelAt(Vector3DUint4(ceilX,  ceilY,  floorZ)) < tThreshold) &&
		(voxelAt(Vector3DUint4(floorX, floorY, ceilZ)) < tThreshold) &&
		(voxelAt(Vector3DUint4(ceilX,  floorY, ceilZ)) < tThreshold) &&
		(voxelAt(Vector3DUint4(floorX, ceilY,  ceilZ)) < tThreshold) &&
		(voxelAt(Vector3DUint4(ceilX,  ceilY,  ceilZ)) < tThreshold));
	}

    template <typename Type>
        std::vector<uint4> Volume<Type>::histogram(void) const throw()
    {
        //Identify the max value
        uint4 maxVal = 0;
        for(uint4 z = 0; z < depth(); ++z)
        {
            for(uint4 y = 0; y < height(); ++y)
            {
                for(uint4 x = 0; x < width(); ++x)
                {
                    uint4 current = voxelAt(Vector3DUint4(x,y,z));
                    if (current > maxVal)
                    {
                        maxVal = current;
                    }
                }
            }
        }

        THERMITE_LOG_DEBUG << "Max is " << maxVal <<std::endl;

        //Create the vector
        std::vector<uint4> result(maxVal+1,0);

        //Fill the vector
        for(uint4 z = 0; z < depth(); ++z)
        {
            for(uint4 y = 0; y < height(); ++y)
            {
                for(uint4 x = 0; x < width(); ++x)
                {
                    ++result[voxelAt(Vector3DUint4(x,y,z))];
                }
            }
        }

        return result;
    } 

	//Returns true if the point is contained inside the volume.
	template <typename Type>
	bool Volume<Type>::contains(const Vector3DDouble& point, uint4 uBorderinCells) const throw()
	{
		return ((point.x() >= static_cast<double>(uBorderinCells)) && 
			(point.y() >= static_cast<double>(uBorderinCells)) &&
			(point.z() >= static_cast<double>(uBorderinCells)) &&
			(point.x() <= static_cast<double>(m_uWidth - (uBorderinCells + 1))) &&
			(point.y() <= static_cast<double>(m_uHeight - (uBorderinCells + 1))) &&
			(point.z() <= static_cast<double>(m_uDepth - (uBorderinCells + 1))));
	}

	template <typename Type>
		Octree<Type>& Volume<Type>::octree() throw()
	{
		if(m_pOctree != 0)
		{
			return *m_pOctree;
		}
		//FIXME - else throw some exception?
	}

    /*-------------------------------------------------------------------------
    *File access
    *------------------------------------------------------------------------*/

    template <typename Type>
        void Volume<Type>::importDAT(const std::string& filename, boost::function<void (std::string, double)> progress) throw(file_error)
    {
		THERMITE_LOG_INFO << "Importing file " << filename << std::endl;

		//Open the file
        std::ifstream file;
        file.open(filename.c_str(), std::ios::in | std::ios::binary);
        if(!file.is_open())
        {
			std::string strError("Could not open file " + filename);
			THERMITE_LOG_ERROR << strError;
            throw file_error(strError);
        }

		//Read volume dimensions
        uint2 volumeWidth = 0;
        uint2 volumeHeight = 0;
        uint2 volumeDepth = 0;
        file.read(reinterpret_cast<char*>(&volumeWidth), sizeof(volumeWidth));
        file.read(reinterpret_cast<char*>(&volumeHeight), sizeof(volumeHeight));
        file.read(reinterpret_cast<char*>(&volumeDepth), sizeof(volumeDepth));
		if(file.fail())
		{
			std::string strError("Failed to read volume dimensions");
			THERMITE_LOG_ERROR << strError;
			throw file_error(strError);
		} 
		THERMITE_LOG_DEBUG << "Volume dimensions are (" << volumeWidth << "x" << volumeHeight << "x" << volumeDepth << ")" << std::endl;
		try
		{
			setDimensions(volumeWidth,volumeHeight,volumeDepth);
		}
		catch(const std::bad_alloc& e)
		{	
			std::string strError("Not enough memory");
			THERMITE_LOG_ERROR << strError;
			throw file_error(strError);
		}        

		//Read the data
        for(uint4 z = 0; z < volumeDepth; ++z)
        {			
            for(uint4 y = 0; y < volumeHeight; ++y)
            {
                for(uint4 x = 0; x < volumeWidth; ++x)
                {
                    Type value;
                    file.read(reinterpret_cast<char*>(&value), sizeof(Type));
                    voxelAt(Vector3DUint4(x,y,z)) = value;
                }
            }
			if(progress)
			{
				progress("Reading data...", static_cast<double>(z+1) / static_cast<double>(volumeDepth));
			}
        }

        //Check if any error occured...
		if(file.fail())
		{
			std::string strError("Failed to read volume data");
			THERMITE_LOG_ERROR << strError;
			throw file_error(strError);
		}     
        
		dataChanged(progress);
		THERMITE_LOG_INFO << "File imported successfully." << std::endl;
    }

    template <typename Type>
        bool Volume<Type>::exportDAT(const std::string& filename) const throw(file_error)
    {
        std::ofstream file;
        file.open(filename.c_str(), std::ios::out | std::ios::binary);
        if(!file.is_open())
        {
            THERMITE_LOG_ERROR << "Could not open file " << filename << std::endl;
            return false;
        }

        uint2 volumeWidth = static_cast<uint2>(m_uWidth);
        uint2 volumeHeight = static_cast<uint2>(m_uHeight);
        uint2 volumeDepth = static_cast<uint2>(m_uDepth);
        file.write(reinterpret_cast<char*>(&volumeWidth), sizeof(volumeWidth));
        file.write(reinterpret_cast<char*>(&volumeHeight), sizeof(volumeHeight));
        file.write(reinterpret_cast<char*>(&volumeDepth), sizeof(volumeDepth));
        for(uint4 z = 0; z < volumeDepth; ++z)
        {
            for(uint4 y = 0; y < volumeHeight; ++y)
            {
                for(uint4 x = 0; x < volumeWidth; ++x)
                {
                    Type value = voxelAt(Vector3DUint4(x,y,z));
                    file.write(reinterpret_cast<char*>(&value), sizeof(Type));
                }
            }
        }

        //Check if any error occured...
        if(file.bad())
        {
            THERMITE_LOG_ERROR << "Problem writing data." << std::endl;
            return false;
        }
        THERMITE_LOG_INFO << "File saved sucessfully." << std::endl;
        return true;
    }

	template <typename Type>
		void Volume<Type>::load(std::string strDir, boost::function<void (std::string, double)> progress) throw(file_error)
	{
		//Append a slash if necessary
		char charLast = strDir.at(strDir.length()-1);
		if((charLast != '\\') && (charLast != '/'))
		{
			strDir += "/";
		}
		THERMITE_LOG_INFO << "Loading directory " << strDir << std::endl;		

		std::ifstream streamMainData;
		std::string strMainDataFilename = strDir + "main.vol";
		
		streamMainData.open(strMainDataFilename.c_str(), std::ios::in | std::ios::binary);
		if(!streamMainData.is_open())
		{
			std::string strError("Could not open file " + strMainDataFilename);
			THERMITE_LOG_ERROR << strError;
			throw file_error(strError);
		}

		//Load values from the properties file.
		std::string strPropFilename = strDir + "properties.txt";
		PropertyValueMap propValMap(strPropFilename);
		boost::optional<uint4> uWidth = propValMap.getValueAs<uint4>("width");
		boost::optional<uint4> uHeight = propValMap.getValueAs<uint4>("height");
		boost::optional<uint4> uDepth = propValMap.getValueAs<uint4>("depth");
		if((!uWidth) || (!uHeight) || (!uDepth))
		{
			std::string strError("Could not find all dimensions");
			THERMITE_LOG_ERROR << strError;
			throw file_error(strError);
		}
		THERMITE_LOG_INFO << "Volume dimensions are " << Vector3DUint4(*uWidth,*uHeight,*uDepth);

		boost::iostreams::filtering_streambuf<boost::iostreams::input> bufMainData;
		boost::optional<std::string> strCompressionMethod = propValMap.getValueAs<std::string>("compression");
		if(strCompressionMethod)
		{
			if(strCompressionMethod->compare("none") == 0)
			{
				THERMITE_LOG_DEBUG << "Using no decompression filter";
			}
			else if(strCompressionMethod->compare("bzip2") == 0)
			{
				bufMainData.push(boost::iostreams::bzip2_decompressor());
				THERMITE_LOG_DEBUG << "Using bzip2 decompression filter";
			}
			else if(strCompressionMethod->compare("gzip") == 0)
			{
				bufMainData.push(boost::iostreams::gzip_decompressor());
				THERMITE_LOG_DEBUG << "Using gzip decompression filter";
			}
			else if(strCompressionMethod->compare("zlib") == 0)
			{
				bufMainData.push(boost::iostreams::zlib_decompressor());
				THERMITE_LOG_DEBUG << "Using zlib decompression filter";
			}
		}
		else
		{
			THERMITE_LOG_WARN << "Could not determine decompression method - using none";
		}
		bufMainData.push(streamMainData);

		try
		{
			setDimensions(*uWidth,*uHeight,*uDepth);
		}
		catch(const std::bad_alloc& e)
		{	
			std::string strError("Not enough memory");
			THERMITE_LOG_ERROR << strError;
			throw file_error(strError);
		} 

		//Read the data
		for(uint4 z = 0; z < *uDepth; ++z)
		{
			for(uint4 y = 0; y < *uHeight; ++y)
			{
				for(uint4 x = 0; x < *uWidth; ++x)
				{
					Type value;
					boost::iostreams::read(bufMainData,reinterpret_cast<char*>(&value), sizeof(Type));
					voxelAt(Vector3DUint4(x,y,z)) = value;
				}
			}
			if(progress)
			{
				progress("Reading data...", static_cast<double>(z+1) / static_cast<double>(*uDepth));
			}
		}

		dataChanged(progress);
		THERMITE_LOG_INFO << "Data loaded successfully." << std::endl;
	}

	template <typename Type>
		bool Volume<Type>::save(std::string strDir, CompressionMethod compressionMethod) throw(file_error)
	{
		//Append a slash if necessary
		char charLast = strDir.at(strDir.length()-1);
		if((charLast != '\\') && (charLast != '/'))
		{
			strDir += "/";
		}
		THERMITE_LOG_INFO << "Saving directory " << strDir << std::endl;

		//Load values from the properties file.
		std::string strPropFilename = strDir + "properties.txt";
		PropertyValueMap propValMap;
		propValMap.addPropertyValuePair<uint2>("width", width());
		propValMap.addPropertyValuePair<uint2>("height", height());
		propValMap.addPropertyValuePair<uint2>("depth", depth());
		switch(compressionMethod)
		{
		case NONE:
			{
				propValMap.addPropertyValuePair<std::string>("compression", "none");
				break;
			}
		case BZIP2:
			{
				propValMap.addPropertyValuePair<std::string>("compression", "bzip2");
				break;
			}
		case GZIP:
			{
				propValMap.addPropertyValuePair<std::string>("compression", "gzip");
				break;
			}
		case ZLIB:
			{
				propValMap.addPropertyValuePair<std::string>("compression", "zlib");
				break;
			}
		}
		propValMap.save(strPropFilename);

		std::ofstream streamMainData;
		std::string strMainDataFilename = strDir + "main.vol";

		streamMainData.open(strMainDataFilename.c_str(), std::ios::out | std::ios::binary);
		if(!streamMainData.is_open())
		{
			THERMITE_LOG_ERROR << "Could not open file " << strMainDataFilename << std::endl;
			return false;
		}

		boost::iostreams::filtering_streambuf<boost::iostreams::output> bufMainData;
		switch(compressionMethod)
		{
		case BZIP2:
			{
				bufMainData.push(boost::iostreams::bzip2_compressor());
				break;
			}
		case GZIP:
			{
				bufMainData.push(boost::iostreams::gzip_compressor());
				break;
			}
		case ZLIB:
			{
				bufMainData.push(boost::iostreams::zlib_compressor());
				break;
			}
		}
		bufMainData.push(streamMainData);

		for(uint4 z = 0; z < depth(); ++z)
		{
			for(uint4 y = 0; y < height(); ++y)
			{
				for(uint4 x = 0; x < width(); ++x)
				{
					Type value = voxelAt(Vector3DUint4(x,y,z));
					boost::iostreams::write(bufMainData,reinterpret_cast<char*>(&value), sizeof(Type));
				}
			}
		}

		//FIXME - do some checksumming?

		THERMITE_LOG_INFO << "Data saved sucessfully." << std::endl;
		return true;
	}

	template <typename Type>
	void Volume<Type>::dataChanged(boost::function<void (std::string, double)> progress)
	{
		THERMITE_LOG_DEBUG << "Volume<Type>::dataChanged()" << std::endl;

		if(m_pOctree != 0)
		{
			delete m_pOctree;
			m_pOctree = 0;
		}
		m_pOctree = new Octree<Type>(*this);
		int4 size = m_pOctree->buildOctree(progress);
		THERMITE_LOG_DEBUG << "Number of octree nodes = " << size << std::endl;
	}


}
