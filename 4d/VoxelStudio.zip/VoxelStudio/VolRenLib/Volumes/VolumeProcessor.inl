#include "MarchingCubesTables.hpp"

namespace Thermite
{
	template <typename Type>
		std::vector< std::vector< Vector3DDouble > > VolumeProcessor<Type>::extractMeshForIsosurface(const Volume<Type>* pVolume, const double fIsovalue, boost::function<void (std::string, double)> progress)
	{
		std::vector< std::vector< Vector3DDouble > > triangles;
		for(uint4 z = 0; z < pVolume->depth()-1; ++z)
		{
			THERMITE_LOG_DEBUG << z << std::endl;
			for(uint4 y = 0; y < pVolume->height()-1; ++y)
			{
				for(uint4 x = 0; x < pVolume->width()-1; ++x)
				{
					//THERMITE_LOG_DEBUG << "x = " << x << " y = " << y << " z = " << z << std::endl;
					std::vector< std::vector< Vector3DDouble > > trianglesForThisCell = extractMeshForIsosurfaceForCell(pVolume, Vector3DUint4(x,y,z),fIsovalue);
					/*triangles.resize(triangles.size() + trianglesForThisCell.size());
					std::copy(trianglesForThisCell.begin(),trianglesForThisCell.end(),triangles.begin());*/
					std::vector< std::vector< Vector3DDouble > >::iterator trianglesForThisCellIter = trianglesForThisCell.begin();
					while(trianglesForThisCellIter != trianglesForThisCell.end())
					{
						std::vector< Vector3DDouble > triangle = (*trianglesForThisCellIter);
						triangles.push_back(triangle);
						++trianglesForThisCellIter;
					}
				}
			}
			if(progress)
			{
				progress("Extracting mesh for isosurface...", static_cast<double>(z+1) / static_cast<double>(pVolume->depth()));
			}
		}
		return triangles;
	}

	template <typename Type>
		std::vector< std::vector< Vector3DDouble > > VolumeProcessor<Type>::extractMeshForIsosurfaceForCell(const Volume<Type>* pVolume, Vector3DUint4 cell, const double fIsovalue)
	{
		uint4 i,uNoOfTriangles;
		int iCubeIndex;
		Vector3DDouble vertlist[12];
		std::vector< std::vector< Vector3DDouble > > triangles;	

		/*
		Determine the index into the edge table which
		tells us which vertices are inside of the surface
		*/
		iCubeIndex = 0;
		if (pVolume->voxelAt(cell + Vector3DUint4(0,0,0)) < fIsovalue) iCubeIndex |= 1;
		if (pVolume->voxelAt(cell + Vector3DUint4(1,0,0)) < fIsovalue) iCubeIndex |= 2;
		if (pVolume->voxelAt(cell + Vector3DUint4(1,1,0)) < fIsovalue) iCubeIndex |= 4;
		if (pVolume->voxelAt(cell + Vector3DUint4(0,1,0)) < fIsovalue) iCubeIndex |= 8;
		if (pVolume->voxelAt(cell + Vector3DUint4(0,0,1)) < fIsovalue) iCubeIndex |= 16;
		if (pVolume->voxelAt(cell + Vector3DUint4(1,0,1)) < fIsovalue) iCubeIndex |= 32;
		if (pVolume->voxelAt(cell + Vector3DUint4(1,1,1)) < fIsovalue) iCubeIndex |= 64;
		if (pVolume->voxelAt(cell + Vector3DUint4(0,1,1)) < fIsovalue) iCubeIndex |= 128;
		//THERMITE_LOG_DEBUG << "Cube Index = " << iCubeIndex << std::endl;
		//THERMITE_LOG_DEBUG << "Edge Table[Cube Index] = " << edgeTable[iCubeIndex] << std::endl;

		/* Cube is entirely in/out of the surface */
		if (edgeTable[iCubeIndex] == 0)
			return triangles;

		/* Find the vertices where the surface intersects the cube */
		if (edgeTable[iCubeIndex] & 1)
		{
			//THERMITE_LOG_DEBUG << "Added edge 0" <<std::endl;
			vertlist[0] = VolumeProcessor<Type>::VertexInterpolateBasic(pVolume, cell + Vector3DUint4(0,0,0),cell + Vector3DUint4(1,0,0), fIsovalue);
		}
		if (edgeTable[iCubeIndex] & 2)
		{
			//THERMITE_LOG_DEBUG << "Added edge 1" <<std::endl;
			vertlist[1] = VolumeProcessor<Type>::VertexInterpolateBasic(pVolume, cell + Vector3DUint4(1,0,0),cell + Vector3DUint4(1,1,0), fIsovalue);
		}
		if (edgeTable[iCubeIndex] & 4)
		{
			//THERMITE_LOG_DEBUG << "Added edge 2" <<std::endl;
			vertlist[2] = VolumeProcessor<Type>::VertexInterpolateBasic(pVolume, cell + Vector3DUint4(1,1,0),cell + Vector3DUint4(0,1,0), fIsovalue);
		}
		if (edgeTable[iCubeIndex] & 8)
		{
			//THERMITE_LOG_DEBUG << "Added edge 3" <<std::endl;
			vertlist[3] = VolumeProcessor<Type>::VertexInterpolateBasic(pVolume, cell + Vector3DUint4(0,1,0),cell + Vector3DUint4(0,0,0), fIsovalue);
		}
		if (edgeTable[iCubeIndex] & 16)
		{
			//THERMITE_LOG_DEBUG << "Added edge 4" <<std::endl;
			vertlist[4] = VolumeProcessor<Type>::VertexInterpolateBasic(pVolume, cell + Vector3DUint4(0,0,1),cell + Vector3DUint4(1,0,1), fIsovalue);
		}
		if (edgeTable[iCubeIndex] & 32)
		{
			//THERMITE_LOG_DEBUG << "Added edge 5" <<std::endl;
			vertlist[5] = VolumeProcessor<Type>::VertexInterpolateBasic(pVolume, cell + Vector3DUint4(1,0,1),cell + Vector3DUint4(1,1,1), fIsovalue);
		}
		if (edgeTable[iCubeIndex] & 64)
		{
			//THERMITE_LOG_DEBUG << "Added edge 6" <<std::endl;
			vertlist[6] = VolumeProcessor<Type>::VertexInterpolateBasic(pVolume, cell + Vector3DUint4(1,1,1),cell + Vector3DUint4(0,1,1), fIsovalue);
		}
		if (edgeTable[iCubeIndex] & 128)
		{
			//THERMITE_LOG_DEBUG << "Added edge 7" <<std::endl;
			vertlist[7] = VolumeProcessor<Type>::VertexInterpolateBasic(pVolume, cell + Vector3DUint4(0,1,1),cell + Vector3DUint4(0,0,1), fIsovalue);
		}
		if (edgeTable[iCubeIndex] & 256)
		{
			//THERMITE_LOG_DEBUG << "Added edge 8" <<std::endl;
			vertlist[8] = VolumeProcessor<Type>::VertexInterpolateBasic(pVolume, cell + Vector3DUint4(0,0,0),cell + Vector3DUint4(0,0,1), fIsovalue);
		}
		if (edgeTable[iCubeIndex] & 512)
		{
			//THERMITE_LOG_DEBUG << "Added edge 9" <<std::endl;
			vertlist[9] = VolumeProcessor<Type>::VertexInterpolateBasic(pVolume, cell + Vector3DUint4(1,0,0),cell + Vector3DUint4(1,0,1), fIsovalue);
		}
		if (edgeTable[iCubeIndex] & 1024)
		{
			//THERMITE_LOG_DEBUG << "Added edge 10" <<std::endl;
			vertlist[10] = VolumeProcessor<Type>::VertexInterpolateBasic(pVolume, cell + Vector3DUint4(1,1,0),cell + Vector3DUint4(1,1,1), fIsovalue);
		}
		if (edgeTable[iCubeIndex] & 2048)
		{
			//THERMITE_LOG_DEBUG << "Added edge 11" <<std::endl;
			vertlist[11] = VolumeProcessor<Type>::VertexInterpolateBasic(pVolume, cell + Vector3DUint4(0,1,0),cell + Vector3DUint4(0,1,1), fIsovalue);
		}

		/* Create the triangle */
		uNoOfTriangles = 0;
		for (i=0;triTable[iCubeIndex][i]!=-1;i+=3)
		{
			std::vector< Vector3DDouble > triangle;
			triangle.push_back(vertlist[triTable[iCubeIndex][i  ]]);
			triangle.push_back(vertlist[triTable[iCubeIndex][i+1]]);
			triangle.push_back(vertlist[triTable[iCubeIndex][i+2]]);
			triangles.push_back(triangle);
			uNoOfTriangles++;
		}

		return(triangles);
	}

	template <typename Type>
		Vector3DDouble VolumeProcessor<Type>::VertexInterpolateBasic(const Volume<Type>* pVolume, Vector3DUint4 p1,Vector3DUint4 p2,const double fIsovalue)
	{
		double mu;
		Vector3DDouble p;
		Vector3DDouble fP1(p1.x(),p1.y(),p1.z());
		Vector3DDouble fP2(p2.x(),p2.y(),p2.z());

		if (abs(fIsovalue-pVolume->voxelAt(p1)) < 0.00001)
			return(fP1);
		if (abs(fIsovalue-pVolume->voxelAt(p2)) < 0.00001)
			return(fP2);
		if (abs(pVolume->voxelAt(p1)-pVolume->voxelAt(p2)) < 0.00001)
			return(fP1);
		mu = (fIsovalue - pVolume->voxelAt(p1)) / (pVolume->voxelAt(p2) - pVolume->voxelAt(p1));
		p.setX(fP1.x() + mu * (fP2.x() - fP1.x()));
		p.setY(fP1.y() + mu * (fP2.y() - fP1.y()));
		p.setZ(fP1.z() + mu * (fP2.z() - fP1.z()));

		return(p);
	}    
}