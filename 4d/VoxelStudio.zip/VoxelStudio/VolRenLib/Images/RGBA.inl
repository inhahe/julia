#include <algorithm>

namespace Thermite
{
    //-------------------------- Constructors, etc ---------------------------------
    template <typename Type>
    RGBA<Type>::RGBA(Type tRed, Type tGreen, Type tBlue, Type tAlpha) throw()
        :m_tRed(tRed)
        ,m_tGreen(tGreen)
        ,m_tBlue(tBlue)
        ,m_tAlpha(tAlpha)
    {
    }

    template <typename Type>
    RGBA<Type>::RGBA(const RGBA<Type>& colourToCopy) throw()
		:m_tRed(colourToCopy.m_tRed)
		,m_tGreen(colourToCopy.m_tGreen)
		,m_tBlue(colourToCopy.m_tBlue)
		,m_tAlpha(colourToCopy.m_tAlpha)
	{		
    }

    template <typename Type>
    RGBA<Type>::~RGBA() throw()
    {
    }

    //------------------------------- Overloaded Operators -------------------------

    template <typename Type>
    inline RGBA<Type>& RGBA<Type>::operator=(const RGBA<Type>& rhs) throw()
    {
		if(this == &rhs)
		{
			return *this;
		}
        m_tRed = rhs.m_tRed;
        m_tGreen = rhs.m_tGreen;
        m_tBlue = rhs.m_tBlue;
        m_tAlpha = rhs.m_tAlpha;
        return *this;
    }

    /*!
    Note: This function does not adjust the alpha component
    */
    template <typename Type>
    inline RGBA<Type>& RGBA<Type>::operator*=(const double& rhs) throw()
    {
        m_tRed *= rhs;
        m_tGreen *= rhs;
        m_tBlue *= rhs;
        return *this;
    }

    /*!
    Note: This function does not adjust the alpha component
    */
    template <typename Type>
    inline RGBA<Type>& RGBA<Type>::operator/=(const double& rhs) throw()
    {
        m_tRed /= rhs;
        m_tGreen /= rhs;
        m_tBlue /= rhs;
        return *this;
    }

    template <typename Type>
    inline RGBA<Type>& RGBA<Type>::operator+=(const RGBA<Type>& rhs) throw()
    {
        //FIXME - Need to think what we should do with the alpha?
        m_tRed += rhs.m_tRed;
        m_tGreen += rhs.m_tGreen;
        m_tBlue += rhs.m_tBlue;
        return *this;
    }

    template <typename Type>
    inline RGBA<Type>& RGBA<Type>::operator-=(const RGBA<Type>& rhs) throw()
    {
        //FIXME - Need to think what we should do with the alpha?
        m_tRed -= rhs.m_tRed;
        m_tGreen -= rhs.m_tGreen;
        m_tBlue -= rhs.m_tBlue;
        return *this;
    }    

    /*!
    Enables the typename to be used intuitavly with output streams such as cout.
    \param os The output stream to write to.
    \param colour The RGBA to write to the stream.
    \return A reference to the output stream to allow chaining.
    */
    template <typename Type>
    std::ostream& operator<<(std::ostream& os, const RGBA<Type>& colour) throw()
    {
        os << "(" << double(colour.red()) << "," << double(colour.green()) << "," << double(colour.blue()) << "," << double(colour.alpha()) <<")";
        return os;
    }
    //----------------------------------- Getters ----------------------------------

    template <typename Type>
    inline Type RGBA<Type>::red(void) const throw()
    {
        return m_tRed;
    }

    template <typename Type>
    inline Type RGBA<Type>::green(void) const throw()
    {
        return m_tGreen;
    }

    template <typename Type>
    inline Type RGBA<Type>::blue(void) const throw()
    {
        return m_tBlue;
    }

    template <typename Type>
    inline Type RGBA<Type>::alpha(void) const throw()
    {
        return m_tAlpha;
    }

    template <typename Type>
        inline void RGBA<Type>::setRed(Type tRed) throw()
    {
        return m_tRed;
    }

    template <typename Type>
        inline void RGBA<Type>::setGreen(Type tGreen) throw()
    {
        return m_tGreen;
    }

    template <typename Type>
        inline void RGBA<Type>::setBlue(Type tBlue) throw()
    {
        return m_tBlue;
    }

    template <typename Type>
        inline void RGBA<Type>::setAlpha(Type tAlpha) throw()
    {
        return m_tAlpha;
    }

    //----------------------------------- Setters ----------------------------------
    template <typename Type>
    inline void RGBA<Type>::set(Type tRed, Type tGreen, Type tBlue, Type tAlpha) throw()
    {
        m_tRed = tRed;
        m_tGreen = tGreen;
        m_tBlue = tBlue;
        m_tAlpha = tAlpha;
    }

    //-------------------------------- Other Functions -----------------------------
    template <typename Type>
    inline void RGBA<Type>::clampToRange(const Type& minVal, const Type& maxVal) throw()
    {
        m_tRed = std::max(std::min(m_tRed, maxVal), minVal);
        m_tBlue = std::max(std::min(m_tBlue, maxVal), minVal);
        m_tGreen = std::max(std::min(m_tGreen, maxVal), minVal);
        m_tAlpha = std::max(std::min(m_tAlpha, maxVal), minVal);
    }	
}
