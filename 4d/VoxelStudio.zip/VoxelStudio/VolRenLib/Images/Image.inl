#include "..\Base\Logging.hpp"

namespace Thermite
{
//----------------------------------- Image -----------------------------------
    template <typename Type>
    Image<Type>::Image() throw()
        :m_uWidth(0)
        ,m_uHeight(0)
    {
    }

    template <typename Type>
    Image<Type>::Image(const Image<Type>& rhs)
    {
        THERMITE_LOG_DEBUG << "Image copy constructor is expensive" << std::endl;
        *this = rhs;
    }

    template <typename Type>
    Image<Type>::~Image() throw()
    {
    }

    /**
    *Performs a deep copy.
    */
    template <typename Type>
    Image<Type>& Image<Type>::operator=(const Image<Type>& rhs) throw()
    {
        THERMITE_LOG_DEBUG << "WARNING: Image assignment operator is expensive" << std::endl;
        assert(this != &rhs);
        m_uWidth = rhs.m_uWidth;
        m_uHeight = rhs.m_uHeight;
        m_vecData = rhs.m_vecData;
        return *this;
    }

    template <typename Type>
    inline const Type& Image<Type>::pixelAt(const uint4 uX, const uint4 uY) const throw()
    {
        assert((uX < m_uWidth) && (uY < m_uHeight));
        return m_vecData[(uY*m_uWidth)+uX];
    }

    template <typename Type>
    inline Type& Image<Type>::pixelAt(const uint4 uX, const uint4 uY) throw()
    {
        assert((uX < m_uWidth) && (uY < m_uHeight));
        return m_vecData[(uY*m_uWidth)+uX];
    }

    /*template <typename Type>
    inline const Type& Image<Type>::operator()(uint4 x, uint4 y) const throw()
    {
        assert((x < m_uWidth) && (y < m_uHeight));
        return m_vecData[(y*m_uWidth)+x];
    }

    template <typename Type>
    inline Type& Image<Type>::operator()(uint4 x, uint4 y) throw()
    {
        assert((x < m_uWidth) && (y < m_uHeight));
        return m_vecData[(y*m_uWidth)+x];
    }*/

    template <typename Type>
    inline uint4 Image<Type>::height(void) const throw()
    {
        return m_uHeight;
    }

    template <typename Type>
    inline uint4 Image<Type>::width(void) const throw()
    {
        return m_uWidth;
    }

    template <typename Type>
    inline Type* const Image<Type>::rawData(void) throw()
    {
        //FIXME - is there a better way?
        return &(m_vecData[0]);
    }    

    template <typename Type>
    void Image<Type>::resize(const uint4 uWidth,const uint4 uHeight)
    {
		THERMITE_LOG_DEBUG << "Image resize function is expensive" << std::endl;
        //Check whether the new size is actually different.
        if((uWidth == m_uWidth) && (uHeight == m_uHeight))
        {
            return;
        }

        //Do the resize
        m_vecData.resize(uWidth * uHeight);
        m_uWidth = uWidth;
        m_uHeight = uHeight;
    }

		template <typename Type>
		void Image<Type>::clearTo(const Type& colour) throw()
		{
			/*for(uint4 y = 0; y < height(); ++y)
			{
				for(uint4 x = 0; x < width(); ++x)
				{
					m_vecData[y * width() + x] = colour;
				}
			}*/
            //m_vecData.assign(colour, m_uWidth*m_uHeight);
            fill(m_vecData.begin(), m_vecData.end(),colour);
		}

//--------------------------------- Iterator ----------------------------------
    /*template <typename Type>
    typename Image<Type>::Iterator& Image<Type>::Iterator::operator=(const Iterator& rhs) throw()
    {
        assert(this != &rhs);
        xVal = rhs.xVal;
        yVal = rhs.yVal;
        image = rhs.image;
        return *this;
    }

    template <typename Type>
    bool Image<Type>::Iterator::operator==(const Iterator& rhs) const throw()
    {
        return ((xVal == rhs.xVal)
            && (yVal == rhs.yVal)
            && (image == rhs.image));
    }

    template <typename Type>
    bool Image<Type>::Iterator::operator!=(const Iterator& rhs) const throw()
    {
        return (!(*this == rhs));
    }

    template <typename Type>
    typename Image<Type>::Iterator& Image<Type>::Iterator::operator++(void) throw()
    {
        assert((yVal*image.widthVal+xVal) <= (image.widthVal*image.heghtVal));
        if(xVal < image.widthVal-1)
            ++xVal;
        else
        {
            xVal = 0;
            ++yVal;
        }
    }

    template <typename Type>
        typename Image<Type>::Iterator Image<Type>::Iterator::operator++(int) throw()
    {
        Iterator iter = *this;
        ++(*this);
        return iter;
    }

    template <typename Type>
        const Type& Image<Type>::Iterator::operator*(void) throw()
    {
        return image.dataPtr[y * image.width + x];
    }

    template <typename Type>
        const Type& Image<Type>::Iterator::operator->(void) throw()
    {
        return image.dataPtr[y * image.width + x];
    }

    template <typename Type>
        uint4 Image<Type>::Iterator::x(void) const throw()
    {
        return xVal;
    }

    template <typename Type>
        uint4 Image<Type>::Iterator::y(void) const throw()
    {
        return yVal;
    }

    template <typename Type>
        void Image<Type>::Iterator::setX(uint4 xToSet) throw()
    {
    }

    template <typename Type>
        void Image<Type>::Iterator::setY(uint4 yToSet) throw()
    {
    }*/
}
