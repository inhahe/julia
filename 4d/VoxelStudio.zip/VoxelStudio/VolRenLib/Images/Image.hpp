#ifndef IMAGE_HEADER_INCLUDED
#define IMAGE_HEADER_INCLUDED

#include <cassert>
#include <vector>

#include "..\Base\Typedef.hpp"

namespace Thermite
{
    template <typename Type>
    class Image
    {
    public:
        Image() throw();
        Image(const Image& rhs);
        ~Image() throw();

        Image<Type>& operator=(const Image<Type>& rhs) throw();
        //const Type& operator()(uint4 x, uint4 y) const throw();
        //Type& operator()(uint4 x, uint4 y) throw();

        const Type& pixelAt(const uint4 uX, const uint4 uY) const throw();
        Type& pixelAt(const uint4 uX, const uint4 uY) throw();

        void clearTo(const Type& colour) throw();
        uint4 height(void) const throw();
        Type* const rawData(void) throw();
        void resize(const uint4 uWidth, const uint4 uHeight);
        uint4 width(void) const throw();				

        /*class Iterator
        {
        public:
            Iterator()
            {
            };

            ~Iterator();

            Iterator& operator=(const Iterator& rhs) throw();
            bool operator==(const Iterator& rhs) const throw();
            bool operator!=(const Iterator& rhs) const throw();
            Iterator& operator++(void) throw();
            Iterator operator++(int) throw();
            const Type& operator*(void) throw();
            const Type& operator->(void) throw();

            uint4 x(void) const throw();
            uint4 y(void) const throw();

            void setX(uint4 xToSet) throw();
            void setY(uint4 yToSet) throw();

        private:
            Image& image;
            uint4 xVal;
            uint4 yVal;
        };*/

    private:
        std::vector<Type> m_vecData;
        uint4 m_uHeight;
        uint4 m_uWidth;                
    };
}//namespace Thermite

#include "Image.inl"

#endif	//IMAGE_HEADER_INCLUDED

