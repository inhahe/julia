#include "RGBA.hpp"

namespace Thermite
{
	RGBA<double> convertToRGBADouble(const RGBA<uint1>& rgbaInput)
	{
		double dRed = static_cast<double>(rgbaInput.red());
		double dGreen = static_cast<double>(rgbaInput.green());
		double dBlue = static_cast<double>(rgbaInput.blue());
		double dAlpha = static_cast<double>(rgbaInput.alpha());

		return RGBA<double>(dRed/255.0,dGreen/255.0,dBlue/255.0,dAlpha/255.0);
	}

	RGBA<uint1> convertToRGBAUint1(const RGBA<double>& rgbaInput)
	{
		uint1 uRed = static_cast<uint1>(rgbaInput.red() * 255.0);
		uint1 uGreen = static_cast<uint1>(rgbaInput.green() * 255.0);
		uint1 uBlue = static_cast<uint1>(rgbaInput.blue() * 255.0);
		uint1 uAlpha = static_cast<uint1>(rgbaInput.alpha() * 255.0);

		return RGBA<uint1>(uRed,uGreen,uBlue,uAlpha);
	}
}