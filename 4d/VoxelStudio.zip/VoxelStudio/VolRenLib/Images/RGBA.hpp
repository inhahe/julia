#ifndef RGBA_H
#define RGBA_H

#include <boost\operators.hpp>

#include "..\Base\Typedef.hpp"

namespace Thermite
{
    template <typename Type>
    class RGBA
		: boost::addable< RGBA<Type>          // RGBA + RGBA
		, boost::subtractable< RGBA<Type>     // RGBA - RGBA
		, boost::dividable2< RGBA<Type>, Type    // RGBA / Type
		, boost::multipliable2< RGBA<Type>, Type // RGBA * Type, Type * RGBA
		, boost::equality_comparable1< RGBA<Type> // RGBA != RGBA
		> > > > >
    {
    public:
        RGBA(const Type tRed = 0.0, const Type tGreen = 0.0, const Type tBlue = 0.0, const Type tAlpha = 1.0) throw();
        RGBA(const RGBA<Type>& colourToCopy) throw();
        ~RGBA() throw();

        RGBA<Type>& operator=(const RGBA<Type>& rhs) throw();
        RGBA<Type>& operator*=(const double& rhs) throw();
        RGBA<Type>& operator/=(const double& rhs) throw();
        RGBA<Type>& operator+=(const RGBA<Type>& rhs) throw();
        RGBA<Type>& operator-=(const RGBA<Type>& rhs) throw();

        Type red(void) const throw();
        Type green(void) const throw();
        Type blue(void) const throw();
        Type alpha(void) const throw();

        void setRed(Type tRed) throw();
        void setGreen(Type tBlue) throw();
        void setBlue(Type tGreen) throw();
        void setAlpha(Type tAlpha) throw();

        void set(const Type tRed, const Type tGreen, const Type tBlue, const Type tAlpha) throw();

        void clampToRange(const Type& minVal, const Type& maxVal) throw();		

    private:
        Type m_tRed;
        Type m_tGreen;
        Type m_tBlue;
        Type m_tAlpha;
    };
    //!Stream Insertion Operator.
    template <typename Type>
    std::ostream& operator<<(std::ostream& os, const RGBA<Type>& colour) throw();

	RGBA<double> convertToRGBADouble(const RGBA<uint1>& rgbaInput);
	RGBA<uint1> convertToRGBAUint1(const RGBA<double>& rgbaInput);
}

#include "RGBA.inl"

#endif	//RGBA_H
