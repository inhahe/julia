#include "..\Images\Image.hpp"

#include "Camera.hpp"
#include "Renderer.hpp"

namespace Thermite
{
        Renderer::Renderer() throw()
    {
		cameraVal.setPosition(Vector3DDouble(0.0f,0.0f,0.0f));
		cameraVal.setOrientation(
			Vector3DDouble(0.0f,0.0f,-1.0f), //fwd
			Vector3DDouble(0.0f,1.0f,0.0f), //up
			Vector3DDouble(1.0f,0.0f,0.0f)); //right
		cameraVal.setExtents(1024.0,1024.0,1024.0);

         

        /*cameraVal.setOrientation(
            Vector3DDouble(0.17f,-0.61f,0.77f), //fwd
            Vector3DDouble(-0.43f,0.65f,0.62f), //up
            Vector3DDouble(-0.88f,-0.44f,-0.15f)); //right*/

        //m_fZoom = 1.0f;
    }

        Renderer::~Renderer() throw()
    {
    }

	void Renderer::initialise(void) throw()
	{
	}

        Camera& Renderer::camera() throw()
    {
        return cameraVal;
    }

        const Camera& Renderer::camera() const throw()
    {
        return cameraVal;
    }	

	uint4 Renderer::width(void)
	{
		return m_uWidth;
	}

	uint4 Renderer::height(void)
	{
		return m_uHeight;
	}

    void Renderer::setSize(uint4 uWidth, uint4 uHeight)
	{
		m_uWidth = uWidth;
		m_uHeight = uHeight;
	}
} //namespace Thermite
