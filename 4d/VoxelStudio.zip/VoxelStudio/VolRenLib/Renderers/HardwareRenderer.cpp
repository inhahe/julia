#include "HardwareRenderer.hpp"

namespace Thermite
{
        HardwareRenderer::HardwareRenderer() throw()
    {
    }

        HardwareRenderer::~HardwareRenderer() throw()
    {
    }

	void HardwareRenderer::initialise(void) throw()
	{
		Renderer::initialise();

		GLenum err = glewInit();
		if (GLEW_OK != err)
		{
			/* Problem: glewInit failed, something is seriously wrong. */
			THERMITE_LOG_ERROR << "Error initialising OpenGL Extension Wrangler - " << glewGetErrorString(err);
		}
		else
		{
			THERMITE_LOG_INFO << "OpenGL Extension Wrangler version " << glewGetString(GLEW_VERSION) << " initialised successfully";
		}
	}

	void HardwareRenderer::render()
	{
	}
} //namespace Thermite
