#include<limits>
#include <queue>

#include "Intersection.hpp"

namespace Thermite
{
    template <typename VoxelType>
        IPRenderer<VoxelType>::IPRenderer(Thermite::Volume<VoxelType>* pVolume) throw()
        :VolumeRenderer<SoftwareRenderer, VoxelType >(pVolume)
    {        
		m_dLower = 1500.0;
		m_dUpper = 2000.0;
        m_fBrightness = 1.0f;

        m_rendScanline = new ScanlineRenderer;		

        Polygon< double > vertices;
        vertices.appendVertex(Vector3DDouble(0.0f,0.0f,m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),m_pVolume->depth()));
        m_rendScanline->addPolygon(vertices);

        vertices.clear();
        vertices.appendVertex(Vector3DDouble(0.0f,0.0f,0.0f));
        vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),0.0f));		
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),0.0f));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,0.0f));
        m_rendScanline->addPolygon(vertices);

        vertices.clear();
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,0.0f));		
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),0.0f));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),m_pVolume->depth()));
        m_rendScanline->addPolygon(vertices);

        vertices.clear();
        vertices.appendVertex(Vector3DDouble(0.0f,0.0f,m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),0.0f));
        vertices.appendVertex(Vector3DDouble(0.0f,0.0f,0.0f));		
        m_rendScanline->addPolygon(vertices);

        vertices.clear();
        vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),0.0f));
        vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),0.0f));		
        m_rendScanline->addPolygon(vertices);

        vertices.clear();
        vertices.appendVertex(Vector3DDouble(0.0f,0.0f,0.0f));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,0.0f));		
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(0.0f,0.0f,m_pVolume->depth()));				
        m_rendScanline->addPolygon(vertices);
    }

    template <typename VoxelType>
    IPRenderer<VoxelType>::~IPRenderer() throw()
    {
    }

	template <typename VoxelType>
		double IPRenderer<VoxelType>::level(void)
	{
		return m_dLevel;
	}

	template <typename VoxelType>
		double IPRenderer<VoxelType>::window(void)
	{
		return m_dWindow;
	}

	template <typename VoxelType>
		void IPRenderer<VoxelType>::setLevel(double dLevel)
	{
		m_dLevel = dLevel;

		//Compute the upper and lower bounds.
		m_dUpper = m_dLevel + (m_dWindow / 2.0);
		m_dLower = m_dLevel - (m_dWindow / 2.0);
	}

	template <typename VoxelType>
		void IPRenderer<VoxelType>::setWindow(double dWindow)
	{
		m_dWindow = dWindow;

		//Compute the upper and lower bounds.
		m_dUpper = m_dLevel + (m_dWindow / 2.0);
		m_dLower = m_dLevel - (m_dWindow / 2.0);
	}

    template <typename VoxelType>
    void IPRenderer<VoxelType>::render() throw()
    {
        m_rendScanline->camera() = cameraVal;
		//m_rendScanline->zoom() = m_fZoom;
        m_rendScanline->camera().setPosition(m_rendScanline->camera().position() - (cameraVal.forward()*m_pVolume->diagonal()));
        m_rendScanline->render();

		Octree<VoxelType>& octree = m_pVolume->octree();

        imageVal.clearTo(RGBA<uint1>(0,0,0,0));

        //Camera properties which aren't dependant on image position
		const Vector3DDouble dv3dRightTimesHalfWidth = cameraVal.right() * (cameraVal.width() / 2.0);
		const Vector3DDouble dv3dUpTimesHalfHeight = cameraVal.up() * (cameraVal.height() / 2.0);
		const Vector3DDouble dv3dLowerLeftCorner = cameraVal.position()
			- dv3dRightTimesHalfWidth 
			- dv3dUpTimesHalfHeight 
			- (camera().forward() * camera().depth() / 2.0);

		const double dXStepInCameraSpace = cameraVal.width() / static_cast<double>(imageVal.width());
		const double dYStepInCameraSpace = cameraVal.height() / static_cast<double>(imageVal.height());

		uint4 samplesTaken = 0;

		//For each pixel in the image:
		for(uint4 uImagePosY = 0; uImagePosY < imageVal.height(); ++uImagePosY)
		{        
			for(uint4 uImagePosX = 0; uImagePosX < imageVal.width(); ++uImagePosX)
			{
				//Compute the start position
				double dCameraPosX = dXStepInCameraSpace * static_cast<double>(uImagePosX);
				double dCameraPosY = dYStepInCameraSpace * static_cast<double>(uImagePosY);
				Vector3DDouble rayPosition = dv3dLowerLeftCorner + (cameraVal.right() * dCameraPosX) + (cameraVal.up() * dCameraPosY);
				Vector3DDouble rayDirection = cameraVal.forward();
				rayDirection.normalise();

                /*if(m_rendScanline->depthImage().pixelAt(xPos,yPos) == std::numeric_limits<double>::infinity())
                {
                    continue;
                }
                rayPosition += (rayDirection * m_rendScanline->depthImage().pixelAt(xPos,yPos));*/

                //Skip forward into volume
                for(uint4 ct = 0; ct < 500; ct++)
                {
                    if((rayPosition.x() >= 0.0) && (rayPosition.y() >= 0.0) && (rayPosition.z() >= 0.0) && 
                        (rayPosition.x() < m_pVolume->width()-1.0) && (rayPosition.y() < m_pVolume->height()-1.0) && (rayPosition.z() < m_pVolume->depth()-1.0))
                    {
                        break;
                    }
                    rayPosition += rayDirection;
                }

                //Maybe there was no intersection...
                if((rayPosition.x() < 0.0) || (rayPosition.y() < 0.0) || (rayPosition.z() < 0.0) || 
                    (rayPosition.x() > m_pVolume->width()-1.0) || (rayPosition.y() > m_pVolume->height()-1.0) || (rayPosition.z() > m_pVolume->depth()-1.0))
                {
                    continue;
                }

                double fSampleSum = 0.0f;
				Vector3DDouble startPosition = rayPosition;
				std::queue< std::pair< Vector3DDouble, uint4 > > queueNodesToProcess;
				queueNodesToProcess.push(std::make_pair(rayPosition, 0));
				while(queueNodesToProcess.empty() == false)
				{
					Vector3DDouble position = queueNodesToProcess.front().first;
					uint4 uNodeIndex = queueNodesToProcess.front().second;
					queueNodesToProcess.pop();
					const OctreeNode<VoxelType>& octreeNode = octree.nodeAt(uNodeIndex);

					if((octreeNode.maxVoxelValue() >= m_dLower) && (octreeNode.minVoxelValue() <= m_dUpper))					
					{
						if(octreeNode.isLeaf())
						{
							uint4 noOfSteps = computeNoOfStepsToExitBox<double>(position, rayDirection, octreeNode.minPosition(),octreeNode.maxPosition());
							for(uint4 ct = 0; ct < noOfSteps; ++ct)
							{     
								double fSample = m_pVolume->computeTrilinearlyInterpolatedValueAt(position);
								fSample = applyWindowLevel(fSample); //FIXME - can we apply window level once after ray has finished?
								fSampleSum += fSample;

								samplesTaken++;

								position += rayDirection;
							}
						}
						else
						{
							while(octreeNode.containsPoint(position))
							{
								uint4 childNode = octree.findChildforPoint(uNodeIndex, position);								
								queueNodesToProcess.push(std::make_pair(position,childNode));

								uint4 noOfSteps = computeNoOfStepsToExitBox(position, rayDirection, octree.nodeAt(childNode).minPosition(),octree.nodeAt(childNode).maxPosition());
								position += (rayDirection * static_cast<double>(noOfSteps));
							}							
						}
					}
				}
				uint4 uNoOfSteps = computeNoOfStepsToExitBox<double>(rayPosition, rayDirection, octree.nodeAt(0).minPosition(),octree.nodeAt(0).maxPosition());
				/*rayPosition += (rayDirection * double(noOfSteps));
				
                fSampleSum /= (rayPosition - startPosition).length();*/
				fSampleSum /= static_cast<double>(uNoOfSteps);
                fSampleSum *= m_fBrightness;
				uint1 uSampleSum = fSampleSum * 255;
                imageVal.rawData()[uImagePosY * imageVal.width() + uImagePosX] = RGBA<uint1>(uSampleSum, uSampleSum, uSampleSum,255);
            }
        }

        //THERMITE_LOG_DEBUG << "Finished Frame" << std::endl;
    }

	template <typename VoxelType>
	double IPRenderer<VoxelType>::applyWindowLevel(const double input)
	{
		if(input < m_dLower)
		{
			return 0.0f;
		}
		else if(input > m_dUpper)
		{
			return 1.0f;
		}
		else
		{
			return (input - m_dLower)/(m_dUpper - m_dLower);
		}
	}    	

    template <typename VoxelType>
        void IPRenderer<VoxelType>::setSize(uint4 uWidth, uint4 uHeight)
    {
		VolumeRenderer<SoftwareRenderer, VoxelType>::setSize(uWidth,uHeight);
        m_rendScanline->setSize(uWidth,uHeight);
    }

	template <typename VoxelType>
	void IPRenderer<VoxelType>::setBrightness(double dBrightness)
	{
		m_fBrightness = dBrightness;
	}
}
