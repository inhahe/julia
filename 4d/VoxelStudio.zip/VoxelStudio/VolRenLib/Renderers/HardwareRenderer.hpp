#ifndef HARDWARERENDERER_HEADER_INCLUDED
#define HARDWARERENDERER_HEADER_INCLUDED

#include <windows.h>
#include <gl\glew.h>

#include "..\Base\Typedef.hpp"
#include "Renderer.hpp"

namespace Thermite
{
    class HardwareRenderer : public Renderer
    {
    public:
        HardwareRenderer() throw();
        ~HardwareRenderer() throw();

		void initialise(void) throw();
        void render(void) throw();
    };
} //namespace Thermite

#endif
