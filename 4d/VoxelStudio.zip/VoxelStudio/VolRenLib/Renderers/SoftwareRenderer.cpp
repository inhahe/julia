#include "SoftwareRenderer.hpp"

namespace Thermite
{
        SoftwareRenderer::SoftwareRenderer() throw()
    {
    }

        SoftwareRenderer::~SoftwareRenderer() throw()
    {
    }

	void SoftwareRenderer::initialise(void) throw()
	{
		Renderer::initialise();
	}

	void SoftwareRenderer::render()
	{
	}

	const Image< RGBA<uint1> >& SoftwareRenderer::image() const throw()
    {
        return imageVal;
    }

	void SoftwareRenderer::setSize(uint4 uWidth, uint4 uHeight)
	{
		Renderer::setSize(uWidth,uHeight);
		imageVal.resize(uWidth,uHeight);
	}
} //namespace Thermite
