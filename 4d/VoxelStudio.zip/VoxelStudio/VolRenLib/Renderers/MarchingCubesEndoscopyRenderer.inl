#include <algorithm>
#include <queue>

//#include <boost/timer.hpp>

#include "MarchingCubesTables.hpp"

namespace Thermite
{
    template <typename VoxelType>
        MarchingCubesEndoscopyRenderer<VoxelType>::MarchingCubesEndoscopyRenderer(Thermite::Volume<VoxelType>* pVolume) throw()
        :VolumeRenderer<HardwareRenderer, VoxelType >(pVolume)
    {    
		m_dIsovalue = 200.0;	
		m_rgbaIsosurface.set(255,255,255,255);

		//camera().setPosition(Vector3DDouble(420.0f,255.0f,231.0f));
		//camera().setPosition(Vector3DDouble(140.0f,85.0f,77.0f));
		camera().setPosition(Vector3DDouble(64.0f,64.0f,64.0f));
		camera().setOrientation(
			Vector3DDouble(0.17f,-0.61f,0.77f), //fwd
			Vector3DDouble(-0.43f,0.65f,0.62f), //up
			Vector3DDouble(-0.88f,-0.44f,-0.15f)); //right

		QueryPerformanceFrequency(&m_iTimerFreq);

		//This method requires a LinearVolume
		m_pLinearVolume = dynamic_cast<LinearVolume<VoxelType>*>(m_pVolume);
		if(m_pLinearVolume == 0)
		{
			THERMITE_LOG_ERROR << "MarchingCubesEndoscopyRenderer: Failed to cast Volume* to LinearVolume*";
			return;
		}

		//Initialise texture
		for(uint4 ct = 0; ct < 131072; ct += 4)
		{
			if(ct < 50000)
			{
				uTexture[ct] = 255;
				uTexture[ct+1] = 0;
				uTexture[ct+2] = 0;
				uTexture[ct+3] = 255;

			}
			else if(ct < 80000)
			{
				uTexture[ct] = 0;
				uTexture[ct+1] = 255;
				uTexture[ct+2] = 0;
				uTexture[ct+3] = 255;
			}
			else
			{
				uTexture[ct] = 255;
				uTexture[ct+1] = 0;
				uTexture[ct+2] = 0;
				uTexture[ct+3] = 255;
			}			
		}		
    }

    template <typename VoxelType>
    MarchingCubesEndoscopyRenderer<VoxelType>::~MarchingCubesEndoscopyRenderer() throw()
    {
    }

	template <typename VoxelType>
		const RGBA<uint1>& MarchingCubesEndoscopyRenderer<VoxelType>::isosurfaceColour(void)
	{
		return m_rgbaIsosurface;
	}

	template <typename VoxelType>
		double MarchingCubesEndoscopyRenderer<VoxelType>::isovalue(void)
	{
		return m_dIsovalue;
	}

	template <typename VoxelType>
		void MarchingCubesEndoscopyRenderer<VoxelType>::setIsosurfaceColour(const RGBA<uint1>& rgbaIsosurface)
	{
		m_rgbaIsosurface = rgbaIsosurface;
	}

	template <typename VoxelType>
		void MarchingCubesEndoscopyRenderer<VoxelType>::setIsovalue(double dIsovalue)
	{
		m_dIsovalue = dIsovalue;
	}

	template <typename VoxelType>
	bool MarchingCubesEndoscopyRenderer<VoxelType>::useNiceInterpolation(void)
	{
		return m_bUseNiceInterpolation;
	}

	template <typename VoxelType>
	void MarchingCubesEndoscopyRenderer<VoxelType>::setUseNiceInterpolation(bool bUseNiceInterpolation)
	{
		m_bUseNiceInterpolation = bUseNiceInterpolation;
	}

	template <typename VoxelType>
	void MarchingCubesEndoscopyRenderer<VoxelType>::initialise(void) throw()
	{
		//Call base class
		HardwareRenderer::initialise();

		//Check hardware support
		if(GLEW_VERSION_2_0)
		{
			THERMITE_LOG_INFO << "Found OpenGL 2.0 support.";
		}
		else
		{
			THERMITE_LOG_ERROR << "MarchingCubesEndoscopyRenderer requires OpenGL 2.0 support";
		}

		if(GL_ARB_occlusion_query)
		{
			THERMITE_LOG_INFO << "Found occlusion support.";
		}
		else
		{
			THERMITE_LOG_ERROR << "MarchingCubesEndoscopyRenderer requires occlusion support";
		}

		//Build the vertex buffers
		glGenBuffers(1,&m_uVertexBuffer);
		for(uint4 ct = 0; ct < 256; ++ct)
		{
			m_uNoOfArrayElementsForCell[ct] = 0;
			for(uint4 temp = 0; temp < 45; temp++)
			{
				m_fVertices[ct * 45 + temp] = 0.0;
				m_fNormals[ct * 45 + temp] = 0.0;
			}
			renderTrianglesForCellIndexIntoArrays(ct);			
		}
		glBindBuffer(GL_ARRAY_BUFFER, m_uVertexBuffer);
		glBufferData(GL_ARRAY_BUFFER, 45 * 256 * 2 * sizeof(m_fVertices[0]), 0, GL_STATIC_DRAW);
		//glBufferSubData(GL_ARRAY_BUFFER,0,45 * 256 * sizeof(m_fVertices[0]),m_fVertices);
		uint4 iBuffer = 0;
		for(uint4 iArray = 0; iArray < (256*45); iArray += 3)
		{
			glBufferSubData(GL_ARRAY_BUFFER,iBuffer * sizeof(m_fVertices[0]),3 * sizeof(m_fVertices[0]),m_fVertices + iArray); iBuffer += 3;
			glBufferSubData(GL_ARRAY_BUFFER,iBuffer * sizeof(m_fNormals[0]),3 * sizeof(m_fNormals[0]),m_fNormals + iArray); iBuffer += 3;
		}

		glGenOcclusionQueriesNV(1, &m_uQuery);
		glGenOcclusionQueriesNV(100, m_uQueries);

		glBindBuffer(GL_ARRAY_BUFFER, m_uVertexBuffer);
		glVertexPointer(3, GL_FLOAT, 6 * sizeof(m_fVertices[0]), 0);
		glNormalPointer(GL_FLOAT, 6 * sizeof(m_fVertices[0]), (GLvoid*)12);

		//Shaders
		uVertexShader = glCreateShader(GL_VERTEX_SHADER );
		uFragmentShader = glCreateShader(GL_FRAGMENT_SHADER );
	}

    template <typename VoxelType>
    void MarchingCubesEndoscopyRenderer<VoxelType>::render() throw()
    {
		THERMITE_LOG_DEBUG << "pos = " << camera().position();
		CheckTimer(m_iTimerFreq);

		glEnableClientState(GL_NORMAL_ARRAY);
		glEnableClientState(GL_VERTEX_ARRAY);

		//boost::timer timerFrame;
		//timerFrame.restart();
		
		glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
		glLoadIdentity();							// Reset The Projection Matrix

		// Calculate The Aspect Ratio Of The Window
		double dHalfWidth = camera().width()/2.0;
		double dHalfHeight = camera().height()/2.0;
		//glOrtho(-dHalfWidth, dHalfWidth,-dHalfHeight, dHalfHeight,1.0,1024.0);
		//glTranslated(0.0,0.0,-500.0);
		gluPerspective(60.0,1.0,0.1,10000.0);
		
		//glRotated(45.0,0.7,0.2,0.5);
		Vector3DDouble v3dTarget = camera().position() + camera().forward();

		glMatrixMode(GL_MODELVIEW);						// Select The Modelview Matrix
		glLoadIdentity();	

		

		gluLookAt(camera().position().x(),camera().position().y(),camera().position().z(),
			v3dTarget.x(),v3dTarget.y(),v3dTarget.z(),
			camera().up().x(),camera().up().y(),camera().up().z());	

		/*LightPosition[0] = camera().forward().x();
		LightPosition[1] = camera().forward().y();
		LightPosition[2] = camera().forward().z();
		LightPosition[3] = 0.0f;*/

		//Light 1
		GLfloat Light1Ambient[]= { 0.2f, 0.2f, 0.2f, 0.0f };
		GLfloat Light1Diffuse[]= { 0.8f, 0.8f, 0.8f, 0.0f };
		GLfloat Light1Position[]= { 64.0f, 64.0f, 64.0f, 1.0f };	
		glLightfv(GL_LIGHT1, GL_AMBIENT, Light1Ambient);	
		glLightfv(GL_LIGHT1, GL_DIFFUSE, Light1Diffuse);
		glLightfv(GL_LIGHT1, GL_POSITION,Light1Position);
		glLightf(GL_LIGHT1, GL_CONSTANT_ATTENUATION, 0.0f);
		glLightf(GL_LIGHT1, GL_LINEAR_ATTENUATION, 0.0f);
		glLightf(GL_LIGHT1, GL_QUADRATIC_ATTENUATION, 0.0002f);
		glEnable(GL_LIGHT1);

		//Light 2
		GLfloat Light2Ambient[]= { 0.2f, 0.2f, 0.2f, 0.0f };
		GLfloat Light2Diffuse[]= { 0.8f, 0.8f, 0.8f, 0.0f };
		GLfloat Light2Position[]= { 64.0f, 192.0f, 192.0f, 1.0f };	
		glLightfv(GL_LIGHT2, GL_AMBIENT, Light2Ambient);	
		glLightfv(GL_LIGHT2, GL_DIFFUSE, Light2Diffuse);
		glLightfv(GL_LIGHT2, GL_POSITION,Light2Position);
		glLightf(GL_LIGHT2, GL_CONSTANT_ATTENUATION, 0.0f);
		glLightf(GL_LIGHT2, GL_LINEAR_ATTENUATION, 0.0f);
		glLightf(GL_LIGHT2, GL_QUADRATIC_ATTENUATION, 0.0002f);
		glEnable(GL_LIGHT2);

		//Light 3
		GLfloat Light3Ambient[]= { 0.2f, 0.2f, 0.2f, 0.0f };
		GLfloat Light3Diffuse[]= { 0.8f, 0.8f, 0.8f, 0.0f };
		GLfloat Light3Position[]= { 192.0f, 192.0f, 64.0f, 1.0f };	
		glLightfv(GL_LIGHT3, GL_AMBIENT, Light3Ambient);	
		glLightfv(GL_LIGHT3, GL_DIFFUSE, Light3Diffuse);
		glLightfv(GL_LIGHT3, GL_POSITION,Light3Position);
		glLightf(GL_LIGHT3, GL_CONSTANT_ATTENUATION, 0.0f);
		glLightf(GL_LIGHT3, GL_LINEAR_ATTENUATION, 0.0f);
		glLightf(GL_LIGHT3, GL_QUADRATIC_ATTENUATION, 0.0002f);
		glEnable(GL_LIGHT3);

		//Light 4
		GLfloat Light4Ambient[]= { 0.2f, 0.2f, 0.2f, 0.0f };
		GLfloat Light4Diffuse[]= { 0.8f, 0.8f, 0.8f, 0.0f };
		GLfloat Light4Position[]= { 192.0f, 64.0f, 192.0f, 1.0f };	
		glLightfv(GL_LIGHT4, GL_AMBIENT, Light4Ambient);	
		glLightfv(GL_LIGHT4, GL_DIFFUSE, Light4Diffuse);
		glLightfv(GL_LIGHT4, GL_POSITION,Light4Position);
		glLightf(GL_LIGHT4, GL_CONSTANT_ATTENUATION, 0.0f);
		glLightf(GL_LIGHT4, GL_LINEAR_ATTENUATION, 0.0f);
		glLightf(GL_LIGHT4, GL_QUADRATIC_ATTENUATION, 0.0002f);
		glEnable(GL_LIGHT4);


		glEnable(GL_LIGHTING);



		glShadeModel(GL_SMOOTH);
		

		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		glEnable(GL_DEPTH_TEST);

		glEnable(GL_NORMALIZE);

		glEnable(GL_COLOR_MATERIAL);

		//Texturing
		/*glTexImage3D(GL_TEXTURE_3D,0,4,32,32,32,0,GL_RGBA,GL_FLOAT,fTexture);
		glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glEnable(GL_TEXTURE_3D);*/
		

		//glTexImage2D(GL_TEXTURE_2D, 0, 3, 128, 128, 0, GL_RGB, GL_UNSIGNED_BYTE, uTexture);
		glTexImage3D(GL_TEXTURE_3D, 0, 4, 32, 32, 32, 0, GL_RGBA, GL_UNSIGNED_BYTE, uTexture);

		glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
		glEnable(GL_TEXTURE_3D);
		

		THERMITE_LOG_DEBUG << "Color is " << m_rgbaIsosurface;
		glColor3ub(m_rgbaIsosurface.red(),m_rgbaIsosurface.green(),m_rgbaIsosurface.blue());

		/*if(m_bUseNiceInterpolation)
		{
			renderLinearInterpolation();
		}
		else
		{*/
			//renderNearestInterpolation();
		/*}*/

		m_uNoOfTrianglesRendered = 0;
		m_uNoOfOcclusionTests = 0;
		renderScene();

		/*OctreeNode<VoxelType> dummyNode;
		dummyNode.minPosition() = Vector3DDouble(-500.0f,-500.0f,-500.0f);
		dummyNode.maxPosition() = Vector3DDouble(500.0f,500.0f,500.0f);

		renderOctreeNodeAsBox(dummyNode);*/

		GLenum error = glGetError();
		while(error != GL_NO_ERROR)
		{			
			const GLubyte* errorString = gluErrorString(error);
			THERMITE_LOG_DEBUG << "Error Status was: " << errorString;
			error = glGetError();
		}

		THERMITE_LOG_DEBUG << "Rendered " <<  m_uNoOfTrianglesRendered << " triangles";
	}

	template <typename VoxelType>
		void MarchingCubesEndoscopyRenderer<VoxelType>::renderScene(void) throw()
	{
		CheckTimer(m_iTimerFreq);
		identifyNodesInFrustrum();

		THERMITE_LOG_DEBUG << "identifyNodesInFrustrum() did " << m_uNoOfOcclusionTests << " occlusion tests and took " << CheckTimer(m_iTimerFreq) << " seconds";

		sort(vecNodesInFrustum.begin(),vecNodesInFrustum.end());

		THERMITE_LOG_DEBUG << "Sorting " << vecNodesInFrustum.size() << " nodes took " << CheckTimer(m_iTimerFreq) << " seconds";

		m_uNoOfOcclusionTests = 0;

		OctreeNode<VoxelType> dummyNode;
		dummyNode.minPosition() = Vector3DDouble(-2000.0f,-2000.0f,-2000.0f);
		dummyNode.maxPosition() = Vector3DDouble(2000.0f,2000.0f,2000.0f);

		//THERMITE_LOG_DEBUG << "Entering loop";
		//while(!queueNodesInFrustum.empty())
		for(uint4 ct = 0; ct < vecNodesInFrustum.size(); ct++)
		{
			//THERMITE_LOG_DEBUG << ct;
			//THERMITE_LOG_DEBUG << "Got " << vecNodesToRender[ct];
			//THERMITE_LOG_DEBUG << "ct = " << ct << ", Rendered " << m_uNoOfCellsRendered << " cubes and " << m_uNoOfTrianglesRendered << " triangles";
			
			//const uint4 uNodeCurrent = queueNodesInFrustum.top().second;
			//queueNodesInFrustum.pop();

			const uint4 uNodeCurrent = vecNodesInFrustum[ct].second;

			//THERMITE_LOG_DEBUG << uNodeCurrent;

			const OctreeNode<VoxelType>& nodeCurrent = m_pLinearVolume->octree().nodeAt(uNodeCurrent);	

			if(ct % 10 == 0)
			{
				m_uNoOfOcclusionTests++;
				if(!isOctreeNodeVisible(dummyNode))
				{
					break;
				}
			}			

			

			//renderOctreeNodeAsBox(dummyNode);
			renderOctreeNode(uNodeCurrent);
		}
		THERMITE_LOG_DEBUG << "Rendering Nodes did " << m_uNoOfOcclusionTests << " occlusion tests and took " << CheckTimer(m_iTimerFreq) << " seconds";
	}

	template <typename VoxelType>
		void MarchingCubesEndoscopyRenderer<VoxelType>::identifyNodesInFrustrum() throw()
	{
		vecNodesInFrustum.clear();
		vecNodesInFrustum.reserve(10000);
		std::queue<uint4> vecNodesToProcess;
		std::vector<uint4> vecNodesToQuery;

		vecNodesToProcess.push(1);
		vecNodesToProcess.push(2);
		vecNodesToProcess.push(3);
		vecNodesToProcess.push(4);
		vecNodesToProcess.push(5);
		vecNodesToProcess.push(6);
		vecNodesToProcess.push(7);
		vecNodesToProcess.push(8);

		while(!vecNodesToProcess.empty())
		{
			//THERMITE_LOG_DEBUG << "Outer while - vecNodesToProcess.size() = " << vecNodesToProcess.size();
			vecNodesToQuery.clear();
			while(!vecNodesToProcess.empty())
			{
				//THERMITE_LOG_DEBUG << "Inner while - vecNodesToProcess.size() = " << vecNodesToProcess.size();
				const uint4 uCurrentNode = vecNodesToProcess.front();
				vecNodesToProcess.pop();
				const OctreeNode<VoxelType>& nodeCurrent = m_pLinearVolume->octree().nodeAt(uCurrentNode);

				/*glColor3f(1.0,0.0,0.0);
				glPolygonMode(GL_FRONT, GL_LINE);
				glPolygonMode(GL_BACK, GL_LINE);*/
				
				//Test if it contains an isosurface
				if((nodeCurrent.maxVoxelValue() < m_dIsovalue) || (nodeCurrent.minVoxelValue() > m_dIsovalue))
				{
					continue;
				}

				vecNodesToQuery.push_back(uCurrentNode);
			}

			glDepthMask(GL_FALSE);
			glColorMask(GL_FALSE,GL_FALSE,GL_FALSE,GL_FALSE);
			//THERMITE_LOG_DEBUG << "Total number to query = " << vecNodesToQuery.size();
			for(uint4 blockCt = 0; blockCt < vecNodesToQuery.size(); blockCt++)
			{
				//THERMITE_LOG_DEBUG << "Start: blockCt = " << blockCt << ", vecNodesToQuery.size() = " << vecNodesToQuery.size();
				for(uint4 innerCt = 0; innerCt < 100; innerCt++)
				{
					uint4 index = blockCt * 100 + innerCt;					
					if(index < vecNodesToQuery.size())
					{
						m_uNoOfOcclusionTests++;
						//THERMITE_LOG_DEBUG << "Querying node index " << vecNodesToQuery[index];
						const OctreeNode<VoxelType>& nodeToQuery = m_pLinearVolume->octree().nodeAt(vecNodesToQuery[index]);
						glBeginQueryARB(GL_SAMPLES_PASSED_ARB, m_uQueries[innerCt]);
						renderOctreeNodeAsBox(nodeToQuery);
						glEndQueryARB(GL_SAMPLES_PASSED_ARB);
					}
					/*else
					{
						THERMITE_LOG_DEBUG << "Out of bounds";
					}*/
				}

				for(uint4 innerCt = 0; innerCt < 100; innerCt++)
				{
					uint4 index = blockCt * 100 + innerCt;
					if(index < vecNodesToQuery.size())
					{
						GLuint pixelCount;
						glGetQueryObjectuivARB(m_uQueries[innerCt], GL_QUERY_RESULT_ARB, &pixelCount);
						if(pixelCount != 0)
						{
							//THERMITE_LOG_DEBUG << "Node index " << vecNodesToQuery[index] << " visible";
							const OctreeNode<VoxelType>& nodeToAdd = m_pLinearVolume->octree().nodeAt(vecNodesToQuery[index]);
							if((nodeToAdd.isLeaf() == false) && (nodeToAdd.depth() < 4))
							{								
								uint4 uBase = 8 * vecNodesToQuery[index];
								//THERMITE_LOG_DEBUG << "Adding nodes " << uBase + 1 << " to " << uBase + 8;

								vecNodesToProcess.push(uBase + 1);
								vecNodesToProcess.push(uBase + 2);
								vecNodesToProcess.push(uBase + 3);
								vecNodesToProcess.push(uBase + 4);
								vecNodesToProcess.push(uBase + 5);
								vecNodesToProcess.push(uBase + 6);
								vecNodesToProcess.push(uBase + 7);
								vecNodesToProcess.push(uBase + 8);
							}
							else
							{
								//THERMITE_LOG_DEBUG << "Node " << vecNodesToQuery[index] << " is final";
								Vector3DDouble v3dNodeCentre = (nodeToAdd.minPosition() + nodeToAdd.maxPosition()) / 2.0;
								Vector3DDouble v3dDifference = camera().position() - v3dNodeCentre;
								double dDistanceSquared = v3dDifference.x() * v3dDifference.x() + v3dDifference.y() * v3dDifference.y() + v3dDifference.z() * v3dDifference.z();
								//vecNodesInFrustum.push_back(std::make_pair((std::numeric_limits<uint4>::max)() - static_cast<uint4>(dDistanceSquared), uCurrentNode));
								vecNodesInFrustum.push_back(std::make_pair(static_cast<uint4>(dDistanceSquared), vecNodesToQuery[index]));
							}
						}
						/*else
						{
							THERMITE_LOG_DEBUG << "Node index " << vecNodesToQuery[index] << " hidden";
						}*/
					}
				}
				//THERMITE_LOG_DEBUG << "End: blockCt = " << blockCt << ", vecNodesToQuery.size() = " << vecNodesToQuery.size();
			}
			glDepthMask(GL_TRUE);
			glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
	
		}
	}

	template <typename VoxelType>
		void MarchingCubesEndoscopyRenderer<VoxelType>::renderOctreeNode(uint4 uNodeToRender) throw()
	{
		std::queue<uint4> vecNodesToProcess;		
		glMatrixMode(GL_MODELVIEW);	

		glBindBuffer(GL_ARRAY_BUFFER, m_uVertexBuffer);
		glVertexPointer(3, GL_FLOAT, 6 * sizeof(m_fVertices[0]), 0);
		glNormalPointer(GL_FLOAT, 6 * sizeof(m_fVertices[0]), (GLvoid*)12);		

		vecNodesToProcess.push(uNodeToRender);
		while(!vecNodesToProcess.empty())
		{
			const uint4 uCurrentNode = vecNodesToProcess.front();
			vecNodesToProcess.pop();

			const OctreeNode<VoxelType>& nodeCurrent = m_pLinearVolume->octree().nodeAt(uCurrentNode);

			//If it's invisible, don't render it
			m_uNoOfOcclusionTests++;
			if(!isOctreeNodeVisible(nodeCurrent))
			{
				continue;
			}

			if(nodeCurrent.isLeaf() == false)
			{
				uint4 uBase = 8 * uCurrentNode;

				vecNodesToProcess.push(uBase + 1);
				vecNodesToProcess.push(uBase + 2);
				vecNodesToProcess.push(uBase + 3);
				vecNodesToProcess.push(uBase + 4);
				vecNodesToProcess.push(uBase + 5);
				vecNodesToProcess.push(uBase + 6);
				vecNodesToProcess.push(uBase + 7);
				vecNodesToProcess.push(uBase + 8);
			}
			else
			{
				//uStart is the first voxel of the first cell
				uint4 uStartX = nodeCurrent.minPosition().x();
				uint4 uStartY = nodeCurrent.minPosition().y();
				uint4 uStartZ = nodeCurrent.minPosition().z();

				//uEnd is the last voxel of the last cell
				uint4 uEndX = nodeCurrent.maxPosition().x();
				uint4 uEndY = nodeCurrent.maxPosition().y();
				uint4 uEndZ = nodeCurrent.maxPosition().z();			

				uStartX = (std::max)(uint4(0),uStartX);
				uStartY = (std::max)(uint4(0),uStartY);
				uStartZ = (std::max)(uint4(0),uStartZ);

				uEndX = (std::min)(m_pLinearVolume->width()-1, uEndX);
				uEndY = (std::min)(m_pLinearVolume->height()-1, uEndY);
				uEndZ = (std::min)(m_pLinearVolume->depth()-1, uEndZ);

				//THERMITE_LOG_DEBUG << "Rendering Node: Start = " << Vector3DUint4(uStartX,uStartY,uStartZ) << ", End = " << Vector3DUint4(uEndX,uEndY,uEndZ)  << "Address = " << &(pLinearVolume->octree());
				//THERMITE_LOG_DEBUG << "is leaf = " << nodeCurrent.isLeaf();

				int iCubeIndex;
				Vector3DDouble vertlist[12];

				const uint4 uWidth = m_pLinearVolume->width();
				const uint4 uWidthTimesHeight = m_pLinearVolume->width() * m_pLinearVolume->height();	



				for(uint4 z = uStartZ; z < uEndZ; ++z)
				{
					for(uint4 y = uStartY; y < uEndY; ++y)
					{			
						const VoxelType* v000 = &(m_pLinearVolume->voxelAt(Vector3DUint4(uStartX,y,z)));
						for(uint4 x = uStartX; x < uEndX; ++x, ++v000)
						{						
							const VoxelType* v100 = v000 + 1;
							const VoxelType* v010 = v000 + uWidth;
							const VoxelType* v110 = v010 + 1;
							const VoxelType* v001 = v000 + uWidthTimesHeight;
							const VoxelType* v101 = v001 + 1;
							const VoxelType* v011 = v001 + uWidth;
							const VoxelType* v111 = v011 + 1;

							/*
							Determine the index into the edge table which
							tells us which vertices are inside of the surface
							*/
							iCubeIndex = 0;
							if (*v000 < m_dIsovalue) iCubeIndex |= 1;
							if (*v100 < m_dIsovalue) iCubeIndex |= 2;
							if (*v110 < m_dIsovalue) iCubeIndex |= 4;
							if (*v010 < m_dIsovalue) iCubeIndex |= 8;
							if (*v001 < m_dIsovalue) iCubeIndex |= 16;
							if (*v101 < m_dIsovalue) iCubeIndex |= 32;
							if (*v111 < m_dIsovalue) iCubeIndex |= 64;
							if (*v011 < m_dIsovalue) iCubeIndex |= 128;

							/* Cube is entirely in/out of the surface */
							if ((edgeTable[iCubeIndex] == 0))
							{
								continue;
							}


							//glLoadIdentity();
							/*glPushMatrix();
							glTranslatef(x,y,z);
							glDrawArrays(GL_TRIANGLES, iCubeIndex * 15, m_uNoOfArrayElementsForCell[iCubeIndex]/3);
							glPopMatrix();*/

							m_uNoOfTrianglesRendered += m_uNoOfArrayElementsForCell[iCubeIndex]/9;

							glPushMatrix();
							glTranslatef(x,y,z);
							glBegin(GL_TRIANGLES);
							uint4 ct = 0;
							while(ct < m_uNoOfArrayElementsForCell[iCubeIndex])
							{
								//if((m_fNormals[iCubeIndex * 45 + ct]* camera().forward().x() + m_fNormals[iCubeIndex * 45 + ct+1]* camera().forward().y() + m_fNormals[iCubeIndex * 45 + ct+2]* camera().forward().z()) > 0.0)
								{
									glNormal3f(m_fNormals[iCubeIndex * 45 + ct],m_fNormals[iCubeIndex * 45 + ct+1],m_fNormals[iCubeIndex * 45 + ct+2]);

									glTexCoord3f(m_fVertices[iCubeIndex * 45 + ct],m_fVertices[iCubeIndex * 45 + ct+1],m_fVertices[iCubeIndex * 45 + ct+2]);
									glVertex3f(m_fVertices[iCubeIndex * 45 + ct],m_fVertices[iCubeIndex * 45 + ct+1],m_fVertices[iCubeIndex * 45 + ct+2]);
									ct+= 3;
									glTexCoord3f(m_fVertices[iCubeIndex * 45 + ct],m_fVertices[iCubeIndex * 45 + ct+1],m_fVertices[iCubeIndex * 45 + ct+2]);
									glVertex3f(m_fVertices[iCubeIndex * 45 + ct],m_fVertices[iCubeIndex * 45 + ct+1],m_fVertices[iCubeIndex * 45 + ct+2]);
									ct+= 3;
									glTexCoord3f(m_fVertices[iCubeIndex * 45 + ct],m_fVertices[iCubeIndex * 45 + ct+1],m_fVertices[iCubeIndex * 45 + ct+2]);
									glVertex3f(m_fVertices[iCubeIndex * 45 + ct],m_fVertices[iCubeIndex * 45 + ct+1],m_fVertices[iCubeIndex * 45 + ct+2]);
									ct+= 3;
								}
								//else
								//{
									//ct += 9;
								//}
							}
							glEnd();
							glPopMatrix();
						}
					}
				}
			}
		}		
	}

	template <typename VoxelType>
	void MarchingCubesEndoscopyRenderer<VoxelType>::renderOctreeNodeAsBox(const OctreeNode<VoxelType>& nodeToRender)
	{
		const Vector3DFloat v3dMin = static_cast<Vector3DFloat>(nodeToRender.minPosition());
		const Vector3DFloat v3dMax = static_cast<Vector3DFloat>(nodeToRender.maxPosition());

		const Vector3DFloat v3dDiff = v3dMax - v3dMin;

		//glLoadIdentity();

		glPushMatrix();

		glTranslatef(v3dMin.x(),v3dMin.y(),v3dMin.z());
		glScalef(v3dDiff.x(),v3dDiff.y(),v3dDiff.z());
		

		//Cube sides face outwards by counter-clockwise
		glBegin(GL_QUADS);

		glVertex3f(0.0f,0.0f,1.0f);
		glVertex3f(1.0f,0.0f,1.0f);
		glVertex3f(1.0f,1.0f,1.0f);
		glVertex3f(0.0f,1.0f,1.0f);

		glVertex3f(0.0f,1.0f,0.0f);
		glVertex3f(1.0f,1.0f,0.0f);
		glVertex3f(1.0f,0.0f,0.0f);
		glVertex3f(0.0f,0.0f,0.0f);

		glVertex3f(1.0f,0.0f,1.0f);
		glVertex3f(1.0f,0.0f,0.0f);
		glVertex3f(1.0f,1.0f,0.0f);
		glVertex3f(1.0f,1.0f,1.0f);

		glVertex3f(0.0f,1.0f,1.0f);
		glVertex3f(0.0f,1.0f,0.0f);
		glVertex3f(0.0f,0.0f,0.0f);
		glVertex3f(0.0f,0.0f,1.0f);

		glVertex3f(0.0f,1.0f,1.0f);
		glVertex3f(1.0f,1.0f,1.0f);
		glVertex3f(1.0f,1.0f,0.0f);
		glVertex3f(0.0f,1.0f,0.0f);

		glVertex3f(0.0f,0.0f,0.0f);
		glVertex3f(1.0f,0.0f,0.0f);
		glVertex3f(1.0f,0.0f,1.0f);
		glVertex3f(0.0f,0.0f,1.0f);

		glEnd();

		glPopMatrix();
	}

	template <typename VoxelType>
		bool MarchingCubesEndoscopyRenderer<VoxelType>::isOctreeNodeVisible(const OctreeNode<VoxelType>& nodeToTest)
	{
		glDepthMask(GL_FALSE);
		glColorMask(GL_FALSE,GL_FALSE,GL_FALSE,GL_FALSE);

		glBeginQueryARB(GL_SAMPLES_PASSED_ARB, m_uQuery);
		renderOctreeNodeAsBox(nodeToTest);
		glEndQueryARB(GL_SAMPLES_PASSED_ARB);

		GLuint pixelCount;
		glGetQueryObjectuivARB(m_uQuery, GL_QUERY_RESULT_ARB, &pixelCount);

		glDepthMask(GL_TRUE);
		glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);

		return (pixelCount > 0);
	}

	template <typename VoxelType>
		void MarchingCubesEndoscopyRenderer<VoxelType>::renderTrianglesForCellIndexIntoArrays(uint1 uCellIndex)
	{
		//const uint4 uStart = uCellIndex * 45;

		Vector3DDouble vertlist[12];

		/* Cube is entirely in/out of the surface */
		if (edgeTable[uCellIndex] == 0)
		{
			return;
		}

		/* Find the vertices where the surface intersects the cube */
		if (edgeTable[uCellIndex] & 1)
		{
			vertlist[0].setX(0.5);
			vertlist[0].setY(0.0);
			vertlist[0].setZ(0.0);
		}
		if (edgeTable[uCellIndex] & 2)
		{
			vertlist[1].setX(1.0);
			vertlist[1].setY(0.5);
			vertlist[1].setZ(0.0);
		}
		if (edgeTable[uCellIndex] & 4)
		{
			vertlist[2].setX(0.5);
			vertlist[2].setY(1.0);
			vertlist[2].setZ(0.0);
		}
		if (edgeTable[uCellIndex] & 8)
		{
			vertlist[3].setX(0.0);
			vertlist[3].setY(0.5);
			vertlist[3].setZ(0.0);
		}
		if (edgeTable[uCellIndex] & 16)
		{
			vertlist[4].setX(0.5);
			vertlist[4].setY(0.0);
			vertlist[4].setZ(1.0);
		}
		if (edgeTable[uCellIndex] & 32)
		{
			vertlist[5].setX(1.0);
			vertlist[5].setY(0.5);
			vertlist[5].setZ(1.0);
		}
		if (edgeTable[uCellIndex] & 64)
		{
			vertlist[6].setX(0.5);
			vertlist[6].setY(1.0);
			vertlist[6].setZ(1.0);
		}
		if (edgeTable[uCellIndex] & 128)
		{
			vertlist[7].setX(0.0);
			vertlist[7].setY(0.5);
			vertlist[7].setZ(1.0);
		}
		if (edgeTable[uCellIndex] & 256)
		{
			vertlist[8].setX(0.0);
			vertlist[8].setY(0.0);
			vertlist[8].setZ(0.5);
		}
		if (edgeTable[uCellIndex] & 512)
		{
			vertlist[9].setX(1.0);
			vertlist[9].setY(0.0);
			vertlist[9].setZ(0.5);
		}
		if (edgeTable[uCellIndex] & 1024)
		{
			vertlist[10].setX(1.0);
			vertlist[10].setY(1.0);
			vertlist[10].setZ(0.5);
		}
		if (edgeTable[uCellIndex] & 2048)
		{
			vertlist[11].setX(0.0);
			vertlist[11].setY(1.0);
			vertlist[11].setZ(0.5);
		}


		//glBegin(GL_TRIANGLES);
		uint4 uNormalIndex = 0;
		uint4 uVertexIndex = 0;
		for (int i=0;triTable[uCellIndex][i]!=-1;i+=3)
		{
			Vector3DDouble v0 = vertlist[triTable[uCellIndex][i  ]];
			Vector3DDouble v1 = vertlist[triTable[uCellIndex][i+1]];
			Vector3DDouble v2 = vertlist[triTable[uCellIndex][i+2]];
			Vector3DDouble normal = (v1 - v0).cross(v1 - v2);

			/*glNormal3f(normal.x(),normal.y(),normal.z());
			glVertex3f(v0.x(),v0.y(),v0.z());
			glVertex3f(v1.x(),v1.y(),v1.z());
			glVertex3f(v2.x(),v2.y(),v2.z());*/


			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.x(); uNormalIndex++;
			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.y(); uNormalIndex++;
			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.z(); uNormalIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v0.x(); uVertexIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v0.y(); uVertexIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v0.z(); uVertexIndex++;

			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.x(); uNormalIndex++;
			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.y(); uNormalIndex++;
			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.z(); uNormalIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v1.x(); uVertexIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v1.y(); uVertexIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v1.z(); uVertexIndex++;

			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.x(); uNormalIndex++;
			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.y(); uNormalIndex++;
			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.z(); uNormalIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v2.x(); uVertexIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v2.y(); uVertexIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v2.z(); uVertexIndex++;

			m_uNoOfArrayElementsForCell[uCellIndex] += 9;
		}
		//glEnd();
	}

	template <typename VoxelType>
	Vector3DDouble MarchingCubesEndoscopyRenderer<VoxelType>::getObjectSpacePosition(uint4 x, uint4 y)
	{
		//Get the depth at the specified position.
		GLfloat fDepth;
		glReadPixels(x,y,1,1,GL_DEPTH_COMPONENT,GL_FLOAT,&fDepth);

		GLdouble dObjX,dObjY,dObjZ;
		GLdouble dModelviewMatrix[16];
		GLdouble dProjectionMatrix[16];
		GLint iViewport[4];
		glGetDoublev(GL_MODELVIEW_MATRIX,dModelviewMatrix);
		glGetDoublev(GL_PROJECTION_MATRIX,dProjectionMatrix);
		glGetIntegerv(GL_VIEWPORT, iViewport);
		gluUnProject(x,y,fDepth,dModelviewMatrix,dProjectionMatrix,iViewport,&dObjX,&dObjY,&dObjZ);

		return Vector3DDouble(dObjX,dObjY,dObjZ);
	}
}
