#ifndef IPRENDERER_HEADER_INCLUDED
#define IPRENDERER_HEADER_INCLUDED

#include <list>
#include <vector>

#include "ScanlineRenderer.hpp"
#include "VolumeRenderer.hpp"
#include "..\Images\RGBA.hpp"
#include "..\Base\Typedef.hpp"

namespace Thermite
{
    template <typename VoxelType>
    class  IPRenderer : public VolumeRenderer<SoftwareRenderer, VoxelType>
    {
    public:
        IPRenderer(Thermite::Volume<VoxelType>* pVolume) throw();
        virtual ~IPRenderer() throw();

		double level(void);
		double window(void);		

		void setLevel(double dLevel);
		void setWindow(double dWindow);	

        virtual void render(void) throw();
        void setSize(uint4 uWidth, uint4 uHeight);

		void setBrightness(double dBrightness);
    private:
		double applyWindowLevel(const double input);   

		double m_dLevel;
		double m_dLower;
		double m_dUpper;
		double m_dWindow;

        double m_fBrightness;
        ScanlineRenderer* m_rendScanline;
    };
}

#include "IPRenderer.inl"

#endif
