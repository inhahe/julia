#ifndef MARCHING_CUBES_RENDERER_HEADER_INCLUDED
#define MARCHING_CUBES_RENDERER_HEADER_INCLUDED

#include <list>
#include <vector>

#include "VolumeRenderer.hpp"
#include "..\Base\Typedef.hpp"

//FIXME - enforce constraint that this only works on linear volume? Or generalize?
namespace Thermite
{
    template <typename VoxelType>
    class  MarchingCubesRenderer : public VolumeRenderer<HardwareRenderer, VoxelType>
    {
    public:
        MarchingCubesRenderer(Thermite::Volume<VoxelType>* pVolume) throw();
        virtual ~MarchingCubesRenderer() throw();

		const RGBA<uint1>& isosurfaceColour(void);
		double isovalue(void);
		bool useNiceInterpolation(void);

		void setIsosurfaceColour(const RGBA<uint1>& rgbaIsosurface);
		void setIsovalue(double dIsovalue);
		void setUseNiceInterpolation(bool bUseNiceInterpolation);

		void initialise(void) throw();
        virtual void render(void) throw();

    private:  		
		void renderLinearInterpolation(void) throw();
		void renderNearestInterpolation(void) throw();
		void renderTrianglesForCellIndexIntoArrays(uint1 uCellIndex);
		void renderOctreeNodeAsBox(const OctreeNode<VoxelType>& nodeToRender);
		double linearInterpolation(double v1, double v2);

		uint4 m_vecNodesToProcess[1000000];		

		GLfloat m_fVertices[11520]; //256*45
		GLfloat m_fNormals[11520]; //256*45

		uint4 m_uNoOfArrayElementsForCell[256];

		GLuint m_uVertexBuffer;
		GLuint m_uNormalBuffer;

		double m_dIsovalue;
		RGBA<uint1> m_rgbaIsosurface;

		bool m_bUseNiceInterpolation;
    };
}

#include "MarchingCubesRenderer.inl"

#endif
