#define CELL_OCCUPIED_FLAG 0x8000
#define NEAR_EDGE_FLAG 0x4000
#define GRADIENT_CACHED_FOR_CELL_FLAG 0x2000
#define GRADIENT_CACHED_FLAG 0x1000

#include <queue>

#include "RenderingMisc.hpp"

namespace Thermite
{
    template <typename VoxelType>
	EndoscopyRenderer<VoxelType>::EndoscopyRenderer(Thermite::Volume<uint2>* pVolume,double threshold) throw()
	: VolumeRenderer<SoftwareRenderer, VoxelType >(pVolume)
	,m_fThreshold(threshold)
	{
			useSobel = false;
			m_bUsingGradientCache = false;

			//camera().setPosition(Vector3DDouble(420.0f,255.0f,231.0f));
			camera().setPosition(Vector3DDouble(95.0f,283.0f,290.0f));
			//camera().setPosition(Vector3DDouble(140.0f,85.0f,77.0f));
			camera().setOrientation(
				Vector3DDouble(0.17f,-0.61f,0.77f), //fwd
				Vector3DDouble(-0.43f,0.65f,0.62f), //up
				Vector3DDouble(-0.88f,-0.44f,-0.15f)); //right

			//initialiseCurvatureVolume();
	}

	template <typename VoxelType>
		EndoscopyRenderer<VoxelType>::~EndoscopyRenderer() throw()
	{
	}

	template <typename VoxelType>
		void EndoscopyRenderer<VoxelType>::render() throw()
	{
		THERMITE_LOG_DEBUG << camera().position();

		//clear the display
		imageVal.clearTo(RGBA<uint1>(0,0,0,0));

		//Some globalish values.
		const double ambientFactor = 0.3f;
		const double diffuseFactor = 0.6f;
		const double specularFactor = 0.5f;
		const double specularExponent = 20.0f;

		//Camera properties which aren't dependant on image position
		const Vector3DDouble xDelta = cameraVal.right() / static_cast<double>(imageVal.width());
		const Vector3DDouble yDelta = cameraVal.up() / static_cast<double>(imageVal.width());
		const Vector3DDouble lowerLeftCorner = cameraVal.position() + cameraVal.forward() - (cameraVal.right() / 2.0) - (cameraVal.up() / 2.0);

		//For each pixel in the image:
		for(uint4 posY = 0; posY < image().height(); ++posY)
		{        
			for(uint4 posX = 0; posX < image().width(); ++posX)
			{
				//Compute the ray direction           
				Vector3DDouble pointOnImagePlane = lowerLeftCorner + (xDelta * static_cast<double>(posX)) + (yDelta * static_cast<double>(posY));
				Vector3DDouble rayPosition = cameraVal.position();
				Vector3DDouble rayDirection = (pointOnImagePlane - cameraVal.position());
				rayDirection.normalise();

				//Skip ray ahead
				Octree<VoxelType>& octree = m_pVolume->octree();
				std::queue< std::pair< Vector3DDouble, uint4 > > queueNodesToProcess;
				queueNodesToProcess.push(std::make_pair(rayPosition, 0));
				bool bFoundSurface = false;
				while((queueNodesToProcess.empty() == false) && (bFoundSurface == false))
				{
					Vector3DDouble position = queueNodesToProcess.front().first;
					uint4 uNodeIndex = queueNodesToProcess.front().second;
					queueNodesToProcess.pop();
					const OctreeNode<VoxelType>& octreeNode = octree.nodeAt(uNodeIndex);

					//THERMITE_LOG_DEBUG << "node min = " << octreeNode.minPosition() << " max = " << octreeNode.maxPosition() << std::endl;

					if(octreeNode.maxVoxelValue() >= m_fThreshold)			
					{
						if(octreeNode.isLeaf())
						{
							//uint4 noOfSteps = computeNoOfStepsToExitBox<double>(position, rayDirection, octreeNode.minPosition(),octreeNode.maxPosition());
							//for(uint4 ct = 0; ct < noOfSteps; ++ct)
							while(octreeNode.containsPoint(position))
							{     
								//if(m_pVolume->computeTrilinearlyInterpolatedValueAt(position) < m_fThreshold)
								if(m_pVolume->cellCornersBelowThreshold(position,static_cast<VoxelType>(m_fThreshold)))
								{
									position += rayDirection;
									//THERMITE_LOG_DEBUG << "Position = " << position << std::endl;
								}	
								else
								{
									position -= rayDirection;
									bFoundSurface = true;
									break;
								}
							}
						}
						else
						{
							while(octreeNode.containsPoint(position))
							{
								uint4 childNode = octree.findChildforPoint(uNodeIndex, position);								
								queueNodesToProcess.push(std::make_pair(position,childNode));

								/*uint4 noOfSteps = computeNoOfStepsToExitBox(position, rayDirection, octree.nodeAt(childNode).minPosition(),octree.nodeAt(childNode).maxPosition());
								position += (rayDirection * static_cast<double>(noOfSteps));*/
								while(octree.nodeAt(childNode).containsPoint(position))
								{
									position += rayPosition;
								}
							}							
						}
					}
					rayPosition = position;
				}

				while(m_pVolume->contains(rayPosition,2))
				{
					if(m_pVolume->computeTrilinearlyInterpolatedValueAt(rayPosition) < m_fThreshold)
					{
						rayPosition += rayDirection;
					}
					else
					{
						break;
					}
				}

				if(m_pVolume->contains(rayPosition,2) == false)
				{
					continue;
				}	
				

				rayDirection *= -0.5f;
				bool previouslyInside = true;    
				for(uint4 ct = 0; ct < 5; ct++)
				{
					//Move ray forward.
					rayPosition += rayDirection;

					//Interpolate and offset. Will be positive if in isosurface, negative if outside
					double interpolatedValue = m_pVolume->computeTrilinearlyInterpolatedValueAt(rayPosition);
					bool inside;
					if(interpolatedValue > m_fThreshold)
						inside = true;
					else
						inside = false;

					if(inside == previouslyInside)
						rayDirection *= 0.5;
					else
						rayDirection *= -0.5;
					previouslyInside = inside;
				}

				//------------------------

				//Do the lighting
				Vector3DDouble normal;                

				if(useSobel)
				{
					normal = m_pVolume->computeTrilinearlyInterpolatedSobelGradientAt(rayPosition);
				}
				else
				{
					normal = m_pVolume->computeTrilinearlyInterpolatedCentralDifferenceGradientAt(rayPosition);
				}               

				normal.normalise();

				RGBA<uint1> rgbaSurface(255,170,150,255);
				/*double dCurvature = m_pVolume->computeTrilinearlyInterpolatedCurvatureAt(rayPosition);
				if(dCurvature <= 0.5)
				{
					rgbaSurface.set(uint1(dCurvature*2.0*255.0),255,0,255);
				}
				else
				{
					rgbaSurface.set(255,uint1(255.0-((dCurvature-0.5)*2.0*255.0)),0,255);
				}*/

				RGBA<uint1> finalColour = calculatePhongLighting(cameraVal.forward(),normal,rgbaSurface,ambientFactor,diffuseFactor,specularFactor,specularExponent);
				imageVal.pixelAt(posX,posY) = finalColour;
			}
		}
	}

	template <typename VoxelType>
		void EndoscopyRenderer<VoxelType>::initialiseCurvatureVolume(void)
	{
		m_volCurvature.setDimensions(m_pVolume->width(), m_pVolume->height(),m_pVolume->depth());
		for(uint4 z = 0; z < m_volCurvature.depth()-1; ++z)
		{
			for(uint4 y = 0; y < m_volCurvature.height()-1; ++y)
			{
				for(uint4 x = 0; x < m_volCurvature.width()-1; ++x)
				{                
					m_volCurvature.voxelAt(Thermite::Vector3DUint4(x,y,z)) = 0.0;
				}
			}
		}

		uint4 pointsComputed = 0;
		for(uint4 z = 2; z < m_volCurvature.depth()-3; ++z)
		{
			THERMITE_LOG_DEBUG << "Z = " << z;
			for(uint4 y = 2; y < m_volCurvature.height()-3; ++y)
			{
				for(uint4 x = 2; x < m_volCurvature.width()-3; ++x)
				{            
					Vector3DInt4 v3dCurrentNormal= m_pVolume->computeSobelGradientAt(Vector3DUint4(x,y,z));
					Vector3DDouble v3dCurrentNormalAsDouble = static_cast<Vector3DDouble>(v3dCurrentNormal);
					/*if(v3dCurrentNormalAsDouble.length() < 10000.0)
					{
						continue;
					}*/
                    
					pointsComputed++;
					Vector3DInt4 v3dAverageNormal(0.0,0.0,0.0);
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y-1,z-1));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y-1,z  ));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y-1,z+1));

					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y  ,z-1));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y  ,z  ));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y  ,z+1));

					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y+1,z-1));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y+1,z  ));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y+1,z+1));


					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y-1,z-1));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y-1,z  ));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y-1,z+1));

					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y  ,z-1));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y  ,z  ));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y  ,z+1));

					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y+1,z-1));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y+1,z  ));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y+1,z+1));


					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y-1,z-1));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y-1,z  ));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y-1,z+1));

					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y  ,z-1));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y  ,z  ));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y  ,z+1));

					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y+1,z-1));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y+1,z  ));
					v3dAverageNormal += m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y+1,z+1));					

					Vector3DDouble v3dAverageNormalAsDouble = static_cast<Vector3DDouble>(v3dAverageNormal);					

					v3dCurrentNormalAsDouble.normalise();
					v3dAverageNormalAsDouble.normalise();

					m_volCurvature.voxelAt(Vector3DUint4(x,y,z)) = float(v3dCurrentNormalAsDouble.dot(v3dAverageNormalAsDouble));
				}
			}
		}
		THERMITE_LOG_DEBUG << "Computed " << pointsComputed << "points";
	}
    
#ifdef BLAH

    template <typename VoxelType>
	void EndoscopyRenderer<VoxelType>::render2() throw()
	{
			//clear the display
			imageVal.clearTo(RGBA<uint1>(0,0,0,0));
			//THERMITE_LOG_DEBUG << "Rendering Frame" << std::endl;
			cacheMissCounter = 0;
			//Check the camera is in the volume.
			/*if((cameraVal.position().x() < 3) || (cameraVal.position().x() > volume().width() - 3) ||
					(cameraVal.position().y() < 3) || (cameraVal.position().y() > volume().height() - 3) ||
					(cameraVal.position().z() < 3) || (cameraVal.position().z() > volume().depth() - 3))
			{
					return;
			}*/

			//Some globalish values.
			const double ambientFactor = 0.3f;
			const double diffuseFactor = 0.6f;
			const double specularFactor = 0.5f;
			const double specularExponent = 20.0f;

			//Camera properties which aren't dependant on image position
			const Vector3DDouble xDelta = cameraVal.right() / static_cast<double>(imageVal.width());
			const Vector3DDouble yDelta = cameraVal.up() / static_cast<double>(imageVal.width());
			const Vector3DDouble lowerLeftCorner = cameraVal.position() + cameraVal.forward() - (cameraVal.right() / 2.0) - (cameraVal.up() / 2.0);
			const uint4 imageHeightInGroups = imageVal.height()/3;
			const uint4 imageWidthInGroups = imageVal.width()/3;

			//For each pixel group in the image:
			for(uint4 groupPosY = 0; groupPosY < imageHeightInGroups; ++groupPosY)
			{        
					const uint4 groupCornerY = groupPosY * 3;
					Vector3DDouble yOffset = yDelta * static_cast<double>(groupCornerY + 1);
					const Vector3DDouble lowerLeftCornerPlusYOffset = lowerLeftCorner + yOffset;

					for(uint4 groupPosX = 0; groupPosX < imageWidthInGroups; ++groupPosX)
					{
							//Properties relating to the group
							const uint4 groupCornerX = groupPosX * 3;            
							const uint4 groupPattern = (groupPosX + groupPosY) % 2;

							//First we compute the starting depth
							//Compute the ray direction
							Vector3DDouble xOffset = xDelta * static_cast<double>(groupCornerX + 1);            
							Vector3DDouble pointOnImagePlane = lowerLeftCornerPlusYOffset + xOffset;
							Vector3DDouble rayPosition = cameraVal.position();
							Vector3DDouble rayDirection = (pointOnImagePlane - cameraVal.position());
							rayDirection.normalise();

							//Do some kind of space skipping
							while(((m_volUtility.voxelAt(static_cast< Vector3DUint4 >(rayPosition)) & CELL_OCCUPIED_FLAG) == false)
								&& ((m_volUtility.voxelAt(static_cast< Vector3DUint4 >(rayPosition)) & NEAR_EDGE_FLAG) == false))
							{
									rayPosition += rayDirection;
							}  

							if(m_volUtility.voxelAt(static_cast< Vector3DUint4 >(rayPosition)) & NEAR_EDGE_FLAG)
							{
								break;
							}

							const double fStartDepth = (rayPosition - cameraVal.position()).length();


							//Now render rest of group
							const int4 pRayPattern[2][10][2] = {{{2,2},{2,0},{0,0},{0,2},{1,1},{-1,-1}},
							{{2,1},{1,0},{0,1},{1,2},{-1,-1}}};
							for(uint4 uRayCt = 0; pRayPattern[groupPattern][uRayCt][0] >= 0; ++uRayCt) //A '-1' marks the end of the pattern
							{           
									//Compute the ray direction
									xOffset = xDelta * static_cast<double>(groupCornerX + pRayPattern[groupPattern][uRayCt][0]);
									yOffset = yDelta * static_cast<double>(groupCornerY + pRayPattern[groupPattern][uRayCt][1]);
									pointOnImagePlane = lowerLeftCorner + xOffset + yOffset;
									rayPosition = cameraVal.position();
									rayDirection = (pointOnImagePlane - cameraVal.position());
									rayDirection.normalise();

									//Skip ahead the appropriate amount
									rayPosition += (rayDirection * fStartDepth);

									while((m_pVolume->computeTrilinearlyInterpolatedValueAt(rayPosition) < m_fThreshold)
										&& ((m_volUtility.voxelAt(static_cast< Vector3DUint4 >(rayPosition)) & NEAR_EDGE_FLAG) == false))
									{
											rayPosition += rayDirection;
									}

									/*if(m_volUtility.voxelAt(static_cast< Vector3DUint4 >(rayPosition)) & NEAR_EDGE_FLAG)
									{
										break;
									}*/

									//double oneToOneDist = 300.0f;
									//double increment = -(fStartDepth / oneToOneDist);
									//rayDirection *= increment;
									/*rayDirection *= -0.1f;
									while(volume().computeTrilinearlyInterpolatedValueAt(rayPosition) >= m_fThreshold)
									{
											rayPosition += rayDirection;
									}*/

									rayDirection *= -0.5f;
									bool previouslyInside = true;    
									for(uint4 ct = 0; ct < 5; ct++)
									{
											//Move ray forward.
											rayPosition += rayDirection;

											//Interpolate and offset. Will be positive if in isosurface, negative if outside
											double interpolatedValue = m_pVolume->computeTrilinearlyInterpolatedValueAt(rayPosition);
											bool inside;
											if(interpolatedValue > m_fThreshold)
													inside = true;
											else
													inside = false;

											if(inside == previouslyInside)
													rayDirection *= 0.5;
											else
													rayDirection *= -0.5;
											previouslyInside = inside;
									}

									//------------------------

									//Do the lighting
									//Vector3DDouble normal = volume().computeTrilinearlyInterpolatedCentralDifferenceGradientAt(rayPosition);
									const uint4 floorX = static_cast<uint4>(rayPosition.x());
									const uint4 floorY = static_cast<uint4>(rayPosition.y());
									const uint4 floorZ = static_cast<uint4>(rayPosition.z());

									const uint4 ceilX = floorX + 1;
									const uint4 ceilY = floorY + 1;
									const uint4 ceilZ = floorZ + 1;

									Vector3DDouble normal;                

									if(m_bUsingGradientCache)
									{
											const Vector3DInt4& v000 = m_gradientCache[floorX][floorY][m_volUtility.voxelAt(Vector3DUint4(floorX, floorY, floorZ)) & 4095];
											const Vector3DInt4& v100 = m_gradientCache[ceilX][floorY][m_volUtility.voxelAt(Vector3DUint4(ceilX, floorY, floorZ)) & 4095];
											const Vector3DInt4& v010 = m_gradientCache[floorX][ceilY][m_volUtility.voxelAt(Vector3DUint4(floorX, ceilY, floorZ)) & 4095];
											const Vector3DInt4& v110 = m_gradientCache[ceilX][ceilY][m_volUtility.voxelAt(Vector3DUint4(ceilX, ceilY, floorZ)) & 4095];
											const Vector3DInt4& v001 = m_gradientCache[floorX][floorY][m_volUtility.voxelAt(Vector3DUint4(floorX, floorY, ceilZ)) & 4095];
											const Vector3DInt4& v101 = m_gradientCache[ceilX][floorY][m_volUtility.voxelAt(Vector3DUint4(ceilX, floorY, ceilZ)) & 4095];
											const Vector3DInt4& v011 = m_gradientCache[floorX][ceilY][m_volUtility.voxelAt(Vector3DUint4(floorX, ceilY, ceilZ)) & 4095];
											const Vector3DInt4& v111 = m_gradientCache[ceilX][ceilY][m_volUtility.voxelAt(Vector3DUint4(ceilX, ceilY, ceilZ)) & 4095];

											normal =  trilinearlyInterpolate< Vector3DDouble >(
													Vector3DDouble(v000),
													static_cast< Vector3DDouble >(v100),
													static_cast< Vector3DDouble >(v010),
													static_cast< Vector3DDouble >(v110),
													static_cast< Vector3DDouble >(v001),
													static_cast< Vector3DDouble >(v101),
													static_cast< Vector3DDouble >(v011),
													static_cast< Vector3DDouble >(v111),
													rayPosition.x() - floorX,rayPosition.y() - floorY,rayPosition.z() - floorZ);
									}
									else
									{
											//normal = volume().computeTrilinearlyInterpolatedCentralDifferenceGradientAt(rayPosition);
											if(useSobel)
											{
													normal = m_pVolume->computeTrilinearlyInterpolatedSobelGradientAt(rayPosition);
											}
											else
											{
													normal = m_pVolume->computeTrilinearlyInterpolatedCentralDifferenceGradientAt(rayPosition);
											}
									}                  

									normal.normalise();
									const Vector3DDouble& lightDirection = cameraVal.forward();

									//Ambient component
									const double ambientIntensity = ambientFactor;

									//Diffuse Component
									const double normalDotLight = normal.dot(lightDirection);
									const double diffuseIntensity = (std::max)(normalDotLight, 0.0) * diffuseFactor;

									//Specular Component
									// Schlick's slick approximation for Phong's specular term:
									// Simply replace Sn(t) = t^n with Sn(t) = t / (n - nt + t).
									const double specularIntensity = ((normalDotLight) / (specularExponent - specularExponent*normalDotLight + normalDotLight)) * specularFactor;


									rayPosition += rayDirection;

									const RGBA<uint1> finalColour(
											(ambientIntensity + diffuseIntensity) * 1.0f  + specularIntensity,
											(ambientIntensity + diffuseIntensity) * 0.6f  + specularIntensity,
											(ambientIntensity + diffuseIntensity) * 0.55f + specularIntensity,
											1.0f
											);

									(imageVal.rawData())[(groupCornerY + pRayPattern[groupPattern][uRayCt][1]) * imageVal.width() + (groupCornerX + pRayPattern[groupPattern][uRayCt][0])] = finalColour;
							}
					}
			}

			for(uint4 interpolationPosY = 1; interpolationPosY < imageVal.height() -1; ++interpolationPosY)
			{        
					for(uint4 interpolationPosX = 1 + (interpolationPosY %2); interpolationPosX < imageVal.width() - 1; interpolationPosX += 2)
					{
							const RGBA<uint1> & fA = imageVal.pixelAt(interpolationPosX-1,interpolationPosY  );
							const RGBA<uint1> & fB = imageVal.pixelAt(interpolationPosX+1,interpolationPosY  );
							const RGBA<uint1> & fC = imageVal.pixelAt(interpolationPosX,  interpolationPosY-1);
							const RGBA<uint1> & fD = imageVal.pixelAt(interpolationPosX,  interpolationPosY+1);

							const RGBA<uint1> interpolatedColour(
									(fA.red()   + fB.red()   + fC.red()   + fD.red())   / 4.0f,
									(fA.green() + fB.green() + fC.green() + fD.green()) / 4.0f,
									(fA.blue()  + fB.blue()  + fC.blue()  + fD.blue())  / 4.0f,
									(fA.alpha() + fB.alpha() + fC.alpha() + fD.alpha()) / 4.0f);
							(imageVal.rawData())[interpolationPosY * imageVal.width() + interpolationPosX] = interpolatedColour;
					}
			}

			//THERMITE_LOG_DEBUG << "Cache misses = " << cacheMissCounter << std::endl;
	}

    template <typename VoxelType>
	inline void EndoscopyRenderer<VoxelType>::computeAndCacheGradientForCellAt(const Vector3DUint4& position)
	{ 
			const uint4 floorX = static_cast<uint4>(position.x());
			const uint4 floorY = static_cast<uint4>(position.y());
			const uint4 floorZ = static_cast<uint4>(position.z());

			const uint4 ceilX = floorX + 1;
			const uint4 ceilY = floorY + 1;
			const uint4 ceilZ = floorZ + 1;

			Vector3DUint4 currentPos = Vector3DUint4(floorX, floorY, floorZ);
			//THERMITE_LOG_DEBUG <<currentPos << std::endl;
			if((m_volUtility.voxelAt(currentPos) & GRADIENT_CACHED_FLAG) == 0)
			{
					computeAndCacheGradientAt(currentPos);
			}

			currentPos = Vector3DUint4(ceilX, floorY, floorZ);
			//THERMITE_LOG_DEBUG <<currentPos << std::endl;
			if((m_volUtility.voxelAt(currentPos) & GRADIENT_CACHED_FLAG) == 0)
			{
					computeAndCacheGradientAt(currentPos);
			}

			currentPos = Vector3DUint4(floorX, ceilY, floorZ);
			//THERMITE_LOG_DEBUG <<currentPos << std::endl;
			if((m_volUtility.voxelAt(currentPos) & GRADIENT_CACHED_FLAG) == 0)
			{
					computeAndCacheGradientAt(currentPos);
			}

			currentPos = Vector3DUint4(ceilX, ceilY, floorZ);
			//THERMITE_LOG_DEBUG <<currentPos << std::endl;
			if((m_volUtility.voxelAt(currentPos) & GRADIENT_CACHED_FLAG) == 0)
			{
					computeAndCacheGradientAt(currentPos);
			}

			//////////////////////////////////////////////////////////////////////////

			currentPos = Vector3DUint4(floorX, floorY, ceilZ);
			//THERMITE_LOG_DEBUG <<currentPos << std::endl;
			if((m_volUtility.voxelAt(currentPos) & GRADIENT_CACHED_FLAG) == 0)
			{
					computeAndCacheGradientAt(currentPos);
			}

			currentPos = Vector3DUint4(ceilX, floorY, ceilZ);
			//THERMITE_LOG_DEBUG <<currentPos << std::endl;
			if((m_volUtility.voxelAt(currentPos) & GRADIENT_CACHED_FLAG) == 0)
			{
					computeAndCacheGradientAt(currentPos);
			}

			currentPos = Vector3DUint4(floorX, ceilY, ceilZ);
			//THERMITE_LOG_DEBUG <<currentPos << std::endl;
			if((m_volUtility.voxelAt(currentPos) & GRADIENT_CACHED_FLAG) == 0)
			{
					computeAndCacheGradientAt(currentPos);
			}

			currentPos = Vector3DUint4(ceilX, ceilY, ceilZ);
			//THERMITE_LOG_DEBUG <<currentPos << std::endl;
			if((m_volUtility.voxelAt(currentPos) & GRADIENT_CACHED_FLAG) == 0)
			{
					computeAndCacheGradientAt(currentPos);
			}

			m_volUtility.voxelAt(Vector3DUint4(floorX,floorY,floorZ)) = m_volUtility.voxelAt(Vector3DUint4(floorX,floorY,floorZ)) + 8192;
	}

    template <typename VoxelType>
	inline Vector3DInt4 EndoscopyRenderer<VoxelType>::computeAndCacheGradientAt(const Vector3DUint4& position)
	{   
			cacheMissCounter++;
			//THERMITE_LOG_DEBUG << "Gradient not in cache for (" << position.x() << "," << position.y() << "," << position.z() << ")" << std::endl;
			Vector3DInt4 gradient;
			if(useSobel)
			{
					gradient = m_pVolume->computeSobelGradientAt(position);
			}
			else
			{
					gradient = m_pVolume->computeCentralDifferenceGradientAt(position);
			}
			//THERMITE_LOG_DEBUG << "got gradient" << std::endl;
			uint2 currentSize = static_cast<uint2>(m_gradientCache[position.x()][position.y()].size());
			//THERMITE_LOG_DEBUG << "current size here " << currentSize << std::endl;
			m_gradientCache[position.x()][position.y()].resize(currentSize + 1);
			//THERMITE_LOG_DEBUG << "and current size here " << currentSize << std::endl;
			m_gradientCache[position.x()][position.y()][currentSize] = gradient;
			//THERMITE_LOG_DEBUG << "current size " << currentSize << std::endl;
			if(currentSize > 4095)
			{
				THERMITE_LOG_ERROR << "Greater than 4095" << std::endl;
				exit(1);
			}
			currentSize = currentSize | m_volUtility.voxelAt(position);
			currentSize += 4096;
			m_volUtility.voxelAt(position) = currentSize;
			if(useSobel)
			{
					return m_pVolume->computeSobelGradientAt(position);
			}
			else
			{
					return m_pVolume->computeCentralDifferenceGradientAt(position);
			}
	}

    template <typename VoxelType>
	void EndoscopyRenderer<VoxelType>::initialiseUtilityVolume(void)
	{
			m_volUtility.setDimensions(m_pVolume->width(), m_pVolume->height(),m_pVolume->depth());
			for(uint4 z = 0; z < m_pVolume->depth()-1; ++z)
			{
					for(uint4 y = 0; y < m_pVolume->height()-1; ++y)
					{
							for(uint4 x = 0; x < m_pVolume->width()-1; ++x)
							{                
									m_volUtility.voxelAt(Thermite::Vector3DUint4(x,y,z)) = 0;
							}
					}
			}
			for(uint4 z = 0; z < m_pVolume->depth()-2; ++z)
			{
					for(uint4 y = 0; y < m_pVolume->height()-2; ++y)
					{
							for(uint4 x = 0; x < m_pVolume->width()-2; ++x)
							{
									bool cellOccupied = ((m_pVolume->voxelAt(Thermite::Vector3DUint4(x,y,z)) >= m_fThreshold) ||
											(m_pVolume->voxelAt(Thermite::Vector3DUint4(x,y,z+1)) >= m_fThreshold) ||
											(m_pVolume->voxelAt(Thermite::Vector3DUint4(x,y+1,z)) >= m_fThreshold) ||
											(m_pVolume->voxelAt(Thermite::Vector3DUint4(x,y+1,z+1)) >= m_fThreshold) ||
											(m_pVolume->voxelAt(Thermite::Vector3DUint4(x+1,y,z)) >= m_fThreshold) ||
											(m_pVolume->voxelAt(Thermite::Vector3DUint4(x+1,y,z+1)) >= m_fThreshold) ||
											(m_pVolume->voxelAt(Thermite::Vector3DUint4(x+1,y+1,z)) >= m_fThreshold) ||
											(m_pVolume->voxelAt(Thermite::Vector3DUint4(x+1,y+1,z+1)) >= m_fThreshold));
									if(cellOccupied)
											m_volUtility.voxelAt(Thermite::Vector3DUint4(x,y,z)) = m_volUtility.voxelAt(Thermite::Vector3DUint4(x,y,z)) | CELL_OCCUPIED_FLAG;
							}
					}
			}

			for(uint4 z = 0; z < m_pVolume->depth()-1; ++z)
			{
					for(uint4 y = 0; y < m_pVolume->height()-1; ++y)
					{
							for(uint4 x = 0; x < m_pVolume->width()-1; ++x)
							{
									if((x < 3) || (x > m_pVolume->width()-4) ||
											(y < 3) || (y > m_pVolume->height()-4) ||
											(z < 3) || (z > m_pVolume->depth()-4))
									{
											m_volUtility.voxelAt(Thermite::Vector3DUint4(x,y,z)) = m_volUtility.voxelAt(Thermite::Vector3DUint4(x,y,z)) | NEAR_EDGE_FLAG;
									}
							}
					}
			}

			if(m_bUsingGradientCache)
			{
					//Build gradient cache
					THERMITE_LOG_DEBUG << "Building Gradient Cache" << std::endl;
					m_gradientCache.resize(m_pVolume->width());
					for(uint4 ct = 0; ct < m_pVolume->width(); ct++)
					{
							m_gradientCache[ct].resize(m_pVolume->height());
							for(uint4 ct2 = 0; ct2 < m_pVolume->width(); ct2++)
							{
									m_gradientCache[ct][ct2].resize(0);
							}
					}

					//And initialise it...
					for(uint4 z = 1; z < m_pVolume->depth()-2; ++z)
					{
							for(uint4 y = 1; y < m_pVolume->height()-2; ++y)
							{
									for(uint4 x = 1; x < m_pVolume->width()-2; ++x)
									{
											//Count how many of region are above threshold
											uint4 aboveThreshold = 0;
											if(m_pVolume->voxelAt(Vector3DUint4(x,y,z)) > m_fThreshold)
													++aboveThreshold;
											if(m_pVolume->voxelAt(Vector3DUint4(x+1,y,z)) > m_fThreshold)
													++aboveThreshold;
											if(m_pVolume->voxelAt(Vector3DUint4(x,y+1,z)) > m_fThreshold)
													++aboveThreshold;
											if(m_pVolume->voxelAt(Vector3DUint4(x+1,y+1,z)) > m_fThreshold)
													++aboveThreshold;
											if(m_pVolume->voxelAt(Vector3DUint4(x,y,z+1)) > m_fThreshold)
													++aboveThreshold;
											if(m_pVolume->voxelAt(Vector3DUint4(x+1,y,z+1)) > m_fThreshold)
													++aboveThreshold;
											if(m_pVolume->voxelAt(Vector3DUint4(x,y+1,z+1)) > m_fThreshold)
													++aboveThreshold;
											if(m_pVolume->voxelAt(Vector3DUint4(x+1,y+1,z+1)) > m_fThreshold)
													++aboveThreshold;

											//If it's not all or none we may be on an isosurface
											//THERMITE_LOG_DEBUG << "Caching for (" << x << "," << y << "," << z << ")" << std::endl;
											if((aboveThreshold != 0) && (aboveThreshold != 8))
													computeAndCacheGradientForCellAt(Vector3DUint4(x,y,z));
									}
							}
					}
			}    
	}

#endif

        /*template <typename VoxelType>
	void EndoscopyRenderer<VoxelType>::initialiseDistanceVolume(void)
	{
			THERMITE_LOG_DEBUG << "Initialising dist vol" << std::endl;
			//Create and initialise to large depth
			m_volDistance.setDimensions(m_pVolume->width(), m_pVolume->height(),m_pVolume->depth());
			//THERMITE_LOG_DEBUG << "Set dimentions " << m_volDistance.rawData() << std::endl;
			for(uint4 z = 0; z < m_volDistance.depth()-1; ++z)
			{
					//THERMITE_LOG_DEBUG << "z is " << z << std::endl;
					for(uint4 y = 0; y < m_volDistance.height()-1; ++y)
					{
							for(uint4 x = 0; x < m_volDistance.width()-1; ++x)
							{                
									if(m_pVolume->voxelAt(Thermite::Vector3DUint4(x,y,z)) < m_fThreshold)
									{
											m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y,z)) = 1000000.0f;
									}
									else
									{
											m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y,z)) = 0.0f;
									}
							}
					}
			}

			const double sqrt1 = 1.0f;
			const double sqrt2 = sqrt(2.0f);
			const double sqrt3 = sqrt(3.0f);

			THERMITE_LOG_DEBUG << "Doing forward pass" << std::endl;
			//Do forwards pass
			for(uint4 z = 1; z < m_volDistance.depth()-2; ++z)
			{
					//THERMITE_LOG_DEBUG << "z pass is " << z << std::endl;
					for(uint4 y = 1; y < m_volDistance.height()-2; ++y)
					{
							for(uint4 x = 1; x < m_volDistance.width()-2; ++x)
							{         
									double minOfNeighbours = m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y,z));

									if(minOfNeighbours > 0.001f)
									{
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y-1,z-1))) + sqrt3);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y-1,z))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y-1,z+1))) + sqrt3);

											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y,z-1))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y,z))) + sqrt1);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y,z+1))) + sqrt2);

											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y+1,z-1))) + sqrt3);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y+1,z))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y+1,z+1))) + sqrt3);


											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y-1,z-1))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y-1,z))) + sqrt1);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y-1,z+1))) + sqrt2);

											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y,z-1))) + sqrt1);
											//minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y,z))) * );
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y,z+1))) + sqrt1);

											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y+1,z-1))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y+1,z))) + sqrt1);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y+1,z+1))) + sqrt2);


											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y-1,z-1))) + sqrt3);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y-1,z))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y-1,z+1))) + sqrt3);

											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y,z-1))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y,z))) + sqrt1);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y,z+1))) + sqrt2);

											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y+1,z-1))) + sqrt3);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y+1,z))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y+1,z+1))) + sqrt3);

											//Set the voxel
											//minOfNeighbours = std::min(minOfNeighbours,uint4(0xFF));
											m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y,z)) = minOfNeighbours;
									}
							}
					}
			}

			THERMITE_LOG_DEBUG << "Doing backward pass" << std::endl;
			//Do forwards pass
			for(uint4 z = m_volDistance.depth()-2; z > 0 ; --z)
			{
					//THERMITE_LOG_DEBUG << "z pass is " << z << std::endl;
					for(uint4 y = m_volDistance.height()-2; y > 0; --y)
					{
							for(uint4 x = m_volDistance.width()-2; x > 0; --x)
							{                
									double minOfNeighbours = double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y,z)));

									if(minOfNeighbours > 0.001f)
									{
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y-1,z-1))) + sqrt3);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y-1,z))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y-1,z+1))) + sqrt3);

											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y,z-1))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y,z))) + sqrt1);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y,z+1))) + sqrt2);

											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y+1,z-1))) + sqrt3);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y+1,z))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x-1,y+1,z+1))) + sqrt3);


											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y-1,z-1))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y-1,z))) + sqrt1);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y-1,z+1))) + sqrt2);

											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y,z-1))) + sqrt1);
											//minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y,z))) * );
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y,z+1))) + sqrt1);

											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y+1,z-1))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y+1,z))) + sqrt1);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y+1,z+1))) + sqrt2);


											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y-1,z-1))) + sqrt3);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y-1,z))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y-1,z+1))) + sqrt3);

											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y,z-1))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y,z))) + sqrt1);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y,z+1))) + sqrt2);

											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y+1,z-1))) + sqrt3);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y+1,z))) + sqrt2);
											minOfNeighbours = std::min(minOfNeighbours, double(m_volDistance.voxelAt(Thermite::Vector3DUint4(x+1,y+1,z+1))) + sqrt3);

											//Set the voxel
											//minOfNeighbours = std::min(minOfNeighbours,uint4(0xFF));
											m_volDistance.voxelAt(Thermite::Vector3DUint4(x,y,z)) = minOfNeighbours;
									}
							}
					}
			}
	}*/
}

#undef CELL_OCCUPIED_FLAG
#undef NEAR_EDGE_FLAG
#undef GRADIENT_CACHED_FOR_CELL_FLAG
#undef GRADIENT_CACHED_FLAG
