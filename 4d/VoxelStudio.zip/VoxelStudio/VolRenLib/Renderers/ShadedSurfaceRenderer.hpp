#ifndef SHADED_SURFACE_RENDERER_HEADER_INCLUDED
#define SHADED_SURFACE_RENDERER_HEADER_INCLUDED

#include <list>
#include <vector>

#include "ScanlineRenderer.hpp"
#include "VolumeRenderer.hpp"
#include "..\Images\RGBA.hpp"
#include "..\Base\Typedef.hpp"

namespace Thermite
{
    template <typename VoxelType>
    class  ShadedSurfaceRenderer : public VolumeRenderer<SoftwareRenderer, VoxelType>
    {
    public:
        ShadedSurfaceRenderer(Thermite::Volume<VoxelType>* pVolume) throw();
        virtual ~ShadedSurfaceRenderer() throw();

		const RGBA<uint1>& isosurfaceColour(void);
		double isovalue(void);

		void setIsosurfaceColour(const RGBA<uint1>& rgbaIsosurface);
		void setIsovalue(double dIsovalue);

        virtual void render(void) throw();
        void setSize(uint4 uWidth, uint4 uHeight);

		double computeCurvatureAt(Vector3DDouble v3dPosition);

    private:  
		bool useSobel;
		double m_dIsovalue;
		RGBA<uint1> m_rgbaIsosurface;
        ScanlineRenderer* m_rendScanline;
    };
}

#include "ShadedSurfaceRenderer.inl"

#endif
