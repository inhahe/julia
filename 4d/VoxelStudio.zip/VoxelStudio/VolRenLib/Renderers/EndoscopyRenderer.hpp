#ifndef ENDOSCOPYRENDERER_HEADER_INCLUDED
#define ENDOSCOPYRENDERER_HEADER_INCLUDED

#include "VolumeRenderer.hpp"
#include "..\Images\RGBA.hpp"
#include "..\Base\Typedef.hpp"

namespace Thermite
{
    template <typename VoxelType>
	class EndoscopyRenderer : public VolumeRenderer<SoftwareRenderer, VoxelType>
	{
	public:
			EndoscopyRenderer(Thermite::Volume<uint2>* pVolume,double threshold) throw();
			virtual ~EndoscopyRenderer() throw();
			virtual void render(void) throw();
			//virtual void render2(void) throw();
			//void renderNoInterpolation(void) throw();
			//void renderBlockwise(void) throw();
			bool useSobel;
			//void initialiseUtilityVolume(void);
			//double computeCurvatureAt(Vector3DDouble v3dPosition);
			void initialiseCurvatureVolume(void);
			//void initialiseDistanceVolume(void);
			//double oneToOneDist;
			//Vector3DInt4 computeAndCacheGradientAt(const Vector3DUint4& position);
			//void computeAndCacheGradientForCellAt(const Vector3DUint4& position);
	private:
			//LinearVolume<uint2> m_volUtility;
			LinearVolume<float> m_volCurvature;
			//Thermite::LinearVolume<double> m_volDistance;
			double m_fThreshold;

			std::vector< std::vector< std::vector< Vector3DInt4 > > > m_gradientCache;
			//std::vector< Thermite::Vector3D<Thermite::int4> >* m_gradientCache;

			uint4 cacheMissCounter;
			bool m_bUsingGradientCache;
	};
}

#include "EndoscopyRenderer.inl"

#endif
