//#include "ReconstructionFilter.hpp"

#include "ScanlineRenderer.hpp"

#include <limits>

namespace Thermite
{
		ScanlineRenderer::ScanlineRenderer() throw()
	{
	}

		ScanlineRenderer::~ScanlineRenderer() throw()
	{
	}

	const Image<double>& ScanlineRenderer::depthImage() const throw()
	{
		return m_imgDepth;
	}

		void ScanlineRenderer::render() throw()
	{		
		imageVal.clearTo(RGBA<uint1>(0,0,0,0));
		m_imgDepth.clearTo(std::numeric_limits<double>::infinity());
		std::vector< Polygon< double > >::iterator iterPolygons = m_polygons.begin();
		while(iterPolygons != m_polygons.end())
		{
			renderConvexPolygon(*iterPolygons);
			++iterPolygons;
		}
	}

		void ScanlineRenderer::setSize(uint4 uWidth, uint4 uHeight)
	{
		SoftwareRenderer::setSize(uWidth,uHeight);
		m_imgDepth.resize(uWidth,uHeight);
	}

	void ScanlineRenderer::addPolygon(const Polygon< double >& polygon)
	{
		m_polygons.push_back(polygon);
	}

		void ScanlineRenderer::renderConvexPolygon(Polygon< double > vertices)
	{

		//Find the dot product
		//Polygon< Vector3DDouble >::iterator iter = vertices.begin();
		Polygon<double>::Iterator vert0 = vertices.firstVertex();
		Polygon<double>::Iterator vert1 = vert0;
		++vert1;
		Polygon<double>::Iterator vert2 = vert1;
		++vert2;
		Vector3DDouble v1 = (*vert2) - (*vert1);
		Vector3DDouble v2 = (*vert0) - (*vert1);
		Vector3DDouble normal = v1.cross(v2);

		//Abort if polygon facing wrong way
		if(normal.dot(cameraVal.forward()) >= 0.0f)
		{
			return;
		}

		//Project the vertices into screen space
		Polygon<double>::Iterator currentVertex = vertices.firstVertex();
		Polygon< double > projectedPositions;
		//THERMITE_LOG_DEBUG << "vertices in screen space:" << std::endl;
		do
		{			
			Vector3DDouble imageSpacePos = imageSpacePosition(*currentVertex);
			//imageSpacePos.z() = 1.0f / imageSpacePos.z();
			projectedPositions.appendVertex(imageSpacePos);
			//THERMITE_LOG_DEBUG << "    (" << imageSpacePos.x() << "," << imageSpacePos.y() << ")" << std::endl;
			//currentVertex = currentVertex->next();
			++currentVertex;
		}while(currentVertex != vertices.firstVertex());

		drawConvexPolygon(projectedPositions);
	}

		void ScanlineRenderer::drawConvexPolygon(Polygon< double > polygon)
	{
		//Do the clipping
		polygon = clip(polygon);
		if(polygon.noOfVertices() == 0)
		{
			return;
		}

		//Identify the top vertex
		//Polygon< Vector3DDouble >::iterator iterProjectedPositions;
		Polygon<double>::Iterator currentVertex;
		currentVertex = polygon.firstVertex();
		Polygon<double>::Iterator topLeftVertex = polygon.firstVertex();		
		do
		{
			if(currentVertex->y() > topLeftVertex->y())
			{
				topLeftVertex = currentVertex;
			}
			//currentVertex = currentVertex->next();
			++currentVertex;
		}	while(currentVertex != polygon.firstVertex());	

		//Duplicate the top vertex
		polygon.insertAfter(topLeftVertex,*topLeftVertex);
		Polygon<double>::Iterator topRightVertex = topLeftVertex;
		//topRightVertex = topRightVertex->previous();
		++topLeftVertex;
		//THERMITE_LOG_DEBUG << "Top vertices are (" << topLeftVertex->x() << "," << topLeftVertex->y() << ") and  (" << topRightVertex->x() << "," << topRightVertex->y() << ")" << std::endl;
		double currentY = topLeftVertex->y();

		//Calculate heights and deltas
		Polygon<double>::Iterator nextLeft = topLeftVertex;
		//nextLeft = nextLeft->next();
		++nextLeft;
		/*if(nextLeft == projectedPositions.end())
		{
		nextLeft = projectedPositions.begin();
		}*/
		//THERMITE_LOG_DEBUG << "Next left is (" << nextLeft->x() << "," << nextLeft->y() << ")" << std::endl;

		Polygon<double>::Iterator nextRight = topRightVertex;		
		/*if(nextRight == projectedPositions.begin())
		{
		nextRight = projectedPositions.end();
		}*/	
		//nextRight = nextRight->previous();
		--nextRight;
		//THERMITE_LOG_DEBUG << "Next right is (" << nextRight->position().x() << "," << nextRight->position().y() << ")" << std::endl;

		double leftHeight = topLeftVertex->y() - nextLeft->y();
		double rightHeight = topRightVertex->y() - nextRight->y();
		double leftDelta = static_cast<double>(nextLeft->x() - topLeftVertex->x()) / leftHeight;
		double rightDelta = static_cast<double>(nextRight->x() - topRightVertex->x()) / rightHeight;
		double leftDepthDelta = static_cast<double>(nextLeft->z() - topLeftVertex->z()) / leftHeight;
		double rightDepthDelta = static_cast<double>(nextRight->z() - topRightVertex->z()) / rightHeight;

		while(true)
		{
			double height = (std::min)(leftHeight, rightHeight);
			//double height = std::min(iterTopLeftVertex->y() - nextLeft->y(), iterTopRightVertex->y() - nextRight->y());
			/*THERMITE_LOG_DEBUG << "lheight = " << leftHeight 
			<< " rheight = " << rightHeight
			<< " height = " << height
			<< " ldelta = " << leftDelta 
			<< " rdelta  = " << rightDelta << std::endl;*/

			//exit(1);

			if(height < 0.0f)
			{
				break;
			}

			for(double i = 0.0f; i < height; i = i + 1.0f)
			{
				//THERMITE_LOG_DEBUG << "rendering span" << std::endl;
				drawHozizontalSpan(topLeftVertex->x(),topLeftVertex->z(), topRightVertex->x(),topRightVertex->z(), currentY);
				--currentY;
				/*topLeftVertex->x() += leftDelta;
				topRightVertex->x() += rightDelta;
				topLeftVertex->z() += leftDepthDelta;
				topRightVertex->z() += rightDepthDelta;*/
				topLeftVertex->setX(topLeftVertex->x() + leftDelta);
				topRightVertex->setX(topRightVertex->x() + rightDelta);
				topLeftVertex->setZ(topLeftVertex->z() + leftDepthDelta);
				topRightVertex->setZ(topRightVertex->z() + rightDepthDelta);
				--leftHeight;
				--rightHeight;
			}

			if(leftHeight <= 0.0f)
			{
				topLeftVertex = nextLeft;
				//nextLeft = nextLeft->next();
				++nextLeft;
				/*if(nextLeft == projectedPositions.end())
				{
				nextLeft = projectedPositions.begin();
				}*/
				leftHeight = topLeftVertex->y() - nextLeft->y();
				leftDelta = static_cast<double>(nextLeft->x() - topLeftVertex->x()) / leftHeight;
				leftDepthDelta = static_cast<double>(nextLeft->z() - topLeftVertex->z()) / leftHeight;
				//THERMITE_LOG_DEBUG << "Reset: lheight = " << leftHeight << " ldelta = " << leftDelta << std::endl;
			}

			if(rightHeight <= 0.0f)
			{
				topRightVertex = nextRight;
				/*if(nextRight == projectedPositions.begin())
				{
				nextRight = projectedPositions.end();
				}*/	
				--nextRight;
				//nextRight = nextRight->previous();
				rightHeight = topRightVertex->y() - nextRight->y();
				rightDelta = static_cast<double>(nextRight->x() - topRightVertex->x()) / rightHeight;
				rightDepthDelta = static_cast<double>(nextRight->z() - topRightVertex->z()) / rightHeight;
				//THERMITE_LOG_DEBUG << "Reset: rheight = " << rightHeight << " rdelta = " << rightDelta << std::endl;
			}

			//exit(1);
		}
	}

		void ScanlineRenderer::drawHozizontalSpan(uint4 x1, double depth1, uint4 x2, double depth2, uint4 y)
	{
		/*if(y < imageVal.height())
		{
			double xDelta = (depth2 - depth1) / (x2-x1);
			for(uint4 x = x1; x <= x2; ++x)
			{
				if(x < imageVal.width())
				{
					//double temp = 1.0f / depth1;
                    double temp = depth1;
					//temp /= 500.0f;
					imageVal.pixelAt(x,y) = RGBA<float>(1.0f,1.0f,1.0f,1.0f);
					m_imgDepth.pixelAt(x,y) = temp;
				}
				depth1 += xDelta;
			}
		}*/
	}

		Vector3DDouble ScanlineRenderer::imageSpacePosition(const Vector3DDouble& position)
	{
		//Orthographic projection so this should be easy...
		Vector3DDouble result;
		Vector3DDouble shiftedPosition  = position - cameraVal.position();
		result.setX(shiftedPosition.dot(cameraVal.right()));
		result.setY(shiftedPosition.dot(cameraVal.up()));	

		//Represents the depth
		result.setZ(((position - (cameraVal.position() + cameraVal.right()*result.x() + cameraVal.up()*result.y())).length()));

		/*result.x() *= m_fZoom;
		result.y() *= m_fZoom;*/
		//result.setX(result.x() * camera().zoom());
		//result.setY(result.y() * camera().zoom());

		/*result.x() += imageVal.width() / 2.0f;
		result.y() += imageVal.height() / 2.0f;*/

		result.setX(result.x() + (imageVal.width() / 2.0f));
		result.setY(result.y() + (imageVal.height() / 2.0f));

		//THERMITE_LOG_DEBUG << x << " " << y << std::endl;
		return result;
	}

	Polygon<double> ScanlineRenderer::clip(Polygon<double> polygon)
	{
		Polygon<double> result;
        result = clipAgainstLeft(polygon,2.0f);
        result = clipAgainstRight(result,imageVal.width()-2);
        result = clipAgainstBottom(result,2.0f);
        result = clipAgainstTop(result,imageVal.height()-2);
		return result;
	}

        Polygon<double> ScanlineRenderer::clipAgainstLeft(Polygon<double> polygon, const double boundaryPos)
    {
        //Check it's not empty
        if(polygon.noOfVertices() == 0)
        {
            return polygon;
        }

        Polygon<double> result;		
        bool previousInside;
        bool currentInside;

        //Clip against left
        Polygon<double>::Iterator current = polygon.firstVertex();
        Polygon<double>::Iterator previous = current;
        --previous;

        do 
        {
            //Check if current and previous vertices are inside.
            currentInside = (current->x() > boundaryPos)? true:false;
            previousInside = (previous->x() > boundaryPos)? true:false;

            //Check the inside/outside combination
            if((currentInside == true) && (previousInside == true))
            {
                result.appendVertex(*current);
            }
            else if((currentInside == false) && (previousInside == true))
            {
                double dydx = (current->y() - previous->y())
                    / (current->x() - previous->x());

                double dzdx = (current->z() - previous->z())
                    / (current->x() - previous->x());

                double dx = boundaryPos - previous->x();
                Vector3DDouble pos = (*previous) + Vector3DDouble(dx,dx*dydx,dx*dzdx);

                result.appendVertex(pos);
            }
            else if((currentInside == false) && (previousInside == false))
            {
                //Do nothing
            }
            else if((currentInside == true) && (previousInside == false))
            {
                double dydx = (current->y() - previous->y())
                    / (current->x() - previous->x());

                double dzdx = (current->z() - previous->z())
                    / (current->x() - previous->x());

                double dx = boundaryPos - previous->x();

                Vector3DDouble pos = (*previous) + Vector3DDouble(dx,dx*dydx,dx*dzdx);
                result.appendVertex(pos);
                result.appendVertex(*current);
            }

            //current = current->m_pNext;
            ++current;
            ++previous;
        } while(current != polygon.firstVertex());

        return result;
    }

        Polygon<double> ScanlineRenderer::clipAgainstRight(Polygon<double> polygon, const double boundaryPos)
    {
        //Check it's not empty
        if(polygon.noOfVertices() == 0)
        {
            return polygon;
        }

        Polygon<double> result;		
        bool previousInside;
        bool currentInside;

        //Clip against left
        Polygon<double>::Iterator current = polygon.firstVertex();
        Polygon<double>::Iterator previous = current;
        --previous;

        do 
        {
            //Check if current and previous vertices are inside.
            currentInside = (current->x() < boundaryPos)? true:false;
            previousInside = (previous->x() < boundaryPos)? true:false;

            //Check the inside/outside combination
            if((currentInside == true) && (previousInside == true))
            {
                result.appendVertex(*current);
            }
            else if((currentInside == false) && (previousInside == true))
            {
                double dydx = (current->y() - previous->y())
                    / (current->x() - previous->x());

                double dzdx = (current->z() - previous->z())
                    / (current->x() - previous->x());

                double dx = boundaryPos - previous->x();
                Vector3DDouble pos = (*previous) + Vector3DDouble(dx,dx*dydx,dx*dzdx);

                result.appendVertex(pos);
            }
            else if((currentInside == false) && (previousInside == false))
            {
                //Do nothing
            }
            else if((currentInside == true) && (previousInside == false))
            {
                double dydx = (current->y() - previous->y())
                    / (current->x() - previous->x());

                double dzdx = (current->z() - previous->z())
                    / (current->x() - previous->x());

                double dx = boundaryPos - previous->x();

                Vector3DDouble pos = (*previous) + Vector3DDouble(dx,dx*dydx,dx*dzdx);
                result.appendVertex(pos);
                result.appendVertex(*current);
            }

            //current = current->m_pNext;
            ++current;
            ++previous;
        } while(current != polygon.firstVertex());

        return result;
    }

        Polygon<double> ScanlineRenderer::clipAgainstBottom(Polygon<double> polygon, const double boundaryPos)
    {
        //Check it's not empty
        if(polygon.noOfVertices() == 0)
        {
            return polygon;
        }

        Polygon<double> result;		
        bool previousInside;
        bool currentInside;

        //Clip against left
        Polygon<double>::Iterator current = polygon.firstVertex();
        Polygon<double>::Iterator previous = current;
        --previous;

        do 
        {
            //Check if current and previous vertices are inside.
            currentInside = (current->y() > boundaryPos)? true:false;
            previousInside = (previous->y() > boundaryPos)? true:false;

            //Check the inside/outside combination
            if((currentInside == true) && (previousInside == true))
            {
                result.appendVertex(*current);
            }
            else if((currentInside == false) && (previousInside == true))
            {
                double dxdy = (current->x() - previous->x())
                    / (current->y() - previous->y());

                double dzdy = (current->z() - previous->z())
                    / (current->y() - previous->y());

                double dy = boundaryPos - previous->y();
                Vector3DDouble pos = (*previous) + Vector3DDouble(dy*dxdy,dy,dy*dzdy);

                result.appendVertex(pos);
            }
            else if((currentInside == false) && (previousInside == false))
            {
                //Do nothing
            }
            else if((currentInside == true) && (previousInside == false))
            {
                double dxdy = (current->x() - previous->x())
                    / (current->y() - previous->y());

                double dzdy = (current->z() - previous->z())
                    / (current->y() - previous->y());

                double dy = boundaryPos - previous->y();
                Vector3DDouble pos = (*previous) + Vector3DDouble(dy*dxdy,dy,dy*dzdy);

                result.appendVertex(pos);
                result.appendVertex(*current);
            }

            //current = current->m_pNext;
            ++current;
            ++previous;
        } while(current != polygon.firstVertex());

        return result;
    }

    Polygon<double> ScanlineRenderer::clipAgainstTop(Polygon<double> polygon, const double boundaryPos)
    {
        //Check it's not empty
        if(polygon.noOfVertices() == 0)
        {
            return polygon;
        }

        Polygon<double> result;		
        bool previousInside;
        bool currentInside;

        //Clip against left
        Polygon<double>::Iterator current = polygon.firstVertex();
        Polygon<double>::Iterator previous = current;
        --previous;

        do 
        {
            //Check if current and previous vertices are inside.
            currentInside = (current->y() < boundaryPos)? true:false;
            previousInside = (previous->y() < boundaryPos)? true:false;

            //Check the inside/outside combination
            if((currentInside == true) && (previousInside == true))
            {
                result.appendVertex(*current);
            }
            else if((currentInside == false) && (previousInside == true))
            {
                double dxdy = (current->x() - previous->x())
                    / (current->y() - previous->y());

                double dzdy = (current->z() - previous->z())
                    / (current->y() - previous->y());

                double dy = boundaryPos - previous->y();
                Vector3DDouble pos = (*previous) + Vector3DDouble(dy*dxdy,dy,dy*dzdy);

                result.appendVertex(pos);
            }
            else if((currentInside == false) && (previousInside == false))
            {
                //Do nothing
            }
            else if((currentInside == true) && (previousInside == false))
            {
                double dxdy = (current->x() - previous->x())
                    / (current->y() - previous->y());

                double dzdy = (current->z() - previous->z())
                    / (current->y() - previous->y());

                double dy = boundaryPos - previous->y();
                Vector3DDouble pos = (*previous) + Vector3DDouble(dy*dxdy,dy,dy*dzdy);

                result.appendVertex(pos);
                result.appendVertex(*current);
            }

            //current = current->m_pNext;
            ++current;
            ++previous;
        } while(current != polygon.firstVertex());

        return result;
    }
}
