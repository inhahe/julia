#include <algorithm>

#include <boost/timer.hpp>

#include "MarchingCubesTables.hpp"

namespace Thermite
{
    template <typename VoxelType>
        MarchingCubesRenderer<VoxelType>::MarchingCubesRenderer(Thermite::Volume<VoxelType>* pVolume) throw()
        :VolumeRenderer<HardwareRenderer, VoxelType >(pVolume)
    {    
		m_dIsovalue = 1200.0;	
		m_rgbaIsosurface.set(255,0,255,255);
		m_bUseNiceInterpolation = false;
    }

    template <typename VoxelType>
    MarchingCubesRenderer<VoxelType>::~MarchingCubesRenderer() throw()
    {
    }

	template <typename VoxelType>
		const RGBA<uint1>& MarchingCubesRenderer<VoxelType>::isosurfaceColour(void)
	{
		return m_rgbaIsosurface;
	}

	template <typename VoxelType>
		double MarchingCubesRenderer<VoxelType>::isovalue(void)
	{
		return m_dIsovalue;
	}

	template <typename VoxelType>
		void MarchingCubesRenderer<VoxelType>::setIsosurfaceColour(const RGBA<uint1>& rgbaIsosurface)
	{
		m_rgbaIsosurface = rgbaIsosurface;
	}

	template <typename VoxelType>
		void MarchingCubesRenderer<VoxelType>::setIsovalue(double dIsovalue)
	{
		m_dIsovalue = dIsovalue;
	}

	template <typename VoxelType>
	bool MarchingCubesRenderer<VoxelType>::useNiceInterpolation(void)
	{
		return m_bUseNiceInterpolation;
	}

	template <typename VoxelType>
	void MarchingCubesRenderer<VoxelType>::setUseNiceInterpolation(bool bUseNiceInterpolation)
	{
		m_bUseNiceInterpolation = bUseNiceInterpolation;
	}

	template <typename VoxelType>
	void MarchingCubesRenderer<VoxelType>::initialise(void) throw()
	{
		//Call base class
		HardwareRenderer::initialise();

		//Check hardware support
		if(GLEW_VERSION_2_0)
		{
			THERMITE_LOG_INFO << "Found OpenGL 2.0 support.";
		}
		else
		{
			THERMITE_LOG_ERROR << "MarchingCubesRenderer requires OpenGL 2.0 support";
		}

		if(GL_ARB_occlusion_query)
		{
			THERMITE_LOG_INFO << "Found occlusion support.";
		}
		else
		{
			THERMITE_LOG_ERROR << "MarchingCubesRenderer requires occlusion support";
		}

		//Build the vertex buffers
		glGenBuffers(1,&m_uVertexBuffer);
		for(uint4 ct = 0; ct < 256; ++ct)
		{
			m_uNoOfArrayElementsForCell[ct] = 0;
			for(uint4 temp = 0; temp < 45; temp++)
			{
				m_fVertices[ct * 45 + temp] = 0.0;
				m_fNormals[ct * 45 + temp] = 0.0;
			}
			renderTrianglesForCellIndexIntoArrays(ct);			
		}
		glBindBuffer(GL_ARRAY_BUFFER, m_uVertexBuffer);
		glBufferData(GL_ARRAY_BUFFER, 45 * 256 * 2 * sizeof(m_fVertices[0]), 0, GL_STATIC_DRAW);
		//glBufferSubData(GL_ARRAY_BUFFER,0,45 * 256 * sizeof(m_fVertices[0]),m_fVertices);
		uint4 iBuffer = 0;
		for(uint4 iArray = 0; iArray < (256*45); iArray += 3)
		{
			glBufferSubData(GL_ARRAY_BUFFER,iBuffer * sizeof(m_fVertices[0]),3 * sizeof(m_fVertices[0]),m_fVertices + iArray); iBuffer += 3;
			glBufferSubData(GL_ARRAY_BUFFER,iBuffer * sizeof(m_fNormals[0]),3 * sizeof(m_fNormals[0]),m_fNormals + iArray); iBuffer += 3;
		}
	}

    template <typename VoxelType>
    void MarchingCubesRenderer<VoxelType>::render() throw()
    {
		glEnableClientState(GL_NORMAL_ARRAY);
		glEnableClientState(GL_VERTEX_ARRAY);

		boost::timer timerFrame;
		timerFrame.restart();
		
		glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
		glLoadIdentity();							// Reset The Projection Matrix

		// Calculate The Aspect Ratio Of The Window
		double dHalfWidth = camera().width()/2.0;
		double dHalfHeight = camera().height()/2.0;
		glOrtho(-dHalfWidth, dHalfWidth,-dHalfHeight, dHalfHeight,1.0,1024.0);
		glTranslated(0.0,0.0,-500.0);
		//glRotated(45.0,0.7,0.2,0.5);
		Vector3DDouble v3dTarget = camera().position() + camera().forward();

		glMatrixMode(GL_MODELVIEW);						// Select The Modelview Matrix
		glLoadIdentity();

		GLfloat LightAmbient[]= { 0.1f, 0.1f, 0.1f, 1.0f };
		GLfloat LightDiffuse[]= { 0.9f, 0.9f, 0.9f, 1.0f };
		GLfloat LightPosition[]= { 0.0f, 0.0f, 0.0f, 1.0f };	

		glLightfv(GL_LIGHT1, GL_AMBIENT, LightAmbient);	
		glLightfv(GL_LIGHT1, GL_DIFFUSE, LightDiffuse);
		glLightfv(GL_LIGHT1, GL_POSITION,LightPosition);
		glEnable(GL_LIGHT1);
		glEnable(GL_LIGHTING);

		gluLookAt(camera().position().x(),camera().position().y(),camera().position().z(),
			v3dTarget.x(),v3dTarget.y(),v3dTarget.z(),
			camera().up().x(),camera().up().y(),camera().up().z());			

		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		glEnable(GL_DEPTH_TEST);

		glEnable(GL_NORMALIZE);

		glEnable(GL_COLOR_MATERIAL);		

		

		THERMITE_LOG_DEBUG << "Color is " << m_rgbaIsosurface;
		glColor3ub(m_rgbaIsosurface.red(),m_rgbaIsosurface.green(),m_rgbaIsosurface.blue());

		if(m_bUseNiceInterpolation)
		{
			renderLinearInterpolation();
		}
		else
		{
			renderNearestInterpolation();
		}

		GLenum error;
		do
		{
			error = glGetError();
			const GLubyte* errorString = gluErrorString(error);
			THERMITE_LOG_DEBUG << "Error Status was: " << errorString;
		}
		while(error != GL_NO_ERROR);

		
		THERMITE_LOG_DEBUG << "MarchingCubesRenderer: Frame rendered in " << timerFrame.elapsed() << " seconds";
	}

	template <typename VoxelType>
		void MarchingCubesRenderer<VoxelType>::renderTrianglesForCellIndexIntoArrays(uint1 uCellIndex)
	{
		//const uint4 uStart = uCellIndex * 45;

		Vector3DDouble vertlist[12];

		/* Cube is entirely in/out of the surface */
		if (edgeTable[uCellIndex] == 0)
		{
			return;
		}

		/* Find the vertices where the surface intersects the cube */
		if (edgeTable[uCellIndex] & 1)
		{
			vertlist[0].setX(0.5);
			vertlist[0].setY(0.0);
			vertlist[0].setZ(0.0);
		}
		if (edgeTable[uCellIndex] & 2)
		{
			vertlist[1].setX(1.0);
			vertlist[1].setY(0.5);
			vertlist[1].setZ(0.0);
		}
		if (edgeTable[uCellIndex] & 4)
		{
			vertlist[2].setX(0.5);
			vertlist[2].setY(1.0);
			vertlist[2].setZ(0.0);
		}
		if (edgeTable[uCellIndex] & 8)
		{
			vertlist[3].setX(0.0);
			vertlist[3].setY(0.5);
			vertlist[3].setZ(0.0);
		}
		if (edgeTable[uCellIndex] & 16)
		{
			vertlist[4].setX(0.5);
			vertlist[4].setY(0.0);
			vertlist[4].setZ(1.0);
		}
		if (edgeTable[uCellIndex] & 32)
		{
			vertlist[5].setX(1.0);
			vertlist[5].setY(0.5);
			vertlist[5].setZ(1.0);
		}
		if (edgeTable[uCellIndex] & 64)
		{
			vertlist[6].setX(0.5);
			vertlist[6].setY(1.0);
			vertlist[6].setZ(1.0);
		}
		if (edgeTable[uCellIndex] & 128)
		{
			vertlist[7].setX(0.0);
			vertlist[7].setY(0.5);
			vertlist[7].setZ(1.0);
		}
		if (edgeTable[uCellIndex] & 256)
		{
			vertlist[8].setX(0.0);
			vertlist[8].setY(0.0);
			vertlist[8].setZ(0.5);
		}
		if (edgeTable[uCellIndex] & 512)
		{
			vertlist[9].setX(1.0);
			vertlist[9].setY(0.0);
			vertlist[9].setZ(0.5);
		}
		if (edgeTable[uCellIndex] & 1024)
		{
			vertlist[10].setX(1.0);
			vertlist[10].setY(1.0);
			vertlist[10].setZ(0.5);
		}
		if (edgeTable[uCellIndex] & 2048)
		{
			vertlist[11].setX(0.0);
			vertlist[11].setY(1.0);
			vertlist[11].setZ(0.5);
		}


		//glBegin(GL_TRIANGLES);
		uint4 uNormalIndex = 0;
		uint4 uVertexIndex = 0;
		for (int i=0;triTable[uCellIndex][i]!=-1;i+=3)
		{
			Vector3DDouble v0 = vertlist[triTable[uCellIndex][i  ]];
			Vector3DDouble v1 = vertlist[triTable[uCellIndex][i+1]];
			Vector3DDouble v2 = vertlist[triTable[uCellIndex][i+2]];
			Vector3DDouble normal = (v1 - v0).cross(v1 - v2);

			/*glNormal3f(normal.x(),normal.y(),normal.z());
			glVertex3f(v0.x(),v0.y(),v0.z());
			glVertex3f(v1.x(),v1.y(),v1.z());
			glVertex3f(v2.x(),v2.y(),v2.z());*/
			

			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.x(); uNormalIndex++;
			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.y(); uNormalIndex++;
			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.z(); uNormalIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v0.x(); uVertexIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v0.y(); uVertexIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v0.z(); uVertexIndex++;

			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.x(); uNormalIndex++;
			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.y(); uNormalIndex++;
			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.z(); uNormalIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v1.x(); uVertexIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v1.y(); uVertexIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v1.z(); uVertexIndex++;

			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.x(); uNormalIndex++;
			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.y(); uNormalIndex++;
			m_fNormals[uCellIndex * 45 + uNormalIndex] = normal.z(); uNormalIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v2.x(); uVertexIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v2.y(); uVertexIndex++;
			m_fVertices[uCellIndex * 45 + uVertexIndex] = v2.z(); uVertexIndex++;

			m_uNoOfArrayElementsForCell[uCellIndex] += 9;
		}
		//glEnd();
	}	

	template <typename VoxelType>
		void MarchingCubesRenderer<VoxelType>::renderLinearInterpolation(void) throw()
	{
		//This method requires a LinearVolume
		LinearVolume<VoxelType>* pLinearVolume = dynamic_cast<LinearVolume<VoxelType>*>(m_pVolume);
		if(pLinearVolume == 0)
		{
			THERMITE_LOG_ERROR << "MarchingCubesRenderer: Failed to cast Volume* to LinearVolume*";
			return;
		}
		uint4 uBegin = 0;
		uint4 uEnd = 0;
		m_vecNodesToProcess[uEnd] = 0;
		++uEnd;
		while(uBegin != uEnd)
		{
			const uint4 uCurrentNode = m_vecNodesToProcess[uBegin];
			++uBegin;
			const OctreeNode<VoxelType>& nodeCurrent = pLinearVolume->octree().nodeAt(uCurrentNode);
			if((nodeCurrent.maxVoxelValue() < m_dIsovalue) || (nodeCurrent.minVoxelValue() > m_dIsovalue))
			{
				continue;
			}

			if(nodeCurrent.isLeaf() == false)
			{
				uint4 uBase = 8 * uCurrentNode;
				m_vecNodesToProcess[uEnd] = (uBase + 1);
				m_vecNodesToProcess[uEnd+1] = (uBase + 2);
				m_vecNodesToProcess[uEnd+2] = (uBase + 3);
				m_vecNodesToProcess[uEnd+3] = (uBase + 4);
				m_vecNodesToProcess[uEnd+4] = (uBase + 5);
				m_vecNodesToProcess[uEnd+5] = (uBase + 6);
				m_vecNodesToProcess[uEnd+6] = (uBase + 7);
				m_vecNodesToProcess[uEnd+7] = (uBase + 8);

				uEnd += 8;
			}
			else
			{
				//uStart is the first voxel of the first cell
				uint4 uStartX = nodeCurrent.minPosition().x();
				uint4 uStartY = nodeCurrent.minPosition().y();
				uint4 uStartZ = nodeCurrent.minPosition().z();

				//uEnd is the last voxel of the last cell
				uint4 uEndX = nodeCurrent.maxPosition().x();
				uint4 uEndY = nodeCurrent.maxPosition().y();
				uint4 uEndZ = nodeCurrent.maxPosition().z();			

				uStartX = (std::max)(uint4(0),uStartX);
				uStartY = (std::max)(uint4(0),uStartY);
				uStartZ = (std::max)(uint4(0),uStartZ);

				uEndX = (std::min)(pLinearVolume->width()-1, uEndX);
				uEndY = (std::min)(pLinearVolume->height()-1, uEndY);
				uEndZ = (std::min)(pLinearVolume->depth()-1, uEndZ);

				//THERMITE_LOG_DEBUG << "Rendering Node: Start = " << Vector3DUint4(uStartX,uStartY,uStartZ) << ", End = " << Vector3DUint4(uEndX,uEndY,uEndZ);

				int iCubeIndex;
				Vector3DDouble vertlist[12];

				const uint4 uWidth = pLinearVolume->width();
				const uint4 uWidthTimesHeight = pLinearVolume->width() * pLinearVolume->height();	

				glBegin(GL_TRIANGLES);
				for(uint4 z = uStartZ; z < uEndZ; ++z)
				{
					for(uint4 y = uStartY; y < uEndY; ++y)
					{			
						const VoxelType* v000 = &(pLinearVolume->voxelAt(Vector3DUint4(uStartX,y,z)));
						for(uint4 x = uStartX; x < uEndX; ++x, ++v000)
						{						
							const VoxelType* v100 = v000 + 1;
							const VoxelType* v010 = v000 + uWidth;
							const VoxelType* v110 = v010 + 1;
							const VoxelType* v001 = v000 + uWidthTimesHeight;
							const VoxelType* v101 = v001 + 1;
							const VoxelType* v011 = v001 + uWidth;
							const VoxelType* v111 = v011 + 1;

							/*
							Determine the index into the edge table which
							tells us which vertices are inside of the surface
							*/
							iCubeIndex = 0;
							if (*v000 < m_dIsovalue) iCubeIndex |= 1;
							if (*v100 < m_dIsovalue) iCubeIndex |= 2;
							if (*v110 < m_dIsovalue) iCubeIndex |= 4;
							if (*v010 < m_dIsovalue) iCubeIndex |= 8;
							if (*v001 < m_dIsovalue) iCubeIndex |= 16;
							if (*v101 < m_dIsovalue) iCubeIndex |= 32;
							if (*v111 < m_dIsovalue) iCubeIndex |= 64;
							if (*v011 < m_dIsovalue) iCubeIndex |= 128;

							/* Cube is entirely in/out of the surface */
							if (edgeTable[iCubeIndex] == 0)
							{
								continue;
							}

							/* Find the vertices where the surface intersects the cube */
							if (edgeTable[iCubeIndex] & 1)
							{
								vertlist[0].setX(static_cast<double>(x) + linearInterpolation(*v000,*v100));
								vertlist[0].setY(static_cast<double>(y));
								vertlist[0].setZ(static_cast<double>(z));
							}
							if (edgeTable[iCubeIndex] & 2)
							{
								vertlist[1].setX(static_cast<double>(x + 1));
								vertlist[1].setY(static_cast<double>(y) + linearInterpolation(*v100,*v110));
								vertlist[1].setZ(static_cast<double>(z));
							}
							if (edgeTable[iCubeIndex] & 4)
							{
								vertlist[2].setX(static_cast<double>(x) + linearInterpolation(*v010,*v110));
								vertlist[2].setY(static_cast<double>(y + 1));
								vertlist[2].setZ(static_cast<double>(z));
							}
							if (edgeTable[iCubeIndex] & 8)
							{
								vertlist[3].setX(static_cast<double>(x));
								vertlist[3].setY(static_cast<double>(y) + linearInterpolation(*v000,*v010));
								vertlist[3].setZ(static_cast<double>(z));
							}
							if (edgeTable[iCubeIndex] & 16)
							{
								vertlist[4].setX(static_cast<double>(x) + linearInterpolation(*v001,*v101));
								vertlist[4].setY(static_cast<double>(y));
								vertlist[4].setZ(static_cast<double>(z + 1));
							}
							if (edgeTable[iCubeIndex] & 32)
							{
								vertlist[5].setX(static_cast<double>(x + 1));
								vertlist[5].setY(static_cast<double>(y) + linearInterpolation(*v101,*v111));
								vertlist[5].setZ(static_cast<double>(z + 1));
							}
							if (edgeTable[iCubeIndex] & 64)
							{
								vertlist[6].setX(static_cast<double>(x) + linearInterpolation(*v011,*v111));
								vertlist[6].setY(static_cast<double>(y + 1));
								vertlist[6].setZ(static_cast<double>(z + 1));
							}
							if (edgeTable[iCubeIndex] & 128)
							{
								vertlist[7].setX(static_cast<double>(x));
								vertlist[7].setY(static_cast<double>(y) + linearInterpolation(*v001,*v011));
								vertlist[7].setZ(static_cast<double>(z + 1));
							}
							if (edgeTable[iCubeIndex] & 256)
							{
								vertlist[8].setX(static_cast<double>(x));
								vertlist[8].setY(static_cast<double>(y));
								vertlist[8].setZ(static_cast<double>(z) + linearInterpolation(*v000,*v001));
							}
							if (edgeTable[iCubeIndex] & 512)
							{
								vertlist[9].setX(static_cast<double>(x + 1));
								vertlist[9].setY(static_cast<double>(y));
								vertlist[9].setZ(static_cast<double>(z) + linearInterpolation(*v100,*v101));
							}
							if (edgeTable[iCubeIndex] & 1024)
							{
								vertlist[10].setX(static_cast<double>(x + 1));
								vertlist[10].setY(static_cast<double>(y + 1));
								vertlist[10].setZ(static_cast<double>(z) + linearInterpolation(*v110,*v111));
							}
							if (edgeTable[iCubeIndex] & 2048)
							{
								vertlist[11].setX(static_cast<double>(x));
								vertlist[11].setY(static_cast<double>(y + 1));
								vertlist[11].setZ(static_cast<double>(z) + linearInterpolation(*v010,*v011));
							}
								
							for (int i=0;triTable[iCubeIndex][i]!=-1;i+=3)
							{
								const Vector3DDouble& vertex0 = vertlist[triTable[iCubeIndex][i  ]];
								const Vector3DDouble& vertex1 = vertlist[triTable[iCubeIndex][i+1]];
								const Vector3DDouble& vertex2 = vertlist[triTable[iCubeIndex][i+2]];

								double vx = vertex1.x() - vertex0.x();
								double vy = vertex1.y() - vertex0.y();
								double vz = vertex1.z() - vertex0.z();

								double wx = vertex1.x() - vertex2.x();
								double wy = vertex1.y() - vertex2.y();
								double wz = vertex1.z() - vertex2.z();

								double nx = vy*wz-vz*wy;
								double ny = vz*wx-vx*wz;
								double nz = vx*wy-vy*wx;

								glNormal3f(nx,ny,nz);
								glVertex3f(vertex0.x(),vertex0.y(),vertex0.z());
								glVertex3f(vertex1.x(),vertex1.y(),vertex1.z());
								glVertex3f(vertex2.x(),vertex2.y(),vertex2.z());
							}
						}
					}
				}
				glEnd();
			}
		}
	}	

	template <typename VoxelType>
		void MarchingCubesRenderer<VoxelType>::renderNearestInterpolation(void) throw()
	{
		uint4 cubesRendered = 0;
		uint4 trianglesRendered = 0;
		glMatrixMode(GL_MODELVIEW);	

		glBindBuffer(GL_ARRAY_BUFFER, m_uVertexBuffer);
		glVertexPointer(3, GL_FLOAT, 6 * sizeof(m_fVertices[0]), 0);
		glNormalPointer(GL_FLOAT, 6 * sizeof(m_fVertices[0]), (GLvoid*)12);

		GLuint query;				
		glGenOcclusionQueriesNV(1, &query);

		//This method requires a LinearVolume
		LinearVolume<VoxelType>* pLinearVolume = dynamic_cast<LinearVolume<VoxelType>*>(m_pVolume);
		if(pLinearVolume == 0)
		{
			THERMITE_LOG_ERROR << "MarchingCubesRenderer: Failed to cast Volume* to LinearVolume*";
			return;
		}		

		uint4 uBegin = 0;
		uint4 uEnd = 0;
		m_vecNodesToProcess[uEnd] = 0;
		++uEnd;
		while(uBegin != uEnd)
		{
			const uint4 uCurrentNode = m_vecNodesToProcess[uBegin];
			++uBegin;
			const OctreeNode<VoxelType>& nodeCurrent = pLinearVolume->octree().nodeAt(uCurrentNode);

			/*glColor3f(1.0,0.0,0.0);
			glPolygonMode(GL_FRONT, GL_LINE);
			glPolygonMode(GL_BACK, GL_LINE);
			
			renderOctreeNodeAsBox(nodeCurrent);	
			glColor3f(0.0,0.0,1.0);*/

			if((nodeCurrent.maxVoxelValue() < m_dIsovalue) || (nodeCurrent.minVoxelValue() > m_dIsovalue))
			{
				continue;
			}

			//If it's invisible, don't render it
			glDepthMask(GL_FALSE);
			glColorMask(GL_FALSE,GL_FALSE,GL_FALSE,GL_FALSE);

			glBeginQueryARB(GL_SAMPLES_PASSED_ARB, query);
			renderOctreeNodeAsBox(nodeCurrent);
			glEndQueryARB(GL_SAMPLES_PASSED_ARB);

			GLuint pixelCount;
			glGetQueryObjectuivARB(query, GL_QUERY_RESULT_ARB, &pixelCount);

			glDepthMask(GL_TRUE);
			glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);

			if (pixelCount == 0) 
			{
				continue;
			}

			if(nodeCurrent.isLeaf() == false)
			{
				uint4 uBase = 8 * uCurrentNode;
				m_vecNodesToProcess[uEnd] = (uBase + 1);
				m_vecNodesToProcess[uEnd+1] = (uBase + 2);
				m_vecNodesToProcess[uEnd+2] = (uBase + 3);
				m_vecNodesToProcess[uEnd+3] = (uBase + 4);
				m_vecNodesToProcess[uEnd+4] = (uBase + 5);
				m_vecNodesToProcess[uEnd+5] = (uBase + 6);
				m_vecNodesToProcess[uEnd+6] = (uBase + 7);
				m_vecNodesToProcess[uEnd+7] = (uBase + 8);

				uEnd += 8;
			}
			else
			{
				//uStart is the first voxel of the first cell
				uint4 uStartX = nodeCurrent.minPosition().x();
				uint4 uStartY = nodeCurrent.minPosition().y();
				uint4 uStartZ = nodeCurrent.minPosition().z();

				//uEnd is the last voxel of the last cell
				uint4 uEndX = nodeCurrent.maxPosition().x();
				uint4 uEndY = nodeCurrent.maxPosition().y();
				uint4 uEndZ = nodeCurrent.maxPosition().z();			

				uStartX = (std::max)(uint4(0),uStartX);
				uStartY = (std::max)(uint4(0),uStartY);
				uStartZ = (std::max)(uint4(0),uStartZ);

				uEndX = (std::min)(pLinearVolume->width()-1, uEndX);
				uEndY = (std::min)(pLinearVolume->height()-1, uEndY);
				uEndZ = (std::min)(pLinearVolume->depth()-1, uEndZ);

				//THERMITE_LOG_DEBUG << "Rendering Node: Start = " << Vector3DUint4(uStartX,uStartY,uStartZ) << ", End = " << Vector3DUint4(uEndX,uEndY,uEndZ);

				int iCubeIndex;
				Vector3DDouble vertlist[12];

				const uint4 uWidth = pLinearVolume->width();
				const uint4 uWidthTimesHeight = pLinearVolume->width() * pLinearVolume->height();	

				

				for(uint4 z = uStartZ; z < uEndZ; ++z)
				{
					for(uint4 y = uStartY; y < uEndY; ++y)
					{			
						const VoxelType* v000 = &(pLinearVolume->voxelAt(Vector3DUint4(uStartX,y,z)));
						for(uint4 x = uStartX; x < uEndX; ++x, ++v000)
						{						
							const VoxelType* v100 = v000 + 1;
							const VoxelType* v010 = v000 + uWidth;
							const VoxelType* v110 = v010 + 1;
							const VoxelType* v001 = v000 + uWidthTimesHeight;
							const VoxelType* v101 = v001 + 1;
							const VoxelType* v011 = v001 + uWidth;
							const VoxelType* v111 = v011 + 1;

							/*
							Determine the index into the edge table which
							tells us which vertices are inside of the surface
							*/
							iCubeIndex = 0;
							if (*v000 < m_dIsovalue) iCubeIndex |= 1;
							if (*v100 < m_dIsovalue) iCubeIndex |= 2;
							if (*v110 < m_dIsovalue) iCubeIndex |= 4;
							if (*v010 < m_dIsovalue) iCubeIndex |= 8;
							if (*v001 < m_dIsovalue) iCubeIndex |= 16;
							if (*v101 < m_dIsovalue) iCubeIndex |= 32;
							if (*v111 < m_dIsovalue) iCubeIndex |= 64;
							if (*v011 < m_dIsovalue) iCubeIndex |= 128;

							/* Cube is entirely in/out of the surface */
							if ((edgeTable[iCubeIndex] == 0))
							{
								continue;
							}

							
							//glLoadIdentity();
							glPushMatrix();
							glTranslatef(x,y,z);
							glDrawArrays(GL_TRIANGLES, iCubeIndex * 15, m_uNoOfArrayElementsForCell[iCubeIndex]/3);
							glPopMatrix();

							cubesRendered++;
							trianglesRendered += m_uNoOfArrayElementsForCell[iCubeIndex]/9;

							/*glBegin(GL_TRIANGLES);
							uint4 ct = 0;
							while(ct < m_uNoOfArrayElementsForCell[iCubeIndex])
							{
								if((m_fNormals[iCubeIndex * 45 + ct]* camera().forward().x() + m_fNormals[iCubeIndex * 45 + ct+1]* camera().forward().y() + m_fNormals[iCubeIndex * 45 + ct+2]* camera().forward().z()) > 0.0)
								{
									glNormal3f(m_fNormals[iCubeIndex * 45 + ct],m_fNormals[iCubeIndex * 45 + ct+1],m_fNormals[iCubeIndex * 45 + ct+2]);
									glVertex3f(m_fVertices[iCubeIndex * 45 + ct],m_fVertices[iCubeIndex * 45 + ct+1],m_fVertices[iCubeIndex * 45 + ct+2]);
									ct+= 3;
									glVertex3f(m_fVertices[iCubeIndex * 45 + ct],m_fVertices[iCubeIndex * 45 + ct+1],m_fVertices[iCubeIndex * 45 + ct+2]);
									ct+= 3;
									glVertex3f(m_fVertices[iCubeIndex * 45 + ct],m_fVertices[iCubeIndex * 45 + ct+1],m_fVertices[iCubeIndex * 45 + ct+2]);
									ct+= 3;
								}
								else
								{
									ct += 9;
								}
							}
							glEnd();*/
						}
					}
				}
			}
		}

		THERMITE_LOG_DEBUG << "Rendered " << cubesRendered << " cubes and " << trianglesRendered << " triangles";
	}

	template <typename VoxelType>
	double MarchingCubesRenderer<VoxelType>::linearInterpolation(double v1, double v2)
	{
		return (m_dIsovalue - v1)/(v2 - v1);
	}

	template <typename VoxelType>
	void MarchingCubesRenderer<VoxelType>::renderOctreeNodeAsBox(const OctreeNode<VoxelType>& nodeToRender)
	{
		const Vector3DFloat v3dMin = static_cast<Vector3DFloat>(nodeToRender.minPosition());
		const Vector3DFloat v3dMax = static_cast<Vector3DFloat>(nodeToRender.maxPosition());

		const Vector3DFloat v3dDiff = v3dMax - v3dMin;

		//glLoadIdentity();

		glPushMatrix();

		glTranslatef(v3dMin.x(),v3dMin.y(),v3dMin.z());
		glScalef(v3dDiff.x(),v3dDiff.y(),v3dDiff.z());
		

		//Cube sides face outwards by counter-clockwise
		glBegin(GL_QUADS);

		glVertex3f(0.0f,0.0f,1.0f);
		glVertex3f(1.0f,0.0f,1.0f);
		glVertex3f(1.0f,1.0f,1.0f);
		glVertex3f(0.0f,1.0f,1.0f);

		glVertex3f(0.0f,1.0f,0.0f);
		glVertex3f(1.0f,1.0f,0.0f);
		glVertex3f(1.0f,0.0f,0.0f);
		glVertex3f(0.0f,0.0f,0.0f);

		glVertex3f(1.0f,0.0f,1.0f);
		glVertex3f(1.0f,0.0f,0.0f);
		glVertex3f(1.0f,1.0f,0.0f);
		glVertex3f(1.0f,1.0f,1.0f);

		glVertex3f(0.0f,1.0f,1.0f);
		glVertex3f(0.0f,1.0f,0.0f);
		glVertex3f(0.0f,0.0f,0.0f);
		glVertex3f(0.0f,0.0f,1.0f);

		glVertex3f(0.0f,1.0f,1.0f);
		glVertex3f(1.0f,1.0f,1.0f);
		glVertex3f(1.0f,1.0f,0.0f);
		glVertex3f(0.0f,1.0f,0.0f);

		glVertex3f(0.0f,0.0f,0.0f);
		glVertex3f(1.0f,0.0f,0.0f);
		glVertex3f(1.0f,0.0f,1.0f);
		glVertex3f(0.0f,0.0f,1.0f);

		glEnd();

		glPopMatrix();
	}
}
