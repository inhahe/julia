#ifndef RENDERER_HEADER_INCLUDED
#define RENDERER_HEADER_INCLUDED

#include "..\Base\Typedef.hpp"

#include "Camera.hpp"

namespace Thermite
{
    //The renderer class
    class Renderer
    {
    public:
        Renderer() throw();
        virtual ~Renderer() throw();
        
        Camera& camera() throw();
        const Camera& camera() const throw();

		uint4 width(void);
		uint4 height(void);

		virtual void initialise(void) throw();
        virtual void render(void) throw() = 0;
		virtual void setSize(uint4 uWidth, uint4 uHeight);

    protected:        
        Camera cameraVal;

		uint4 m_uWidth;
		uint4 m_uHeight;
    };
} //namespace Thermite

#endif
