#include "Camera.hpp"
#include "..\Maths\Matrix.hpp"

namespace Thermite
{
    Camera::Camera(const Vector3DDouble& positionValToSet,
        const Vector3DDouble& forwardValToSet,
        const Vector3DDouble& upValToSet,
        const Vector3DDouble& rightValToSet)
        :positionVal(positionValToSet)
        ,forwardVal(forwardValToSet)
        ,upVal(upValToSet)
        ,rightVal(rightValToSet)
		,m_dWidth(256.0)
		,m_dHeight(256.0)
		,m_dDepth(1024.0)
    {
    }

	Camera::Camera()
		:positionVal(Vector3DDouble(0.0,0.0,0.0))
		,forwardVal(Vector3DDouble(0.0,0.0,-1.0))
		,upVal(Vector3DDouble(0.0,1.0,0.0))
		,rightVal(Vector3DDouble(1.0,0.0,0.0))
		,m_dWidth(256.0)
		,m_dHeight(256.0)
		,m_dDepth(1024.0)
	{
	}

    void Camera::setPosition(const Vector3DDouble& positionValToSet) throw()
    {
        positionVal = positionValToSet;
    }

    void Camera::setOrientation(
        const Vector3DDouble& forwardValToSet,
        const Vector3DDouble& upValToSet,
        const Vector3DDouble& rightValToSet) throw()
    {
        forwardVal = forwardValToSet;
        upVal = upValToSet;
        rightVal = rightValToSet;
    }

	void Camera::setWidth(double dWidth)
	{
		m_dWidth = dWidth;
	}

	void Camera::setHeight(double dHeight)
	{
		m_dHeight = dHeight;
	}

	void Camera::setDepth(double dDepth)
	{
		m_dDepth = dDepth;
	}

	void Camera::setExtents(double dWidth, double dHeight, double dDepth)
	{
		m_dWidth = dWidth;
		m_dHeight = dHeight;
		m_dDepth = dDepth;
	}

    const Vector3DDouble& Camera::position(void) const throw()
    {
        return positionVal;
    }

    const Vector3DDouble& Camera::forward(void) const throw()
    {
        return forwardVal;
    }

    const Vector3DDouble& Camera::up(void) const throw()
    {
        return upVal;
    }

    const Vector3DDouble& Camera::right(void) const throw()
    {
        return rightVal;
    }

	double Camera::width(void)
	{
		return m_dWidth;
	}

	double Camera::height(void)
	{
		return m_dHeight;
	}

	double Camera::depth(void)
	{
		return m_dDepth;
	}

    void Camera::lookDown(double angle) throw()
    {
        Matrix3DDouble rotation = create3x3RotationMatrix(rightVal, angle);
        //rotation.rotate(rightVal, angle);
        forwardVal = rotation * forwardVal;
        upVal = rotation * upVal;
		/*forwardVal*= rotation;
		upVal *= rotation;*/
    }

    void Camera::lookUp(double angle) throw()
    {
        Matrix3DDouble rotation = create3x3RotationMatrix(rightVal, -angle);
       // rotation.rotate(rightVal, -angle);

        forwardVal = rotation * forwardVal;
        upVal = rotation * upVal;
    }

    void Camera::lookRight(double angle) throw()
    {
        Matrix3DDouble rotation = create3x3RotationMatrix(upVal, angle);
        //rotation.rotate(upVal, angle);

        forwardVal = rotation * forwardVal;
        rightVal = rotation * rightVal;
		/*forwardVal*= rotation;
		rightVal *= rotation;*/
    }

    void Camera::lookLeft(double angle) throw()
    {
        Matrix3DDouble rotation = create3x3RotationMatrix(upVal, -angle);
        //rotation.rotate(upVal, -angle);

        forwardVal = rotation * forwardVal;
        rightVal = rotation * rightVal;
		/*forwardVal*= rotation;
		rightVal *= rotation;*/
    }
}
