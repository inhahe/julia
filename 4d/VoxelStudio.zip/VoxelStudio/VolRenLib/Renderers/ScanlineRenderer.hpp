#ifndef SCANLINERENDERER_HEADER_INCLUDED
#define SCANLINERENDERER_HEADER_INCLUDED

#include <list>
#include <vector>

#include "..\Images\RGBA.hpp"
#include "..\Base\Typedef.hpp"
#include "..\Maths\Polygon.hpp"
#include "SoftwareRenderer.hpp"

namespace Thermite
{
	class  ScanlineRenderer : public SoftwareRenderer
	{
	public:
		ScanlineRenderer() throw();
		virtual ~ScanlineRenderer() throw();

		virtual void render(void) throw();
		void setSize(uint4 uWidth, uint4 uHeight);
		void addPolygon(const Polygon< double >& polygon);
		Vector3DDouble imageSpacePosition(const Vector3DDouble& position);
		const Image<double>& depthImage() const throw();
	protected:
		std::vector< Polygon< double > > m_polygons;

		Polygon<double> clip(Polygon<double> polygon);
        //FIXME - templatize clipAgainst*() functions- -they are very similar...
        Polygon<double> clipAgainstLeft(Polygon<double> polygon, const double boundaryPos);
        Polygon<double> clipAgainstRight(Polygon<double> polygon, const double boundaryPos);
        Polygon<double> clipAgainstBottom(Polygon<double> polygon, const double boundaryPos);
        Polygon<double> clipAgainstTop(Polygon<double> polygon, const double boundaryPos);
		void renderConvexPolygon(Polygon< double > vertices);
		void drawConvexPolygon(Polygon< double > polygon);
		void drawHozizontalSpan(uint4 x1, double depth1, uint4 x2, double depth2, uint4 y);

		Thermite::Image<double> m_imgDepth;
	};
}

#endif
