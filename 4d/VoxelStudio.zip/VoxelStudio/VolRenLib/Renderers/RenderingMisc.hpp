#ifndef RENDERINGMISC_HEADER_INCLUDED
#define RENDERINGMISC_HEADER_INCLUDED

#include "..\Base\FwdDecl.hpp"
#include "..\Base\Typedef.hpp"

namespace Thermite
{
	RGBA<uint1> calculatePhongLighting(Vector3DDouble viewAndLightDirection, Vector3DDouble surfaceNormal, RGBA<uint1> surfaceColour, double ambientFactor, double surfaceDiffuseFactor, double surfaceSpecularFactor, double surfaceSpecularExponent);
}

#endif