#include<limits>
#include <queue>

#include "RenderingMisc.hpp"

namespace Thermite
{
    template <typename VoxelType>
        ShadedSurfaceRenderer<VoxelType>::ShadedSurfaceRenderer(Thermite::Volume<VoxelType>* pVolume) throw()
        :VolumeRenderer<SoftwareRenderer, VoxelType >(pVolume)
    {        
		useSobel = false;
		m_dIsovalue = 1400.0;

        m_rendScanline = new ScanlineRenderer;		

        Polygon< double > vertices;
        vertices.appendVertex(Vector3DDouble(0.0f,0.0f,m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),m_pVolume->depth()));
        m_rendScanline->addPolygon(vertices);

        vertices.clear();
        vertices.appendVertex(Vector3DDouble(0.0f,0.0f,0.0f));
        vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),0.0f));		
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),0.0f));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,0.0f));
        m_rendScanline->addPolygon(vertices);

        vertices.clear();
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,0.0f));		
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),0.0f));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),m_pVolume->depth()));
        m_rendScanline->addPolygon(vertices);

        vertices.clear();
        vertices.appendVertex(Vector3DDouble(0.0f,0.0f,m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),0.0f));
        vertices.appendVertex(Vector3DDouble(0.0f,0.0f,0.0f));		
        m_rendScanline->addPolygon(vertices);

        vertices.clear();
        vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),0.0f));
        vertices.appendVertex(Vector3DDouble(0.0f,m_pVolume->height(),m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),m_pVolume->height(),0.0f));		
        m_rendScanline->addPolygon(vertices);

        vertices.clear();
        vertices.appendVertex(Vector3DDouble(0.0f,0.0f,0.0f));
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,0.0f));		
        vertices.appendVertex(Vector3DDouble(m_pVolume->width(),0.0f,m_pVolume->depth()));
        vertices.appendVertex(Vector3DDouble(0.0f,0.0f,m_pVolume->depth()));				
        m_rendScanline->addPolygon(vertices);
    }

    template <typename VoxelType>
    ShadedSurfaceRenderer<VoxelType>::~ShadedSurfaceRenderer() throw()
    {
    }

	template <typename VoxelType>
		const RGBA<uint1>& ShadedSurfaceRenderer<VoxelType>::isosurfaceColour(void)
	{
		return m_rgbaIsosurface;
	}

	template <typename VoxelType>
		double ShadedSurfaceRenderer<VoxelType>::isovalue(void)
	{
		return m_dIsovalue;
	}

	template <typename VoxelType>
		void ShadedSurfaceRenderer<VoxelType>::setIsosurfaceColour(const RGBA<uint1>& rgbaIsosurface)
	{
		m_rgbaIsosurface = rgbaIsosurface;
	}
	template <typename VoxelType>
		void ShadedSurfaceRenderer<VoxelType>::setIsovalue(double dIsovalue)
	{
		m_dIsovalue = dIsovalue;
	}

    template <typename VoxelType>
    void ShadedSurfaceRenderer<VoxelType>::render() throw()
    {
		//Some globalish values.
		const double ambientFactor = 0.3f;
		const double diffuseFactor = 0.6f;
		const double specularFactor = 0.5f;
		const double specularExponent = 20.0f;

        m_rendScanline->camera() = cameraVal;
		//m_rendScanline->zoom() = m_fZoom;
        m_rendScanline->camera().setPosition(m_rendScanline->camera().position() - (cameraVal.forward()*m_pVolume->diagonal()));
        m_rendScanline->render();

		//Camera properties which aren't dependant on position in the image
		const Vector3DDouble dv3dRightTimesHalfWidth = cameraVal.right() * (cameraVal.width() / 2.0);
		const Vector3DDouble dv3dUpTimesHalfHeight = cameraVal.up() * (cameraVal.height() / 2.0);
		const Vector3DDouble dv3dLowerLeftCorner = cameraVal.position()
			- dv3dRightTimesHalfWidth 
			- dv3dUpTimesHalfHeight 
			- (camera().forward() * camera().depth() / 2.0);

		const double dXStepInCameraSpace = cameraVal.width() / static_cast<double>(imageVal.width());
		const double dYStepInCameraSpace = cameraVal.height() / static_cast<double>(imageVal.height());

		//Clear the image
		imageVal.clearTo(RGBA<uint1>(0,0,0,255));

		//For each pixel in the image:
		for(uint4 uImagePosY = 0; uImagePosY < imageVal.height(); ++uImagePosY)
		{        
			for(uint4 uImagePosX = 0; uImagePosX < imageVal.width(); ++uImagePosX)
			{
				//Compute the start position
				double dCameraPosX = dXStepInCameraSpace * static_cast<double>(uImagePosX);
				double dCameraPosY = dYStepInCameraSpace * static_cast<double>(uImagePosY);
				Vector3DDouble rayPosition = dv3dLowerLeftCorner + (cameraVal.right() * dCameraPosX) + (cameraVal.up() * dCameraPosY);
                Vector3DDouble rayDirection = cameraVal.forward();
                rayDirection.normalise();

                /*if(m_rendScanline->depthImage().pixelAt(xPos,yPos) == std::numeric_limits<double>::infinity())
                {
                    continue;
                }
                rayPosition += (rayDirection * m_rendScanline->depthImage().pixelAt(xPos,yPos));*/

                //Skip forward into volume
                for(uint4 ct = 0; ct < 500; ct++)
                {
                    if(m_pVolume->contains(rayPosition,2))
                    {
                        break;
                    }
                    rayPosition += rayDirection;
                }

                //Maybe there was no intersection...
                if(m_pVolume->contains(rayPosition,2) == false)
                {
                    continue;
                }

				//Find the isosurface
				while(m_pVolume->contains(rayPosition,2))
				{
					if(m_pVolume->computeTrilinearlyInterpolatedValueAt(rayPosition) < m_dIsovalue)
					{
						rayPosition += rayDirection;
					}
					else
					{
						break;
					}
				}

				if(m_pVolume->contains(rayPosition,2) == false)
				{
					continue;
				}

				rayDirection *= -0.5f;
				bool previouslyInside = true;    
				for(uint4 ct = 0; ct < 5; ct++)
				{
					//Move ray forward.
					rayPosition += rayDirection;

					//Interpolate and offset. Will be positive if in isosurface, negative if outside
					double interpolatedValue = m_pVolume->computeTrilinearlyInterpolatedValueAt(rayPosition);
					bool inside;
					if(interpolatedValue > m_dIsovalue)
						inside = true;
					else
						inside = false;

					if(inside == previouslyInside)
						rayDirection *= 0.5;
					else
						rayDirection *= -0.5;
					previouslyInside = inside;
				}

				//Do the lighting
				Vector3DDouble normal;                

				if(useSobel)
				{
					normal = m_pVolume->computeTrilinearlyInterpolatedSobelGradientAt(rayPosition);
				}
				else
				{
					normal = m_pVolume->computeTrilinearlyInterpolatedCentralDifferenceGradientAt(rayPosition);
				}               

				normal.normalise();

				if(uImagePosX == uImagePosY)
				{
					THERMITE_LOG_DEBUG << uImagePosY << " = " <<computeCurvatureAt(rayPosition);
				}

				/*if(computeCurvatureAt(rayPosition) > 0.1)
				{
					m_rgbaIsosurface.set(255,0,0,255);
				}
				else
				{
					m_rgbaIsosurface.set(0,255,0,255);
				}*/

				RGBA<uint1> finalColour = calculatePhongLighting(cameraVal.forward(),normal,m_rgbaIsosurface,ambientFactor,diffuseFactor,specularFactor,specularExponent);
				imageVal.pixelAt(uImagePosX,uImagePosY) = finalColour;
            }
        }

        //THERMITE_LOG_DEBUG << "Finished Frame" << std::endl;
    }  	

    template <typename VoxelType>
        void ShadedSurfaceRenderer<VoxelType>::setSize(uint4 uWidth, uint4 uHeight)
    {
		VolumeRenderer<SoftwareRenderer, VoxelType>::setSize(uWidth,uHeight);
        m_rendScanline->setSize(uWidth,uHeight);
    }

	template <typename VoxelType>
		double ShadedSurfaceRenderer<VoxelType>::computeCurvatureAt(Vector3DDouble v3dPosition)
	{
		Vector3DUint4 v3dPositionAsUint4 = static_cast<Vector3DUint4>(v3dPosition);
		uint4 x = v3dPositionAsUint4.x();
		uint4 y = v3dPositionAsUint4.y();
		uint4 z = v3dPositionAsUint4.z();

		//Vector3DInt4 v3dCurrentNormal= m_pVolume->computeSobelGradientAt(Vector3DUint4(x,y,z));
		//Vector3DDouble v3dCurrentNormalAsDouble = static_cast<Vector3DDouble>(v3dCurrentNormal);

		Vector3DDouble v3dNormals[27];
		v3dNormals[ 0] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y-1,z-1)));
		v3dNormals[ 1] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y-1,z  )));
		v3dNormals[ 2] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y-1,z+1)));

		v3dNormals[ 3] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y  ,z-1)));
		v3dNormals[ 4] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y  ,z  )));
		v3dNormals[ 5] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y  ,z+1)));

		v3dNormals[ 6] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y+1,z-1)));
		v3dNormals[ 7] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y+1,z  )));
		v3dNormals[ 8] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x-1,y+1,z+1)));


		v3dNormals[ 9] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y-1,z-1)));
		v3dNormals[10] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y-1,z  )));
		v3dNormals[11] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y-1,z+1)));

		v3dNormals[12] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y  ,z-1)));
		v3dNormals[13] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y  ,z  )));
		v3dNormals[14] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y  ,z+1)));

		v3dNormals[15] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y+1,z-1)));
		v3dNormals[16] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y+1,z  )));
		v3dNormals[17] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x  ,y+1,z+1)));


		v3dNormals[18] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y-1,z-1)));
		v3dNormals[19] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y-1,z  )));
		v3dNormals[20] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y-1,z+1)));

		v3dNormals[21] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y  ,z-1)));
		v3dNormals[22] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y  ,z  )));
		v3dNormals[23] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y  ,z+1)));

		v3dNormals[24] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y+1,z-1)));
		v3dNormals[25] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y+1,z  )));
		v3dNormals[26] = static_cast<Vector3DDouble>(m_pVolume->computeSobelGradientAt(Vector3DUint4(x+1,y+1,z+1)));					

		for(uint4 ct = 0; ct < 27; ct++)
		{
			v3dNormals[ct].normalise();
		}

		Vector3DDouble v3dAverageNormal(0.0,0.0,0.0);
		for(uint4 ct = 0; ct < 27; ct++)
		{
			v3dAverageNormal += v3dNormals[ct];
		}
		v3dAverageNormal /= 27.0;

		Vector3DDouble xMinusXBar[27];
		for(uint4 ct = 0; ct < 27; ct++)
		{
			xMinusXBar[ct] = v3dNormals[ct] - v3dAverageNormal;
		}

		Vector3DDouble xMinusXBarSquared[27];
		for(uint4 ct = 0; ct < 27; ct++)
		{
			xMinusXBarSquared[ct].setX(xMinusXBar[ct].x()*xMinusXBar[ct].x());
			xMinusXBarSquared[ct].setY(xMinusXBar[ct].y()*xMinusXBar[ct].y());
			xMinusXBarSquared[ct].setZ(xMinusXBar[ct].z()*xMinusXBar[ct].z());
		}

		Vector3DDouble averageOfXMinusXBarSquared(0.0,0.0,0.0);
		for(uint4 ct = 0; ct < 27; ct++)
		{
			averageOfXMinusXBarSquared += xMinusXBarSquared[ct];
		}
		averageOfXMinusXBarSquared /= 27.0;

		Vector3DDouble standardDeviation;
		standardDeviation.setX(sqrt(averageOfXMinusXBarSquared.x()));
		standardDeviation.setY(sqrt(averageOfXMinusXBarSquared.y()));
		standardDeviation.setZ(sqrt(averageOfXMinusXBarSquared.z()));

		return standardDeviation.x() + standardDeviation.y() + standardDeviation.z();
	}
}
