#ifndef VOLUME_RENDERER_HEADER_INCLUDED
#define VOLUME_RENDERER_HEADER_INCLUDED

#include "HardwareRenderer.hpp"
#include "SoftwareRenderer.hpp"
#include "Volume.hpp"

namespace Thermite
{
    template <typename BaseRendererType, typename VoxelType>
    class VolumeRenderer : public BaseRendererType
    {
    public:
        VolumeRenderer(Thermite::Volume<VoxelType>* pVolume) throw();
        virtual ~VolumeRenderer() throw();

        const Volume<VoxelType>* volume() const throw();

        virtual void render(void) throw() = 0;

    protected:
        Thermite::Volume<VoxelType>* m_pVolume;
    };
} //namespace Thermite

//Some handy typedefs
/*template <typename VoxelType>*/
//typedef VolumeRenderer<SoftwareRenderer,VoxelType> SoftwareVolumeRenderer<VoxelType>;

#include "VolumeRenderer.inl"

#endif
