#ifndef SLICERENDERER_HEADER_INCLUDED
#define SLICERENDERER_HEADER_INCLUDED

#include "..\Base\Typedef.hpp"
#include "..\Images\RGBA.hpp"
#include "VolumeRenderer.hpp"

namespace Thermite
{
	template <typename VoxelType>
    class  SliceRenderer : public VolumeRenderer<SoftwareRenderer, VoxelType>
    {
    public:
        SliceRenderer(Thermite::Volume<VoxelType>* pVolume) throw();
        virtual ~SliceRenderer() throw();        

		const RGBA<uint1>& isosurfaceColour(void);
		double isovalue(void);
		double level(void);
		bool volumeRenderingEnabled(void);
		double window(void);		

		void setInterpolationFilter(ReconstructionFilter* filtInterpolation);
		void setIsosurfaceColour(const RGBA<uint1>& rgbaIsosurface);
		void setIsovalue(double dIsovalue);
		void setLevel(double dLevel);
		void setVolumeRenderingEnabled(bool bEnabled);
		void setWindow(double dWindow);		

		virtual void render(void) throw();

    private:
		bool m_bVolumeRenderingEnabled;

		double m_dIsovalue;
		double m_dLevel;
		double m_dLower;
		double m_dUpper;
        double m_dWindow;

		ReconstructionFilter* m_filtInterpolation;

		RGBA<uint1> m_rgbaIsosurface;
		RGBA<double> m_rgbaIsosurfaceAsDouble;
    };
}

#include "SliceRenderer.inl"

#endif
