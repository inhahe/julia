#ifndef MARCHING_CUBES_ENDOSCOPY_RENDERER_HEADER_INCLUDED
#define MARCHING_CUBES_ENDOSCOPY_RENDERER_HEADER_INCLUDED

#include <list>
#include <vector>

#include "VolumeRenderer.hpp"
#include "..\Base\Typedef.hpp"

//FIXME - enforce constraint that this only works on linear volume? Or generalize?
namespace Thermite
{
    template <typename VoxelType>
    class  MarchingCubesEndoscopyRenderer : public VolumeRenderer<HardwareRenderer, VoxelType>
    {
    public:
        MarchingCubesEndoscopyRenderer(Thermite::Volume<VoxelType>* pVolume) throw();
        virtual ~MarchingCubesEndoscopyRenderer() throw();

		const RGBA<uint1>& isosurfaceColour(void);
		double isovalue(void);
		bool useNiceInterpolation(void);

		void setIsosurfaceColour(const RGBA<uint1>& rgbaIsosurface);
		void setIsovalue(double dIsovalue);
		void setUseNiceInterpolation(bool bUseNiceInterpolation);

		void initialise(void) throw();
        virtual void render(void) throw();

		Vector3DDouble getObjectSpacePosition(uint4 x, uint4 y);

    private:  
		void renderScene(void);
		void identifyNodesInFrustrum() throw();
		void renderOctreeNode(uint4 uNodeToRender) throw();
		void renderTrianglesForCellIndexIntoArrays(uint1 uCellIndex);
		void renderOctreeNodeAsBox(const OctreeNode<VoxelType>& nodeToRender);
		bool isOctreeNodeVisible(const OctreeNode<VoxelType>& nodeToTest);

		GLfloat m_fVertices[11520]; //256*45
		GLfloat m_fNormals[11520]; //256*45

		uint4 m_uNoOfTrianglesRendered;
		uint4 m_uNoOfOcclusionTests;

		uint4 m_uNoOfArrayElementsForCell[256];

		GLuint m_uVertexBuffer;
		GLuint m_uNormalBuffer;

		GLuint m_uQuery;
		GLuint m_uQueries[100];

		double m_dIsovalue;
		RGBA<uint1> m_rgbaIsosurface;

		std::vector< std::pair<uint4, uint4> > vecNodesInFrustum;

		LARGE_INTEGER m_iTimerFreq;

		LinearVolume<VoxelType>* m_pLinearVolume;

		GLuint uVertexShader;
		GLuint uFragmentShader;

		GLubyte uTexture[131072];
    };
}

#include "MarchingCubesEndoscopyRenderer.inl"

#endif
