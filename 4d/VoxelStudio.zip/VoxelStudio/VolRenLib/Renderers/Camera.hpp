#ifndef CAMERA_HEADER_INCLUDED
#define CAMERA_HEADER_INCLUDED


#include "..\Maths\Vector.hpp"

namespace Thermite
{
    class Camera
    {
    public:
        Camera(const Vector3DDouble& positionValToSet,
            const Vector3DDouble& forwardValToSet,
            const Vector3DDouble& upValToSet,
            const Vector3DDouble& rightValToSet);
		Camera();

        void setPosition(const Vector3DDouble& positionValToSet) throw();
        void setOrientation(
            const Vector3DDouble& forwardValToSet,
            const Vector3DDouble& upValToSet,
            const Vector3DDouble& rightValToSet) throw();
		void setWidth(double dWidth);
		void setHeight(double dHeight);
		void setDepth(double dDepth);
		void setExtents(double dWidth, double dHeight, double dDepth);

        const Vector3DDouble& position(void) const throw();
        const Vector3DDouble& forward(void) const throw();
        const Vector3DDouble& up(void) const throw();
        const Vector3DDouble& right(void) const throw();

		double width(void);
		double height(void);
		double depth(void);

        void lookDown(double angle) throw();
        void lookUp(double angle) throw();
        void lookRight(double angle) throw();
        void lookLeft(double angle) throw();

    private:
        Vector3DDouble positionVal;
        Vector3DDouble forwardVal;
        Vector3DDouble upVal;
        Vector3DDouble rightVal;

		double m_dWidth;
		double m_dHeight;
		double m_dDepth;
    };

}//namespace Thermite

#endif
