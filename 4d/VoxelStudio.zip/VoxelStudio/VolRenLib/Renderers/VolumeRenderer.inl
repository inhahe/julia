#include "..\Volumes\LinearVolume.hpp"

namespace Thermite
{
    template <typename BaseRendererType, typename VoxelType>
        VolumeRenderer<BaseRendererType,VoxelType>::VolumeRenderer(Thermite::Volume<VoxelType>* pVolume) throw()
		:m_pVolume(pVolume)
    {
		cameraVal.setPosition(Vector3DDouble(pVolume->width()/2.0f,pVolume->height()/2.0f,pVolume->depth()/2.0f));
    }

    template <typename BaseRendererType, typename VoxelType>
        VolumeRenderer<BaseRendererType, VoxelType>::~VolumeRenderer() throw()
    {
    }

    template <typename BaseRendererType, typename VoxelType>
        const Volume<VoxelType>* VolumeRenderer<BaseRendererType, VoxelType>::volume() const throw()
    {
        return m_pVolume;
    }
} //namespace Thermite
