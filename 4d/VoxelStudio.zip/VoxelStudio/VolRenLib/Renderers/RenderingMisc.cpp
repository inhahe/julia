#include "../Maths/Vector.hpp"
#include "../Images/RGBA.hpp"
#include "RenderingMisc.hpp"

namespace Thermite
{
	RGBA<uint1> calculatePhongLighting(Vector3DDouble viewAndLightDirection, Vector3DDouble surfaceNormal, RGBA<uint1> surfaceColour, double ambientFactor, double surfaceDiffuseFactor, double surfaceSpecularFactor, double surfaceSpecularExponent)
	{
		//Ambient component
		const double ambientIntensity = ambientFactor;

		//Diffuse Component
		const double normalDotLight = (std::max)(0.0, surfaceNormal.dot(viewAndLightDirection));
		const double diffuseIntensity = normalDotLight * surfaceDiffuseFactor;

		//Specular Component
		// Schlick's slick approximation for Phong's specular term:
		// Simply replace Sn(t) = t^n with Sn(t) = t / (n - nt + t).
		const double specularIntensity = ((normalDotLight) / (surfaceSpecularExponent - surfaceSpecularExponent*normalDotLight + normalDotLight)) * surfaceSpecularFactor;

		const double dFinalRed = (ambientIntensity + diffuseIntensity) * surfaceColour.red()  + specularIntensity * 255.0;
		const double dFinalGreen = (ambientIntensity + diffuseIntensity) * surfaceColour.green()  + specularIntensity * 255.0;
		const double dFinalBlue = (ambientIntensity + diffuseIntensity) * surfaceColour.blue()  + specularIntensity * 255.0;

		const uint1 uFinalRed = (std::min)(255.0, dFinalRed);
		const uint1 uFinalGreen = (std::min)(255.0, dFinalGreen);
		const uint1 uFinalBlue = (std::min)(255.0, dFinalBlue);

		return RGBA<uint1>(uFinalRed,uFinalGreen,uFinalBlue,255);
	}
}