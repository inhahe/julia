#include "RenderingMisc.hpp"

namespace Thermite
{
	template <typename VoxelType>
	SliceRenderer<VoxelType>::SliceRenderer(Thermite::Volume<VoxelType>* pVolume) throw()
		:VolumeRenderer<SoftwareRenderer, VoxelType >(pVolume)
		,m_bVolumeRenderingEnabled(false)
		,m_dLower(static_cast<double>(pVolume->minimum()))
		,m_dUpper(static_cast<double>(pVolume->maximum())) 
		,m_dIsovalue(m_dLower + (m_dUpper - m_dLower) / 2.0)
		,m_rgbaIsosurface(1.0f,0.6f,0.55f,1.0f)
		,m_rgbaIsosurfaceAsDouble(convertToRGBADouble(m_rgbaIsosurface))
		,m_filtInterpolation(ReconstructionFilter::createLinearInterpolationFilter())
	{      
	}

	template <typename VoxelType>
	SliceRenderer<VoxelType>::~SliceRenderer() throw()
	{
	}

	template <typename VoxelType>
	const RGBA<uint1>& SliceRenderer<VoxelType>::isosurfaceColour(void)
	{
		return m_rgbaIsosurface;
	}

	template <typename VoxelType>
		double SliceRenderer<VoxelType>::isovalue(void)
	{
		return m_dIsovalue;
	}

	template <typename VoxelType>
	double SliceRenderer<VoxelType>::level(void)
	{
		return m_dLevel;
	}

	template <typename VoxelType>
	bool SliceRenderer<VoxelType>::volumeRenderingEnabled(void)
	{
		return m_bVolumeRenderingEnabled;
	}

	template <typename VoxelType>
	double SliceRenderer<VoxelType>::window(void)
	{
		return m_dWindow;
	}

	template <typename VoxelType>
	void SliceRenderer<VoxelType>::setInterpolationFilter(ReconstructionFilter* filtInterpolation)
	{
		//FIXME - don't pass in by pointer - could cause problems if filters are shared...
		//Or maybe use boost::smart_ptr?
        /*if(m_filtInterpolation != 0)
		{
			delete m_filtInterpolation;
			m_filtInterpolation = 0;
		}*/
		m_filtInterpolation = filtInterpolation;
	}

	template <typename VoxelType>
	void SliceRenderer<VoxelType>::setIsosurfaceColour(const RGBA<uint1>& rgbaIsosurface)
	{
		m_rgbaIsosurface = rgbaIsosurface;
		m_rgbaIsosurfaceAsDouble = convertToRGBADouble(rgbaIsosurface);
	}
	template <typename VoxelType>
		void SliceRenderer<VoxelType>::setIsovalue(double dIsovalue)
	{
		m_dIsovalue = dIsovalue;
	}

	template <typename VoxelType>
		void SliceRenderer<VoxelType>::setLevel(double dLevel)
	{
		m_dLevel = dLevel;

		//Compute the upper and lower bounds.
		m_dUpper = m_dLevel + (m_dWindow / 2.0);
		m_dLower = m_dLevel - (m_dWindow / 2.0);
	}

	template <typename VoxelType>
		void SliceRenderer<VoxelType>::setVolumeRenderingEnabled(bool bEnabled)
	{
		m_bVolumeRenderingEnabled = bEnabled;
	}

	template <typename VoxelType>
	void SliceRenderer<VoxelType>::setWindow(double dWindow)
	{
		m_dWindow = dWindow;

		//Compute the upper and lower bounds.
		m_dUpper = m_dLevel + (m_dWindow / 2.0);
		m_dLower = m_dLevel - (m_dWindow / 2.0);
	}

	template <typename VoxelType>
	void SliceRenderer<VoxelType>::render() throw()
	{		
		//Some globalish values.
		//These should be members...
		const double ambientFactor = 0.3f;
		const double diffuseFactor = 0.6f;
		const double specularFactor = 0.5f;
		const double specularExponent = 20.0f;

		//Camera properties which aren't dependant on position in the image
		const Vector3DDouble dv3dRightTimesHalfWidth = cameraVal.right() * (cameraVal.width() / 2.0);
		const Vector3DDouble dv3dUpTimesHalfHeight = cameraVal.up() * (cameraVal.height() / 2.0);
		const Vector3DDouble dv3dLowerLeftCorner = cameraVal.position() - dv3dRightTimesHalfWidth - dv3dUpTimesHalfHeight;

		const double dXStepInCameraSpace = cameraVal.width() / static_cast<double>(imageVal.width());
		const double dYStepInCameraSpace = cameraVal.height() / static_cast<double>(imageVal.height());

		//Clear the image
		imageVal.clearTo(RGBA<uint1>(0,0,0,255));

		//For each pixel in the image:
		for(uint4 uImagePosY = 0; uImagePosY < imageVal.height(); ++uImagePosY)
		{        
			for(uint4 uImagePosX = 0; uImagePosX < imageVal.width(); ++uImagePosX)
			{
				//Compute the start position
				double dCameraPosX = dXStepInCameraSpace * static_cast<double>(uImagePosX);
				double dCameraPosY = dYStepInCameraSpace * static_cast<double>(uImagePosY);
				Vector3DDouble position = dv3dLowerLeftCorner + (cameraVal.right() * dCameraPosX) + (cameraVal.up() * dCameraPosY);				

				if(m_pVolume->contains(position,2)) //Inside the volume.Border of 2 needed for Catmull-Rom filter.
				{	
					double sample = m_pVolume->applyFilter(position,m_filtInterpolation,m_filtInterpolation,m_filtInterpolation);
					if((m_bVolumeRenderingEnabled == false) || (sample >= m_dIsovalue)) //We don't do volume rendering					
                    {						
                        if(sample < m_dLower)
                        {
                            sample =  0.0;
                        }
                        else if(sample > m_dUpper)
                        {
                            sample =  1.0;
                        }
                        else
                        {
                            sample = (sample - m_dLower)/(m_dUpper - m_dLower);
                        }
						uint1 uSample = sample * 255;
						imageVal.rawData()[uImagePosY * imageVal.width() + uImagePosX] = RGBA<uint1>(uSample,uSample,uSample,255);
                    }
                    else //We do volume rendering
                    {
                        Vector3DDouble rayPosition = position;
                        Vector3DDouble rayDirection = cameraVal.forward();

						//Do space skipping
						while(m_pVolume->contains(rayPosition,1) && (m_pVolume->cellCornersBelowThreshold(rayPosition, m_dIsovalue)))
						{
							rayPosition += rayDirection;
						}

						//Find surface
                        while(m_pVolume->contains(rayPosition,1))
                        {     
                            sample = m_pVolume->computeTrilinearlyInterpolatedValueAt(rayPosition);
                            if(sample >= m_dIsovalue)
                            {
                                Vector3DDouble normal = m_pVolume->computeTrilinearlyInterpolatedCentralDifferenceGradientAt(rayPosition);
                                normal.normalise();
                                /*const Vector3DDouble& lightDirection = cameraVal.forward();

                                //Ambient component
                                const double ambientIntensity = ambientFactor;

                                //Diffuse Component
                                const double normalDotLight = normal.dot(lightDirection);
                                const double diffuseIntensity = (std::max)(normalDotLight, 0.0) * diffuseFactor;

                                //Specular Component
                                // Schlick's slick approximation for Phong's specular term:
                                // Simply replace Sn(t) = t^n with Sn(t) = t / (n - nt + t).
                                const double specularIntensity = ((normalDotLight) / (specularExponent - specularExponent*normalDotLight + normalDotLight)) * specularFactor;

								RGBA<double> rgbaResult(m_rgbaIsosurfaceAsDouble);
								rgbaResult *= ambientIntensity+diffuseIntensity+specularIntensity;
								imageVal.rawData()[uImagePosY * imageVal.width() + uImagePosX] = convertToRGBAUint1(rgbaResult);*/
								/*if((rayPosition.x() > 4.0) && (rayPosition.y() > 4.0) && (rayPosition.z() > 4.0) &&
									(rayPosition.x() < m_pVolume->width()-5.0) && (rayPosition.y() < m_pVolume->height()-5.0) && (rayPosition.z() < m_pVolume->depth()-5.0))
								{
									double dCurvature = m_pVolume->computeCurvatureAt(static_cast<Vector3DUint4>(rayPosition + Vector3DDouble(0.5,0.5,0.5)));
									if(dCurvature <= 0.5)
									{
										m_rgbaIsosurface.set(uint1(dCurvature*2.0*255.0),255,0,255);
									}
									else
									{
										m_rgbaIsosurface.set(255,uint1(255.0-((dCurvature-0.5)*2.0*255.0)),0,255);
									}
								}*/

								RGBA<uint1> finalColour = calculatePhongLighting(cameraVal.forward(),normal,m_rgbaIsosurface,ambientFactor,diffuseFactor,specularFactor,specularExponent);
								imageVal.pixelAt(uImagePosX,uImagePosY) = finalColour;
                                break;
                            }  
							rayPosition += rayDirection;
                        }
                    }                    					
				}              
			}
		}
	}
}
