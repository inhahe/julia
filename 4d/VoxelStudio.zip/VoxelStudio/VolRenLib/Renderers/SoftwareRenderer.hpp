#ifndef SOFTWARERENDERER_HEADER_INCLUDED
#define SOFTWARERENDERER_HEADER_INCLUDED

#include "..\Base\Typedef.hpp"

#include "..\Images\Image.hpp"
#include "..\Images\RGBA.hpp"

#include "Renderer.hpp"

namespace Thermite
{
    class SoftwareRenderer : public Renderer
    {
    public:
        SoftwareRenderer() throw();
        ~SoftwareRenderer() throw();

		const Image< RGBA<uint1> >& image() const throw();

		void initialise(void) throw();
        void render(void) throw();

		void setSize(uint4 uWidth, uint4 uHeight);
	protected:
		Thermite::Image< RGBA<uint1> > imageVal;
    };
} //namespace Thermite

#endif
