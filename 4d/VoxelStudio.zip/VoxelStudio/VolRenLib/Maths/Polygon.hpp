#ifndef Polygon_HEADER_INCLUDED
#define Polygon_HEADER_INCLUDED

#include "..\Maths\Vector.hpp"

namespace Thermite
{	
	template<typename Type>
	class Polygon
	{
		//Forward declarations
	public:
		class Iterator;
	private:
		class Vertex;

		//Now the class definition.
	public:
		Polygon();
		Polygon& operator=(const Polygon& rhs) throw();
		Polygon(const Polygon<Type>& buffer);

		void appendVertex(const Vector<3,Type>& tPosition);
		void clear();
		void insertAfter(const Iterator& vertexToInsertAfter, const Vector<3,Type>& tPosition);
        void insertBefore(const Iterator& vertexToInsertBefore, const Vector<3,Type>& tPosition);		
		uint4 noOfVertices() const;
		Iterator firstVertex() const;			

	private:
		Vertex* m_pElems;
		uint4 m_uNoOfVertices;

		//Now the nested classes
        
	public:
		class Iterator
		{
			friend class Polygon<Type>;
		public:
			Vector<3,Type>& operator*() const;
			Vector<3,Type>* operator->() const;
			Iterator& operator++();
			Iterator operator++(int);
			Iterator& operator--();
			Iterator operator--(int);
			bool operator==(const Iterator& rhs);
			bool operator!=(const Iterator& rhs);
		private:
			Vertex* m_pVertex;
		};

	private:
		class Vertex
		{
			friend class Polygon<Type>;
			//Contents public as this nested class is private to Polygon.
		public:
			Vector<3,Type> m_tPosition;
			mutable Vertex* m_pNext;
			mutable Vertex* m_pPrevious;
		};
	};	
}

#include "Polygon.inl"

#endif
