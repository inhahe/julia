#include <cassert>
#include <cmath>

#include "..\Base\Utility.hpp"

namespace Thermite
{
	template <typename Type>
		Line<Type>::Line(const Vector<3,Type>& vecStart, const Vector<3,Type>& vecEnd) throw()
		:m_vecStart(vecStart)
		,m_vecEnd(vecEnd)
	{
	}

	template <typename Type>
	const Vector<3,Type>& Line<Type>::start(void) const throw()
	{
		return m_vecStart;
	}
	
	template <typename Type>
	Vector<3,Type>& Line<Type>::start(void) throw()
	{
		return m_vecStart;
	}

	template <typename Type>
	const Vector<3,Type>& Line<Type>::end(void) const throw()
	{
		return m_vecEnd;
	}

	template <typename Type>
	Vector<3,Type>& Line<Type>::end(void) throw()
	{
		return m_vecEnd;
	}
}//namespace Thermite
