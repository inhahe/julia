namespace Thermite
{
	template<typename Type>
		Polygon<Type>::Polygon()
		:m_pElems(0)
		,m_uNoOfVertices(0)
	{
	}

	template<typename Type>
		Polygon<Type>::Polygon(const Polygon<Type>& buffer)
		:m_pElems(0)
		,m_uNoOfVertices(0)
	{
		*this = buffer;
	}

	template<typename Type>
		Polygon<Type>& Polygon<Type>::operator=(const Polygon<Type>& rhs) throw()
	{
		if(this == &rhs)
		{
			return *this;
		}
		clear();
		if(rhs.noOfVertices() > 0)
		{
			Polygon<Type>::Iterator iter = rhs.firstVertex();
			do 
			{
				appendVertex(*iter);
				++iter;
			} while(iter != rhs.firstVertex());
		}
		return *this;
	}

	template<typename Type>
		void Polygon<Type>::appendVertex(const Vector<3,Type>& tPosition)
	{
		Polygon<Type>::Vertex* node = new Polygon<Type>::Vertex;
		node->m_tPosition = tPosition;
		if(m_uNoOfVertices == 0) //This is the first node that's been added...
		{
			node->m_pPrevious = node;
			node->m_pNext = node;
			m_pElems = node;
		}
		else
		{
			Polygon<Type>::Vertex* lastNode = m_pElems->m_pPrevious;
			lastNode->m_pNext = node;
			node->m_pPrevious = lastNode;
			node->m_pNext = m_pElems;
			m_pElems->m_pPrevious = node;
		}
		++m_uNoOfVertices;
	}

	template<typename Type>
		void Polygon<Type>::insertBefore(typename const Polygon<Type>::Iterator& vertexToInsertBefore, const Vector<3,Type>& tPosition)
	{
		Polygon<Type>::Vertex* node = new Polygon<Type>::Vertex;
		node->m_tPosition = tPosition;

		vertexToInsertBefore.m_pVertex->m_pPrevious->m_pNext = node;
		node->m_pPrevious = vertexToInsertBefore.m_pVertex->m_pPrevious;
		node->m_pNext = vertexToInsertBefore.m_pVertex;
		vertexToInsertBefore.m_pVertex->m_pPrevious = node;

		++m_uNoOfVertices;
	}

	template<typename Type>
		void Polygon<Type>::insertAfter(typename const Polygon<Type>::Iterator& vertexToInsertAfter, const Vector<3,Type>& tPosition)
	{
		Polygon<Type>::Vertex* node = new Polygon<Type>::Vertex;
		node->m_tPosition = tPosition;

		vertexToInsertAfter.m_pVertex->m_pNext->m_pPrevious = node;
		node->m_pNext = vertexToInsertAfter.m_pVertex->m_pNext;
		node->m_pPrevious = vertexToInsertAfter.m_pVertex;
		vertexToInsertAfter.m_pVertex->m_pNext = node;

		++m_uNoOfVertices;
	}

	template<typename Type>
		void Polygon<Type>::clear()
	{
		//Check if it's already empty.
		if(m_uNoOfVertices == 0)
		{
			return;
		}
		//If not, clear it.
		Polygon<Type>::Vertex* nodeToDelete = m_pElems->m_pPrevious;
		do
		{
			nodeToDelete = nodeToDelete->m_pPrevious;
			delete nodeToDelete->m_pNext;

		} while(nodeToDelete != m_pElems);
		delete m_pElems;

		m_pElems = 0;
		m_uNoOfVertices = 0;

	}

	template<typename Type>
		typename Polygon<Type>::Iterator Polygon<Type>::firstVertex() const
	{
		Polygon<Type>::Iterator iter;
		iter.m_pVertex = m_pElems;
		return iter;
	}

	template<typename T>
		uint4 Polygon<T>::noOfVertices() const
	{
		return m_uNoOfVertices;
	}

	//////////////////////////////////////////////////////////////////////////
	//Iterator
	//////////////////////////////////////////////////////////////////////////

	template<class Type>
		Vector<3,Type>& Polygon<Type>::Iterator::operator*() const
	{
		return m_pVertex->m_tPosition;
	}

	template<class Type>
		Vector<3,Type>* Polygon<Type>::Iterator::operator->() const
	{
		return (&(operator*()));
	}

	template<class Type>
		typename Polygon<Type>::Iterator& Polygon<Type>::Iterator::operator++()
	{
		m_pVertex = m_pVertex->m_pNext;
		return *this;
	}

	template<class Type>
		typename Polygon<Type>::Iterator Polygon<Type>::Iterator::operator++(int)
	{
		Polygon<Type>::Iterator temp = *this;
		m_pVertex = m_pVertex->m_pNext;
		return temp;
	}

	template<class Type>
		typename Polygon<Type>::Iterator& Polygon<Type>::Iterator::operator--()
	{
		m_pVertex = m_pVertex->m_pPrevious;
		return *this;
	}

	template<class Type>
		typename Polygon<Type>::Iterator Polygon<Type>::Iterator::operator--(int)
	{
		Polygon<Type>::Iterator temp = *this;
		m_pVertex = m_pVertex->m_pPrevious;
		return temp;
	}

	template<class Type>
		bool Polygon<Type>::Iterator::operator==(const Iterator& rhs)
	{
		return (m_pVertex == rhs.m_pVertex);
	}

	template<class Type>
		bool Polygon<Type>::Iterator::operator!=(const Iterator& rhs)
	{
		return (m_pVertex != rhs.m_pVertex);
	}
}