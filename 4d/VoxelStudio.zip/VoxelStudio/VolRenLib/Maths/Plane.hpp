#ifndef PLANE_HEADER_INCLUDED
#define PLANE_HEADER_INCLUDED

#include "..\Base\Typedef.hpp"
#include "Vector.hpp"

namespace Thermite
{
	template <typename Type>
	class Plane
	{
	public:
		Plane(const Vector<3,Type>& vecNormal, const Type& fD) throw();
		Plane(const Vector<3,Type>& vecNormal, const Vector<3,Type>& vecPointOnPlane) throw();

		const Vector<3,Type>& normal(void) const throw();
		//Vector3D<Type>& normal(void) throw();
		const Type& d(void) const throw();
		//Type& d(void) throw();

	private:
		Vector<3,Type> m_vecNormal;
		Type m_fD;
	};	
}//namespace Thermite

#include "Plane.inl"

#endif

