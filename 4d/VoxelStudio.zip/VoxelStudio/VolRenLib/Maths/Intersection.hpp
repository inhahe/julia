#ifndef INTERSECTION_HEADER_INCLUDED
#define INTERSECTION_HEADER_INCLUDED

#include "Line.hpp"
#include "Plane.hpp"

namespace Thermite
{
	template <typename Type>
	Vector<3,Type> intersectionOf(const Line<Type>& line, const Plane<Type>& plane);

	template <typename Type>
	uint4 computeNoOfStepsToExitBox(const Vector<3,Type>& rayPosition, const Vector<3,Type>& rayDirection, const Vector<3,Type>& minBoxCorner, const Vector<3,Type>& maxBoxCorner);
}//namespace Thermite

#include "Intersection.inl"

#endif

