#include <cassert>
#include <cmath>

#include "..\Base\Utility.hpp"

namespace Thermite
{
	template <typename Type>
		Plane<Type>::Plane(const Vector<3,Type>& vecNormal, const Type& fD) throw()
		:m_vecNormal(vecNormal)
		,m_fD(fD)
	{
	}

	template <typename Type>
		Plane<Type>::Plane(const Vector<3,Type>& vecNormal, const Vector<3,Type>& vecPointOnPlane) throw()
		:m_vecNormal(vecNormal)
	{
		m_fD = vecNormal.dot(vecPointOnPlane);
	}

	template <typename Type>
		const Vector<3,Type>& Plane<Type>::normal(void) const throw()
	{
		return m_vecNormal;
	}

	/*template <typename Type>
		Vector3D<Type>& Plane<Type>::normal(void) throw()
	{
		return m_vecNormal;
	}*/

	template <typename Type>
		const Type& Plane<Type>::d(void) const throw()
	{
		return m_fD;
	}

	/*template <typename Type>
		Type& Plane<Type>::d(void) throw()
	{
		return m_fD;
	}*/
}//namespace Thermite
