#include "..\Base\Utility.hpp"

namespace Thermite
{
	template <typename Type>
		Vector<3,Type> intersectionOf(const Line<Type>& line, const Plane<Type>& plane)
	{
		Vector<3,Type> startToEnd = line.end() - line.start();
		Type t = (plane.d() - plane.normal().dot(line.start())) / plane.normal().dot(startToEnd);

		if((t >= static_cast<Type>(0.0)) && (t <= static_cast<Type>(1.0)))
		{
			Vector<3,Type> intersectionPoint = line.start() + (startToEnd * t);
			return intersectionPoint;
		}
		else
		{
			//FIXME - should use exceptions
			return Vector<3,Type>(0.0f,0.0f,0.0f);
		}
	}

	template <typename Type>
		uint4 computeNoOfStepsToExitBox(const Vector<3,Type>& rayPosition, const Vector<3,Type>& rayDirection, const Vector<3,Type>& minBoxCorner, const Vector<3,Type>& maxBoxCorner)
	{
		double xSteps;
		double ySteps;
		double zSteps;

		if(rayDirection.x() > 0.0f)
		{
			xSteps = maxBoxCorner.x() - rayPosition.x();  
			xSteps /= rayDirection.x();
		}
		else if(rayDirection.x() < 0.0f)
		{
			xSteps = minBoxCorner.x() - rayPosition.x();
			xSteps /= rayDirection.x();
		}
		else
		{
			xSteps = std::numeric_limits<Type>::infinity();
		}

		if(rayDirection.y() > 0.0f)
		{
			ySteps = maxBoxCorner.y() - rayPosition.y();
			ySteps /= rayDirection.y();
		}
		else if(rayDirection.y() < 0.0f)
		{
			ySteps = minBoxCorner.y() - rayPosition.y();
			ySteps /= rayDirection.y();
		}
		else
		{
			ySteps = std::numeric_limits<Type>::infinity();
		}

		if(rayDirection.z() > 0.0f)
		{
			zSteps = maxBoxCorner.z() - rayPosition.z();
			zSteps /= rayDirection.z();
		}
		else if(rayDirection.z() < 0.0f)
		{
			zSteps = minBoxCorner.z() - rayPosition.z();			
			zSteps /= rayDirection.z();
		}
		else
		{
			zSteps = std::numeric_limits<Type>::infinity();
		}

		double minSteps = (std::min)(xSteps, ySteps);
		minSteps = (std::min)(minSteps, zSteps);

		//Takes the ceil
		return static_cast<uint4>(minSteps+1.0);
	}
}//namespace Thermite
