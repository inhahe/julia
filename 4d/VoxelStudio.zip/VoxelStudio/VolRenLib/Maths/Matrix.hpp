#ifndef MATRIX_H
#define MATRIX_H

#include <iosfwd>

#include "..\Base\Typedef.hpp"

namespace Thermite
{
    //Forward Declarations
    template <uint4 Size, typename Type> class Vector;

    //!Represents a 3x3 matrix
    /*!
    Detailed info...
    */
    template <uint4 Size, typename Type>
    class Matrix
    {
    public:
        //!Constructor.
        Matrix() throw();
        //!Copy Constructor.
        Matrix(const Matrix<Size,Type>& matrixToCopy) throw();
        //!Destructor.
        ~Matrix() throw();

        //!Assignment operator.
        Matrix<Size,Type>& operator=(const Matrix<Size,Type> &rhs) throw();
		//!Subtraction operator
		Matrix<Size,Type>& operator-=(const Matrix<Size,Type>& rhs) throw();
        //!Multiplication operator
        Matrix<Size,Type>& operator*=(const Matrix<Size,Type>& rhs) throw();
        //!Multiplication operator
        Matrix<Size,Type>& operator*=(const Type& rhs) throw();
        //!Division operator
        Matrix<Size,Type>& operator/=(const Type& rhs) throw();
        //!Gets the Matrix element at the specified position.
        Type operator()(uint4 row, uint4 column) const throw();
        //!Sets the Matrix element at the specified position.
        void set(uint4 row, uint4 column, Type tValue) throw();

        //!Calculates the determinant of the Matrix.
        double determinant(void) const throw();   
		//!Returns the Transpose
		Matrix<Size,Type> transpose(void) const throw();

        //!Converts this Matrix to the identity matrix.
        static const Matrix<Size,Type> identity(void) throw();
        //!Scales the Matrix by the specified amount.
        void scale(const Type& xScale, const Type& yScale, const Type& zScale) throw();
        //!Uniforly scales the matrix by the specified amount.
        void scale(const Type& amount) throw();

    private:
        //The matrix data
        Type m_tData[Size*Size];
    };

    //!Multiplication Operator.
    template <uint4 Size,typename Type>
        const Matrix<Size,Type> operator*(const Matrix<Size,Type>& lhs, const Type& rhs) throw();
    //!Multiplication operator.
    template <uint4 Size,typename Type>
	const Matrix<Size,Type> operator*(const Matrix<Size,Type>& lhs, const Matrix<Size,Type>& rhs) throw();
	//!Subraction operator.
	template <uint4 Size,typename Type>
		const Matrix<Size,Type> operator-(const Matrix<Size,Type>& lhs, const Matrix<Size,Type>& rhs) throw();
    //!Multiplication operator.
    /*template <uint4 Size,typename Type>
        const Vector<Size,Type> operator*(const Matrix<Size,Type>& lhs, const Vector<Size,Type>& rhs) throw();*/
    //!Division Operator.
    template <uint4 Size,typename Type>
        const Matrix<Size,Type> operator/(const Matrix<Size,Type>& lhs, const Type& rhs) throw();
    //!Stream Insertion Operator.
    template <uint4 Size,typename Type>
        std::ostream& operator<<(std::ostream& os, const Matrix<Size,Type>& m) throw();

	template<typename Type>
	Matrix<2,Type> create2x2RotationMatrix(const Type angle);
	template<typename Type>
	Matrix<3,Type> create3x3RotationMatrix(Vector<3,Type> axis, const Type angle);

	typedef Matrix<2,float> Matrix2DFloat;
	typedef Matrix<2,double> Matrix2DDouble;
	typedef Matrix<3,float> Matrix3DFloat;
	typedef Matrix<3,double> Matrix3DDouble;
	typedef Matrix<4,float> Matrix4DFloat;
	typedef Matrix<4,double> Matrix4DDouble;

}//namespace Thermite

#include "Matrix.inl"

#endif
