#include <cassert>
#include <cmath>

#include "Vector.hpp"

namespace Thermite
{
	//-------------------------- Constructors, etc ---------------------------------
	/*!
	Creates a Matrix and initialises it to the identity Matrix.
	*/
	template <uint4 Size,typename Type>
		Matrix<Size,Type>::Matrix() throw()
	{
		for(uint4 row = 0; row < Size; ++row)
		{
			for(uint4 col = 0; col < Size; ++col)
			{
				if(row == col)
				{
					set(row,col,1.0);
				}
				else
				{
					set(row,col,0.0);
				}
			}
		}
	}

	/*!
	Creates a Matrix to be the same as the one passed as a parameter.
	\param matrixToCopy The matrix to be copied.
	*/
	template <uint4 Size,typename Type>
		Matrix<Size,Type>::Matrix(const Matrix<Size,Type>& matrixToCopy) throw()
	{
		*this = matrixToCopy;
	}

	/*!
	Destroys the Matrix.
	*/
	template <uint4 Size,typename Type>
		Matrix<Size,Type>::~Matrix() throw()
	{
	}

	//------------------------------- Overloaded Operators -------------------------

	/*!
	Assigns one matrix to be equal to another.
	\param rhs Matrix to make equal to.
	\return A reference to itself for chaining assignments.
	*/
	template <uint4 Size,typename Type>
		Matrix<Size,Type>& Matrix<Size,Type>::operator=(const Matrix<Size,Type>& rhs) throw()
	{
		assert(this != &rhs);
		memcpy(m_tData, rhs.m_tData, sizeof(Type) * Size * Size);
		return *this;
	}

	/*!
	Subtraction operator
	\return A reference to itself to allow chaining.
	*/
	template <uint4 Size,typename Type>
		Matrix<Size,Type>& Matrix<Size,Type>::operator-=(const Matrix& rhs) throw()
	{
		for(uint4 ct = 0; ct < (Size * Size); ct++)
			m_tData[ct] -= rhs.m_tData[ct];
		return *this;
	}

	/*!
	Multiplies every element of the Matrix by the the value passed as a parameter.
	\param rhs The Matrix to multiply by.
	\return A reference to itself to allow chaining.
	*/
	template <uint4 Size,typename Type>
		Matrix<Size,Type>& Matrix<Size,Type>::operator*=(const Matrix& rhs) throw()
	{
		Matrix<Size,Type> result;

		result.m_tData[0] = m_tData[0]*rhs.m_tData[0]+m_tData[3]*rhs.m_tData[1]+m_tData[6]*rhs.m_tData[2];
		result.m_tData[1] = m_tData[1]*rhs.m_tData[0]+m_tData[4]*rhs.m_tData[1]+m_tData[7]*rhs.m_tData[2];
		result.m_tData[2] = m_tData[2]*rhs.m_tData[0]+m_tData[5]*rhs.m_tData[1]+m_tData[8]*rhs.m_tData[2];

		result.m_tData[3] = m_tData[0]*rhs.m_tData[3]+m_tData[3]*rhs.m_tData[4]+m_tData[6]*rhs.m_tData[5];
		result.m_tData[4] = m_tData[1]*rhs.m_tData[3]+m_tData[4]*rhs.m_tData[4]+m_tData[7]*rhs.m_tData[5];
		result.m_tData[5] = m_tData[2]*rhs.m_tData[3]+m_tData[5]*rhs.m_tData[4]+m_tData[8]*rhs.m_tData[5];

		result.m_tData[6] = m_tData[0]*rhs.m_tData[6]+m_tData[3]*rhs.m_tData[7]+m_tData[6]*rhs.m_tData[8];
		result.m_tData[7] = m_tData[1]*rhs.m_tData[6]+m_tData[4]*rhs.m_tData[7]+m_tData[7]*rhs.m_tData[8];
		result.m_tData[8] = m_tData[2]*rhs.m_tData[6]+m_tData[5]*rhs.m_tData[7]+m_tData[8]*rhs.m_tData[8];



		*this = result;
		return *this;
	}

	/*!
	Multiplies every element of the Matrix by the the value passed as a parameter.
	\param rhs The number to multiply each element by.
	\return A reference to itself to allow chaining.
	*/
	template <uint4 Size,typename Type>
		Matrix<Size,Type>& Matrix<Size,Type>::operator*=(const Type& rhs) throw()
	{
		for(uint4 ct = 0; ct < (Size * Size); ct++)
			m_tData[ct] = m_tData[ct] * rhs;
		return *this;
	}

	/*!
	Divides every element of the Matrix by the the value passed as a parameter.
	\param rhs The number to divide each element by.
	\return A reference to itself to allow chaining.
	*/
	template <uint4 Size,typename Type>
		Matrix<Size,Type>& Matrix<Size,Type>::operator/=(const Type& rhs) throw()
	{
		for(uint4 ct = 0; ct < (Size * Size); ct++)
			m_tData[ct] = m_tData[ct] / rhs;
		return *this;
	}

	/*!
	\param column The column of the desired element (1 to 3).
	\param row The row of the desired element (1 to 3).
	\return The value at the specified position.
	\see setElement()
	*/
	template <uint4 Size,typename Type>
		Type Matrix<Size,Type>::operator()(uint4 row, uint4 column) const throw()
	{
		assert((row >= 0) && (row < Size));
		assert((column >= 0) && (column < Size));

		return m_tData[column * Size + row];
	}

	/*!
	\param column The column of the desired element (1 to 3).
	\param row The row of the desired element (1 to 3).
	\param m_tDataToSet The value to be set at the specified position.
	\see getElement()
	*/
	template <uint4 Size,typename Type>
		void Matrix<Size,Type>::set(uint4 row, uint4 column, Type tValue) throw()
	{
		assert((row >= 0) && (row < Size));
		assert((column >= 0) && (column < Size));

		m_tData[column * Size + row] = tValue;
	}

	/*!
	Multiplies every element of the Matrix by the the value passed as a parameter.
	\param lhs The Matrix to multiply.
	\param rhs The amount to multiply by.
	\return The resulting Matrix.
	*/
	template <uint4 Size,typename Type>
		const Matrix<Size,Type> operator*(const Matrix<Size,Type>& lhs, const Type& rhs) throw()
	{
		Matrix<Size,Type> result(lhs);
		result *= rhs;
		return result;
	}

	/*!
	Multiplies one Matrix by another, using proper Matrix multiplication
	rules. It is important to remember that A*B is different from B*A.
	\param lhs The Matrix to multiply.
	\param rhs The Matrix to multiply by.
	\return The resulting matrix.
	*/
	template <uint4 Size,typename Type>
		const Matrix<Size,Type> operator*(const Matrix<Size,Type>& lhs, const Matrix<Size,Type>& rhs) throw()
	{
		Matrix<Size,Type> result(lhs);
		result *= rhs;
		return result;
	}

	/*!
	Subraction
	\return The resulting matrix.
	*/
	template <uint4 Size,typename Type>
		const Matrix<Size,Type> operator-(const Matrix<Size,Type>& lhs, const Matrix<Size,Type>& rhs) throw()
	{
		Matrix<Size,Type> result(lhs);
		result -= rhs;
		return result;
	}

	/*!
	Multiplies a Vector by a Matrix, which transforms the Vector in the way specified
	by the Matrix.
	\param lhs The Vector to multiply.
	\param rhs The Matrix to multiply by.
	\return The resulting Vector.
	*/
	/*template <uint4 Size,typename Type>
		const Vector<Size,Type> operator*(const Matrix<Size,Type>& lhs, const Vector<Size,Type>& rhs) throw()
	{
		//FIXME - rewrite
		Type x = lhs(0,0) * rhs.x() + lhs(0,1) * rhs.y() + lhs(0,2) * rhs.z();
		Type y = lhs(1,0) * rhs.x() + lhs(1,1) * rhs.y() + lhs(1,2) * rhs.z();
		Type z = lhs(2,0) * rhs.x() + lhs(2,1) * rhs.y() + lhs(2,2) * rhs.z();

		Vector<3,Type> result;
		result.x() = x;
		result.y() = y;
		result.z() = z;

		return result;
	}*/

	/*!
	Divides every element of the Matrix by the the value passed as a parameter.
	\param lhs The Matrix to divide.
	\param rhs The amount to divide by.
	\return The resulting Matrix.
	*/
	template <uint4 Size,typename Type>
		const Matrix<Size,Type> operator/(const Matrix<Size,Type>& lhs, const Type& rhs) throw()
	{
		Matrix<Size,Type> result(lhs);
		result /= rhs;
		return result;
	}

	/*!
	Outputs the Matrix as the 9 values seperated by comma's and surrounded
	by square brackets. The order of the number is down the first column of
	the Matrix, then the second, etc.
	\param os A referance to the output stream.
	\param m The Matrix to be output.
	\return A referance to the output stream to allow chaining.
	*/
	template <uint4 Size,typename Type>
		std::ostream& operator<<(std::ostream& os, const Matrix<Size,Type>& m) throw()
	{
		os << "[";
		for(uint4 col = 0; col < Size; ++col)
		{
			for(uint4 row = 0; row < Size; ++row)
			{
				os << m(row,col);
				if(row < Size-1)
				{
					os << ",";
				}
			}
			if(col < Size-1)
			{
				os << ";";
			}
		}
		os << "]";
		return os;
	}

	//----------------------------------- Getters ----------------------------------



	//----------------------------------- Setters ----------------------------------



	//-------------------------------- Other Functions -----------------------------

	/*!
	*/
	template <uint4 Size,typename Type>
		const Matrix<Size,Type> Matrix<Size,Type>::identity(void) throw()
	{
		Matrix<Size,Type> ident; //Defaults to identity
		return ident;
	}

	/*!
	\param xScale Amount to scale by in x.
	\param yScale Amount to scale by in y.
	\param zScale Amount to scale by in z.
	\see rotate(), translate()
	*/
	template <uint4 Size,typename Type>
		void Matrix<Size,Type>::scale(const Type& xScale, const Type& yScale, const Type& zScale) throw()
	{
		Matrix<Size,Type> scale;
		scale.m_tData[0] = xScale;
		scale.m_tData[4] = yScale;
		scale.m_tData[8] = zScale;
		*this = (*this) * scale;
	}

	/*!
	\param amount The amount to scale by in all directions.
	\see rotate(), translate()
	*/
	template <uint4 Size,typename Type>
		void Matrix<Size,Type>::scale(const Type& amount) throw()
	{
		Matrix<Size,Type> scale;
		scale.m_tData[0] = amount;
		scale.m_tData[4] = amount;
		scale.m_tData[8] = amount;
		*this = (*this) * scale;
	}

	template <uint4 Size,typename Type>
		double Matrix<Size,Type>::determinant(void) const throw()
	{		
		return 0.0;
	}

	template <uint4 Size,typename Type>
		Matrix<Size,Type> Matrix<Size,Type>::transpose(void) const throw()
	{
		Matrix<Size,Type> transposedMatrix;

		transposedMatrix.set(0,0,(*this)(0,0));
		transposedMatrix.set(0,1,(*this)(1,0));
		transposedMatrix.set(0,2,(*this)(2,0));

		transposedMatrix.set(1,0,(*this)(0,1));
		transposedMatrix.set(1,1,(*this)(1,1));
		transposedMatrix.set(1,2,(*this)(2,1));

		transposedMatrix.set(2,0,(*this)(0,2));
		transposedMatrix.set(2,1,(*this)(1,2));
		transposedMatrix.set(2,2,(*this)(2,2));

		return transposedMatrix;
	}

	template<typename Type>
	Matrix<2,Type> create2x2RotationMatrix(const Type angle)
	{
		Matrix<2,Type> result;
		result.set(0,0,cos(angle));
		result.set(0,1,-sin(angle));
		result.set(1,0,sin(angle));
		result.set(1,1,cos(angle));
		return result;
	}

	template<typename Type>
	Matrix<3,Type> create3x3RotationMatrix(Vector<3,Type> axis, const Type angle)
	{
		axis.normalise();
		Type x = axis.x();
		Type y = axis.y();
		Type z = axis.z();

		Type c = c = cos(angle);
		Type s = sin(angle);

		Matrix<3,Type> result;
		result.set(0,0,x*x*(1-c)+c);
		result.set(0,1,x*y*(1-c)-z*s);
		result.set(0,2,x*z*(1-c)+y*s);
		result.set(1,0,y*x*(1-c)+z*s);
		result.set(1,1,y*y*(1-c)+c);
		result.set(1,2,y*z*(1-c)-x*s);
		result.set(2,0,x*z*(1-c)-y*s);
		result.set(2,1,y*z*(1-c)+x*s);
		result.set(2,2,z*z*(1-c)+c);
		return result;
	}
}//namespace Thermite
