#ifndef LINE_HEADER_INCLUDED
#define LINE_HEADER_INCLUDED

#include "..\Base\Typedef.hpp"
#include "Vector.hpp"

namespace Thermite
{
	template <typename Type>
	class Line
	{
	public:
		Line(const Vector<3,Type>& vecStart, const Vector<3,Type>& vecEnd) throw();

		const Vector<3,Type>& start(void) const throw();
		Vector<3,Type>& start(void) throw();
		const Vector<3,Type>& end(void) const throw();
		Vector<3,Type>& end(void) throw();

	private:
		Vector<3,Type> m_vecStart;
		Vector<3,Type> m_vecEnd;
	};	
}//namespace Thermite

#include "Line.inl"

#endif

